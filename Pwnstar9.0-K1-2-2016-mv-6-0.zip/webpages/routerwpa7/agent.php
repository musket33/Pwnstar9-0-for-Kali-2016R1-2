<?php
	$agent = $_SERVER['HTTP_USER_AGENT'];
	echo "<h2>$agent</h2>";
?>